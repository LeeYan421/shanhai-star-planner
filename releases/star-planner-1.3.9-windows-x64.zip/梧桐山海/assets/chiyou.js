/* 首次进入才读取本机兵魂资料，查询状态不修改星宿配置，不产生网络上报。 */
(() => {
  'use strict';
  const $=id=>document.getElementById(id),esc=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const size=24,state={index:null,loading:false,tab:'souls',page:0,history:[]};let queryTimer;
  const soulRow=s=>`<mdui-card class="chiyou-row" data-chiyou-soul="${s.id}" clickable role="button" tabindex="0" variant="filled"><span><strong>${esc(s.name)}</strong><small>${esc(s.description).replace(/\n/g,' · ')}</small></span><span class="chiyou-row-side">${s.pets.length}种宠物 <b>›</b></span></mdui-card>`;
  const petRow=p=>`<mdui-card class="chiyou-row chiyou-pet-row" data-chiyou-pet="${esc(p.name)}" clickable role="button" tabindex="0" variant="filled"><span><strong>${esc(p.name)}</strong><small>${p.souls.map(s=>esc(s.name)).join('、')}</small></span><span class="chiyou-row-side">${p.souls.length}种兵魂 <b>›</b></span></mdui-card>`;
  function render(){
    if(!state.index)return;const rows=state.tab==='souls'?state.index.searchSouls($('chiyou-query').value):state.index.searchPets($('chiyou-query').value),pages=Math.max(1,Math.ceil(rows.length/size));state.page=Math.min(state.page,pages-1);
    document.querySelectorAll('[data-chiyou-tab]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.chiyouTab===state.tab)));
    $('chiyou-query').placeholder=state.tab==='souls'?'搜索兵魂名称、效果或宠物':'搜索宠物或兵魂名称';$('chiyou-total').textContent=rows.length+(state.tab==='souls'?'种兵魂':'种宠物');
    $('chiyou-results').innerHTML=rows.slice(state.page*size,(state.page+1)*size).map(state.tab==='souls'?soulRow:petRow).join('')||'<p class="chiyou-empty">没有匹配结果，试试兵魂简称或宠物名。</p>';
    $('chiyou-pager').classList.toggle('hidden',pages<=1);$('chiyou-page').textContent=state.page+1+' / '+pages;$('chiyou-prev').disabled=state.page===0;$('chiyou-next').disabled=state.page===pages-1;
  }
  async function open(){
    if(state.index){render();return;}if(state.loading)return;state.loading=true;$('chiyou-message').textContent='正在读取兵魂资料…';$('chiyou-retry').classList.add('hidden');
    try{const response=await fetch('chiyou-data.json');if(!response.ok)throw new Error('兵魂资料未能读取');state.index=createChiyouIndex(await response.json());$('chiyou-content').classList.remove('hidden');$('chiyou-message').textContent='';render();}
    catch(error){globalThis.Diagnostics?.record('chiyou',error);$('chiyou-message').textContent='资料载入失败，请重试';$('chiyou-retry').classList.remove('hidden');}finally{state.loading=false;}
  }
  function renderDetail(){
    const item=state.history.at(-1);if(!item)return;$('chiyou-detail-back').classList.toggle('hidden',state.history.length<2);
    if(item.kind==='soul'){
      const soul=state.index.souls.get(item.id);$('chiyou-detail-title').textContent=soul.name;
      $('chiyou-detail-body').innerHTML=`<p class="chiyou-description">${esc(soul.description)}</p><div class="chiyou-qualities">${state.index.qualities.map((q,i)=>`<span class="mutation-quality" data-quality="${i}">${esc(q)}</span>`).join('')}</div><div class="subheading"><h3>可作核心的宠物</h3><span class="muted">${soul.pets.length}种</span></div><label class="sr-only" for="chiyou-source-query">筛选核心宠物</label><mdui-text-field id="chiyou-source-query" class="chiyou-source-query" type="search" placeholder="搜索这些宠物" value="${esc(item.query||'')}" variant="filled"></mdui-text-field><div id="chiyou-source-results"></div><mdui-button id="chiyou-source-more" class="text-button hidden" variant="text">加载更多</mdui-button><p class="hint">已按名称去重，支援宠物不作为凝炼来源。同名宠物的具体结果以魂力页为准。</p>`;renderSources();
    }else{
      const pet=state.index.pets.get(item.name);$('chiyou-detail-title').textContent=pet.name;$('chiyou-detail-body').innerHTML=`<p class="hint">对应${pet.souls.length}种兵魂${pet.souls.length>1?'，同名记录已合并，请以宠物魂力页核对':''}。</p>${pet.souls.map(soulRow).join('')}`;
    }
  }
  function renderSources(){const item=state.history.at(-1),rows=state.index.sources(item.id,item.query),limit=(item.page+1)*size;$('chiyou-source-results').innerHTML=rows.slice(0,limit).map(petRow).join('')||'<p class="chiyou-empty">没有匹配的核心宠物。</p>';$('chiyou-source-more').classList.toggle('hidden',rows.length<=limit);}
  function show(item){state.history.push({...item,query:'',page:0});renderDetail();if(!$('chiyou-detail').open)$('chiyou-detail').showModal();$('chiyou-detail').scrollTop=0;}
  function close(){state.history=[];$('chiyou-detail').close();}
  function back(){if(!$('chiyou-detail').open)return false;if(state.history.length>1){state.history.pop();renderDetail();}else close();return true;}
  $('chiyou-retry').addEventListener('click',open);$('chiyou-query').addEventListener('input',()=>{state.page=0;clearTimeout(queryTimer);queryTimer=setTimeout(render,180);});
  $('chiyou-clear').addEventListener('click',()=>{clearTimeout(queryTimer);$('chiyou-query').value='';state.page=0;render();});
  document.querySelectorAll('[data-chiyou-tab]').forEach(b=>b.addEventListener('click',()=>{clearTimeout(queryTimer);state.tab=b.dataset.chiyouTab;state.page=0;render();}));
  $('chiyou-prev').addEventListener('click',()=>{state.page--;render();$('chiyou-results').scrollIntoView({block:'start'});});$('chiyou-next').addEventListener('click',()=>{state.page++;render();$('chiyou-results').scrollIntoView({block:'start'});});
  document.addEventListener('click',event=>{const soul=event.target.closest('[data-chiyou-soul]'),pet=event.target.closest('[data-chiyou-pet]');if(!state.index)return;if(soul)show({kind:'soul',id:Number(soul.dataset.chiyouSoul)});else if(pet)show({kind:'pet',name:pet.dataset.chiyouPet});});
  $('chiyou-detail-close').addEventListener('click',close);$('chiyou-detail-back').addEventListener('click',back);$('chiyou-detail').addEventListener('cancel',event=>{if(state.history.length>1){event.preventDefault();back();}else state.history=[];});
  $('chiyou-detail-body').addEventListener('input',event=>{if(event.target.id!=='chiyou-source-query')return;const item=state.history.at(-1);item.query=event.target.value;item.page=0;renderSources();});
  $('chiyou-detail-body').addEventListener('click',event=>{if(event.target.closest('#chiyou-source-more')){state.history.at(-1).page++;renderSources();}});
  globalThis.ChiyouTool={open,back,leave(){clearTimeout(queryTimer);if($('chiyou-detail').open)close();}};
})();
