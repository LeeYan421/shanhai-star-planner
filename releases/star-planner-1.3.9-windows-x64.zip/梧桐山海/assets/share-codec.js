/* 方案码仅包含配置，不保存身份、名称、进度或求解结果；校验后仍需重新计算。 */
(function(root){
  'use strict';
  if(typeof module!=='undefined'&&module.exports)require('./pvp-rules.js');
  const rules=['crit','power','attack-pen','crit-target','pvp'];
  const pvpRules=()=>createPvpRules();
  function checksum(text){let crc=-1;for(const byte of new TextEncoder().encode(text)){crc^=byte;for(let bit=0;bit<8;bit++)crc=crc>>>1^(-(crc&1)&0xedb88320);}return((crc^-1)>>>0).toString(16).padStart(8,'0');}
  function integer(value,max){if(!Number.isSafeInteger(value)||value<0||value>max)throw new Error('方案码数值超出范围');return value;}
  function unique(values,max,length){if(!Array.isArray(values)||values.length>length||values.some(v=>!Number.isSafeInteger(v)||v<0||v>max)||new Set(values).size!==values.length)throw new Error('方案码目标格式无效');return values;}
  function encode(config,data){
    const elements=data.elements.flatMap(e=>e.options.map(o=>o.key)),rule=rules.indexOf(config.strategy);
    if(rule<0||!/^\d+$/.test(String(config.budget))||!/^\d+$/.test(String(config.capacity))||config.strategy==='crit-target'&&!/^\d+$/.test(String(config.critTarget)))throw new Error('先填写完整的点数、容量和目标');
    if(!Array.isArray(config.selected)||!Array.isArray(config.elements)||config.elements.some(k=>!elements.includes(k)))throw new Error('方案目标无效');
    const packet=[1,data.sourceSha256.slice(0,16),Number(config.budget),Number(config.capacity),rule,rule===3?Number(config.critTarget):0,[...new Set(config.selected)].sort((a,b)=>a-b),[...new Set(config.elements.map(k=>elements.indexOf(k)))].sort((a,b)=>a-b)];
    const custom=config.elementRules||[];
    if(!Array.isArray(custom)||custom.length>4)throw new Error('元素自定义目标无效');
    if(custom.length){packet[0]=2;packet.push(custom.map(r=>{const index=data.elements.findIndex(e=>e.key===r?.key);if(index<0||!['points','attack'].includes(r.mode)||!/^\d{1,7}$/.test(String(r.value))||data.elements[index].options.some(o=>config.elements.includes(o.key)))throw new Error('元素自定义目标无效');return [index,r.mode==='points'?0:1,Number(r.value)];}).sort((a,b)=>a[0]-b[0]));}
    const stars=config.elementStars||[];if(!Array.isArray(stars))throw new Error('元素星宿等级无效');
    if(stars.length){packet[0]=3;if(packet.length===8)packet.push([]);packet.push(stars.map(s=>[s.starId,s.levels]).sort((a,b)=>a[0]-b[0]));}
    if(config.strategy==='pvp'){const p=pvpRules().normalize(config.pvp);packet[0]=4;packet[8]??=[];packet[9]??=[];packet[10]=[pvpRules().presets.findIndex(x=>x.key===p.preset),p.attrIds];if(Object.values(p.weights).some(weight=>weight!==1)){packet[0]=5;packet[11]=pvpRules().attributes.map(a=>Math.round(p.weights[a.id]*100));}}
    const text=JSON.stringify(packet);validate(packet);const payload=btoa(text).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
    return 'WS1-'+payload+'.'+checksum(text);
  }
  function validate(packet){
    if(!Array.isArray(packet)||![1,2,3,4,5].includes(packet[0])||packet.length!==packet[0]+7||typeof packet[1]!=='string'||!/^[a-f0-9]{16}$/.test(packet[1]))throw new Error('不支持的方案码版本');
    integer(packet[2],1000000);integer(packet[3],60);integer(packet[4],packet[0]>=4?4:3);integer(packet[5],1000000);unique(packet[6],100000,24);unique(packet[7],63,32);
    if(packet[0]>=2){const rows=packet[8];if(!Array.isArray(rows)||(packet[0]===2&&!rows.length)||rows.length>4||new Set(rows.map(r=>r?.[0])).size!==rows.length)throw new Error('元素自定义目标无效');for(const r of rows){if(!Array.isArray(r)||r.length!==3)throw new Error('元素自定义目标无效');integer(r[0],3);integer(r[1],1);integer(r[2],1000000);}}
    if(packet[0]>=3){const stars=packet[9];if(!Array.isArray(stars)||packet[0]===3&&!stars.length||stars.length>8||new Set(stars.map(s=>s?.[0])).size!==stars.length)throw new Error('元素星宿等级无效');for(const s of stars){if(!Array.isArray(s)||s.length!==2||!Array.isArray(s[1])||!s[1].length||s[1].length>20)throw new Error('元素星宿等级无效');integer(s[0],100000);for(const lv of s[1])integer(lv,6);}}
    if(packet[0]>=4){
      const p=packet[10];if(packet[4]!==4||!Array.isArray(p)||p.length!==2)throw new Error('PVP属性与规则不一致');integer(p[0],pvpRules().presets.length-1);
      let weights;if(packet[0]===5){if(!Array.isArray(packet[11])||packet[11].length!==pvpRules().attributes.length)throw new Error('PVP权重格式无效');weights=Object.fromEntries(pvpRules().attributes.map((a,i)=>[a.id,integer(packet[11][i],10000)/100]));}
      pvpRules().normalize({preset:pvpRules().presets[p[0]].key,attrIds:p[1],weights});
    }
    if(packet[4]!==3&&packet[5]!==0)throw new Error('方案码目标与规则不一致');return packet;
  }
  function read(raw){
    if(typeof raw!=='string'||raw.length>4096)throw new Error('方案码过长或格式无效');
    if((raw.match(/WS1-/g)||[]).length!==1)throw new Error('请一次只粘贴一条方案码');
    const found=raw.match(/WS1-[A-Za-z0-9_-]+\.[a-f0-9]{8}(?![A-Za-z0-9_-])/g);if(!found||found.length!==1)throw new Error('请粘贴一条完整的WS1方案码');
    const code=found[0];if(code.length>1600)throw new Error('方案码过长');const [payload,digest]=code.slice(4).split('.');
    let text,packet;try{text=atob(payload.replace(/-/g,'+').replace(/_/g,'/'));packet=JSON.parse(text);}catch{throw new Error('方案码内容损坏');}
    if(checksum(text)!==digest)throw new Error('方案码校验失败，请重新复制');validate(packet);return {code,packet};
  }
  function inspect(raw){const {code,packet:p}=read(raw);return {code,source:p[1],budget:p[2],capacity:p[3],strategy:rules[p[4]],critTarget:p[4]===3?p[5]:null,talentCount:p[6].length,elementCount:p[7].length+(p[8]?.length||0)+(p[9]?.length||0),...(p[8]?{elementRules:p[8].map(r=>({name:['金','木','风','火'][r[0]],mode:r[1]===0?'points':'attack',value:r[2]}))}:{}),...(p[9]?{elementStarCount:p[9].length}:{})};}
  function decode(raw,data){
    const {packet:p}=read(raw);if(p[1]!==data.sourceSha256.slice(0,16))throw new Error('方案数据版本不同，请更新App后导入');
    const elements=data.elements.flatMap(e=>e.options.map(o=>o.key)),talents=new Set(data.talents.map(t=>t.id));
    if(p[3]>data.maxCapacity||p[6].some(id=>!talents.has(id))||p[7].some(i=>i>=elements.length))throw new Error('方案包含当前数据没有的目标');
    const custom=(p[8]||[]).map(r=>{const e=data.elements[r[0]];if(!e||e.options.some(o=>p[7].some(i=>elements[i]===o.key)))throw new Error('元素自定义目标冲突');return {key:e.key,mode:r[1]===0?'points':'attack',value:r[2]};});
    const stars=(p[9]||[]).map(s=>{const e=data.elements.find(e=>e.starIds.includes(s[0])),nodes=data.nodes.filter(n=>n.starId===s[0]).sort((a,b)=>(a.row||a.id)-(b.row||b.id));if(!e||s[1].length!==nodes.length||s[1].some((lv,i)=>lv>nodes[i].values.length)||custom.some(r=>r.key===e.key)||e.options.some(o=>p[7].some(i=>elements[i]===o.key)))throw new Error('元素星宿等级无效或目标冲突');return {starId:s[0],levels:s[1]};});
    const pvp=p[10]?pvpRules().normalize({preset:pvpRules().presets[p[10][0]].key,attrIds:p[10][1],weights:p[0]===5?Object.fromEntries(pvpRules().attributes.map((a,i)=>[a.id,p[11][i]/100])):undefined}):null;
    return {budget:String(p[2]),capacity:String(p[3]),strategy:rules[p[4]],critTarget:p[4]===3?String(p[5]):'',selected:p[6],elements:p[7].map(i=>elements[i]),source:data.sourceSha256,...(pvp?{pvp}:{}),...(custom.length?{elementRules:custom}:{}),...(stars.length?{elementStars:stars}:{})};
  }
  const api={encode,decode,inspect};if(typeof module!=='undefined')module.exports=api;else root.ShareCodec=api;
})(globalThis);
