/* MDUI交互与原有计算控制器衔接；界面控件的状态由组件自身管理。 */
(() => {
  'use strict';
  mdui.setTheme('light');
  const stack=[],labeled=new WeakSet(),mounted=new WeakSet();
  const dialog=customElements.get('mdui-dialog'),select=customElements.get('mdui-select'),collapse=customElements.get('mdui-collapse-item');
  for(const tag of ['mdui-text-field','mdui-select']){
    const prototype=customElements.get(tag).prototype,property=Object.getOwnPropertyDescriptor(prototype,'value');
    Object.defineProperty(prototype,'value',{configurable:true,get(){return property.get.call(this);},set(value){property.set.call(this,this.multiple&&Array.isArray(value)?value.map(String):String(value??''));}});
  }
  dialog.prototype.showModal=function(){this.open=true;};dialog.prototype.close=function(){this.open=false;};
  Object.defineProperty(select.prototype,'options',{get(){return this.querySelectorAll('mdui-menu-item');}});
  Object.defineProperty(select.prototype,'selectedOptions',{get(){return [...this.options].filter(item=>item.value===this.value);}});
  function mount(item){
    if(!item.parentElement)return null;
    let group=item.parentElement;
    if(group.localName!=='mdui-collapse'){const parent=item.parentElement,next=item.nextSibling;group=document.createElement('mdui-collapse');group.className='collapse-shell';group.accordion=true;group.value=item.hasAttribute('open')?'panel':'';group.append(item);parent.insertBefore(group,next);}
    group.accordion=true;if(!item.value)item.value='panel';
    if(!mounted.has(item)){mounted.add(item);group.addEventListener('click',event=>{if(event.target.closest('mdui-collapse-item')===item&&event.composedPath().some(node=>node.part?.contains('header')))event.stopPropagation();});}
    return group;
  }
  Object.defineProperty(collapse.prototype,'open',{get(){return this.hasAttribute('open');},set(value){this.toggleAttribute('open',!!value);const group=mount(this);if(group)Promise.resolve(this.updateComplete).then(()=>{if(this.isConnected)group.value=this.hasAttribute('open')?this.value:'';});}});
  const svg=(path,slot)=>{const icon=document.createElementNS('http://www.w3.org/2000/svg','svg');icon.setAttribute('viewBox','0 0 24 24');icon.setAttribute('aria-hidden','true');icon.setAttribute('slot',slot);const shape=document.createElementNS(icon.namespaceURI,'path');shape.setAttribute('d',path);icon.append(shape);return icon;};
  function closeMenu(){const root=stack.filter(node=>node.open).at(-1)||document;for(const node of root.querySelectorAll('mdui-select,mdui-dropdown.profile-manage')){const dropdown=node.localName==='mdui-dropdown'?node:node.shadowRoot?.querySelector('mdui-dropdown');if(dropdown?.open&&node.getClientRects().length){dropdown.open=false;return true;}}return false;}
  function syncColors(){document.querySelectorAll('[data-color-field]').forEach(button=>{const value=document.getElementById(button.dataset.colorField).value;button.style.setProperty('--swatch',value);button.querySelector('span').textContent=value.toUpperCase();});}
  function enhance(root){
    for(const item of [root,...root.querySelectorAll?.('mdui-collapse-item')||[]])if(item.localName==='mdui-collapse-item'){
      mount(item);const heading=item.querySelector(':scope>[slot=header]');
      if(heading&&!heading.querySelector('[slot=end-icon]'))heading.append(svg('m7 10 5 5 5-5','end-icon'));
      heading?.setAttribute('aria-expanded',String(item.open));
    }
    for(const control of [root,...root.querySelectorAll?.('mdui-button,mdui-button-icon,mdui-text-field,mdui-checkbox,mdui-switch,mdui-radio,mdui-select')||[]]){
      if(!control.localName?.startsWith('mdui-')||labeled.has(control))continue;labeled.add(control);
      if(control.localName==='mdui-select'&&!control.querySelector('[slot=end-icon]'))control.append(svg('m7 10 5 5 5-5','end-icon'));
      Promise.resolve(control.updateComplete).then(()=>{const label=control.getAttribute('aria-label');if(label)control.shadowRoot?.querySelector('button,input,textarea,[role=combobox]')?.setAttribute('aria-label',label);});
    }
  }
  document.addEventListener('open',event=>{
    if(event.target.localName==='mdui-dialog'){document.querySelectorAll('mdui-select').forEach(control=>{const dropdown=control.shadowRoot?.querySelector('mdui-dropdown');if(dropdown)dropdown.open=false;});const index=stack.indexOf(event.target);if(index>=0)stack.splice(index,1);stack.push(event.target);}
    else if(event.target.localName==='mdui-collapse-item'){const item=event.target;item.setAttribute('open','');item.querySelector(':scope>[slot=header]')?.setAttribute('aria-expanded','true');item.dispatchEvent(new Event('toggle',{bubbles:true}));}
  });
  document.addEventListener('close',event=>{if(event.target.localName==='mdui-collapse-item'){event.target.removeAttribute('open');event.target.querySelector(':scope>[slot=header]')?.setAttribute('aria-expanded','false');event.target.dispatchEvent(new Event('toggle',{bubbles:true}));}});
  document.addEventListener('closed',event=>{if(event.target.localName==='mdui-dialog'){const index=stack.indexOf(event.target);if(index>=0)stack.splice(index,1);}});
  document.addEventListener('keydown',event=>{if(event.key!=='Escape')return;if(closeMenu()){event.preventDefault();event.stopImmediatePropagation();return;}const active=stack.filter(node=>node.open).at(-1);if(!active)return;const cancel=new Event('cancel',{cancelable:true});if(active.dispatchEvent(cancel))active.close();event.preventDefault();event.stopImmediatePropagation();},true);
  document.addEventListener('click',event=>{
    const label=event.target.closest('label');if(!label||event.target.closest('a,button,input,select,textarea,mdui-list-item,mdui-checkbox,mdui-radio,mdui-switch,mdui-button,mdui-button-icon,mdui-text-field,mdui-select,mdui-slider'))return;
    const control=label.querySelector('mdui-checkbox,mdui-switch');if(control&&!control.disabled){event.preventDefault();control.checked=!control.checked;control.dispatchEvent(new Event('change',{bubbles:true,composed:true}));control.focus();}
    else if(label.htmlFor){const field=document.getElementById(label.htmlFor);if(field?.localName.startsWith('mdui-')){event.preventDefault();field.focus();}}
  });
  document.addEventListener('change',event=>{
    const group=event.target;
    if(group.localName==='mdui-tabs'&&group.classList.contains('mutation-tabs')){const item=[...group.querySelectorAll('mdui-tab')].find(item=>item.value===group.value);if(item&&item.getAttribute('aria-pressed')!=='true')item.click();}
    if(group.localName==='mdui-segmented-button-group'){const item=[...group.querySelectorAll('mdui-segmented-button')].find(item=>item.value===group.value);if(item&&item.getAttribute('aria-pressed')!=='true')item.click();}
    if(group.localName==='mdui-navigation-bar'&&group.value){const page=document.body.dataset.page,section=['compare','collection','community'].includes(page)?page:'home';if(group.value!==section)globalThis.PlannerApp?.route(group.value);}
    if(group.localName==='mdui-tabs'&&group.id==='tool-nav'&&group.value!==document.body.dataset.page)globalThis.PlannerApp?.route(group.value);
  });
  globalThis.AppUI={closeMenu,syncColors,validateForm(form){return [...form.querySelectorAll('mdui-text-field,mdui-select')].every(field=>field.reportValidity())&&form.reportValidity();},sync(){
    const page=document.body.dataset.page||'home',section=['compare','collection','community'].includes(page)?page:'home';
    const navigation=document.querySelector('mdui-navigation-bar');if(navigation)navigation.value=section;
    document.querySelectorAll('[data-app-nav]').forEach(item=>item.setAttribute('aria-current',item.dataset.appNav===section?'page':'false'));
    document.querySelectorAll('.sidebar-tools [data-go]').forEach(item=>item.active=item.dataset.go===page||item.dataset.go==='config'&&['result','guide'].includes(page));
    document.querySelectorAll('[data-personal-nav]').forEach(item=>item.active=item.dataset.personalNav===page);
  }};
  document.addEventListener('DOMContentLoaded',()=>{
    document.querySelectorAll('label[for]').forEach(label=>{const control=document.getElementById(label.htmlFor);if(!['mdui-text-field','mdui-select'].includes(control?.localName)||control.label)return;const text=label.querySelector('.sr-only')?.textContent.trim()||[...label.childNodes].filter(node=>node.nodeType===Node.TEXT_NODE).map(node=>node.textContent).join('').trim();if(label.classList.contains('sr-only')||label.querySelector('.sr-only')||getComputedStyle(label).display==='none')control.label=text;else if(!control.hasAttribute('aria-label'))control.setAttribute('aria-label',text);});
    document.querySelectorAll('input[type=color],input[type=file]:not(.hidden)').forEach(input=>{
      if(!input.id||input.classList.contains('hidden'))return;const color=input.type==='color',button=document.createElement('mdui-button');button.variant='outlined';
      if(color){button.dataset.colorField=input.id;button.className='color-picker';button.append(document.createElement('span'));button.setAttribute('aria-label',input.closest('label')?.textContent.trim()||'选择颜色');}
      else button.textContent='添加截图';button.addEventListener('click',()=>input.click());input.classList.add('sr-only');input.tabIndex=-1;input.after(button);
    });
    syncColors();enhance(document.body);
    new MutationObserver(records=>{const selects=new Set();for(const record of records){if(record.type==='attributes'){const item=record.target;if(['mdui-tab','mdui-segmented-button'].includes(item.localName)&&item.getAttribute('aria-pressed')==='true'){const group=item.closest('mdui-tabs,mdui-segmented-button-group');if(group)group.value=item.value;}continue;}const select=record.target.closest?.('mdui-select');if(select)selects.add(select);for(const node of record.addedNodes)if(node.nodeType===1)enhance(node);}for(const select of selects){if(!select.querySelector('[slot=end-icon]'))select.append(svg('m7 10 5 5 5-5','end-icon'));select.requestUpdate();}}).observe(document.body,{subtree:true,childList:true,attributes:true,attributeFilter:['aria-pressed']});
    document.querySelectorAll('mdui-select').forEach(control=>{if(!control.value&&!control.hasAttribute('value'))control.value=control.options[0]?.value||'';});
    new MutationObserver(()=>AppUI.sync()).observe(document.body,{attributes:true,attributeFilter:['data-page']});AppUI.sync();
    const back=globalThis.handlePlannerBack;if(back)globalThis.handlePlannerBack=()=>closeMenu()||back();
    const size=()=>{const picker=document.getElementById('picker');if(picker)picker.fullscreen=innerWidth<600;};size();addEventListener('resize',size);document.body.classList.add('ui-ready');
  });
})();
