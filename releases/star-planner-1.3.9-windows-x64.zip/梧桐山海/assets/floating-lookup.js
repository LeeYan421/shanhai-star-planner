/* MDUI下拉菜单直接在悬浮WebView内显示，保留原生键盘和窗口高度契约。 */
(() => {
  'use strict';
  if(document.body.dataset.floating!=='mutation')return;
  let nativeFocus=false,frame,lastHeight=0;
  document.addEventListener('focusin',event=>{if(!nativeFocus&&event.target.id==='mutation-query'&&typeof globalThis.MutationOverlay?.requestKeyboard==='function')MutationOverlay.requestKeyboard();});
  globalThis.handleFloatingLookupBack=()=>AppUI.closeMenu()||(document.body.dataset.page==='collection'?handlePlannerBack():MutationTool.back());
  globalThis.focusFloatingMutationSearch=()=>{AppUI.closeMenu();MutationTool.back();nativeFocus=true;document.getElementById('mutation-query').focus({preventScroll:true});nativeFocus=false;return true;};
  const overlay=globalThis.MutationOverlay;
  document.getElementById('lookup-input').classList.toggle('hidden',!overlay);
  document.getElementById('lookup-input').onclick=()=>overlay?.toggleInput();
  document.getElementById('lookup-minimize').onclick=()=>overlay?overlay.windowAction('minimize'):AndroidPlanner.windowAction('minimize');
  document.getElementById('lookup-close').onclick=()=>overlay?overlay.windowAction('close'):AndroidPlanner.windowAction('close');
  let moved=false;
  document.getElementById('lookup-bubble').onclick=()=>{if(!moved)overlay?.windowAction('restore');};
  globalThis.setLookupMini=value=>{document.body.classList.toggle('lookup-mini',!!value);document.getElementById('lookup-bubble').classList.toggle('hidden',!value);if(!value)document.body.classList.remove('edge-hidden');};
  globalThis.setLookupDock=(left,hidden)=>{document.body.dataset.edge=left?'left':'right';document.body.classList.toggle('edge-hidden',!!hidden);};
  globalThis.setLookupInputMode=value=>{document.getElementById('lookup-input').textContent=value?'完成':'输入';};
  if(globalThis.DesktopHost)for(const handle of [document.getElementById('lookup-drag'),document.getElementById('lookup-bubble')]){let start;handle.addEventListener('pointerdown',event=>{start={x:event.screenX,y:event.screenY};moved=false;handle.setPointerCapture(event.pointerId);});handle.addEventListener('pointermove',event=>{if(!start)return;const dx=event.screenX-start.x,dy=event.screenY-start.y;if(Math.abs(dx)+Math.abs(dy)>6)moved=true;if(moved){if(overlay)overlay.dragWindow(dx,dy,false);else AndroidPlanner.dragGuideWindow?.(dx,dy,false);}});const end=()=>{if(start&&moved){if(overlay)overlay.dragWindow(0,0,true);else AndroidPlanner.dragGuideWindow?.(0,0,true);}start=null;};handle.addEventListener('pointerup',end);handle.addEventListener('pointercancel',end);}
  function reportHeight(){cancelAnimationFrame(frame);frame=requestAnimationFrame(()=>{
    if(document.getElementById('mutation-content').classList.contains('hidden'))return;
    const main=document.getElementById('main'),view=main.querySelector('.view:not(.hidden)');if(!view||main.clientWidth<100)return;
    const modal=document.getElementById('mutation-detail').open||[...document.querySelectorAll('mdui-select')].some(n=>n.shadowRoot?.querySelector('mdui-dropdown')?.open);
    if(modal||document.body.classList.contains('lookup-mini'))return;
    const height=Math.max(180,Math.min(552,Math.ceil(view.getBoundingClientRect().height)+16));
    if(height!==lastHeight&&typeof globalThis.MutationOverlay?.reportContentHeight==='function'){lastHeight=height;MutationOverlay.reportContentHeight(height);}
  });}
  if(globalThis.ResizeObserver)document.querySelectorAll('#main>.view').forEach(view=>new ResizeObserver(reportHeight).observe(view));
  else new MutationObserver(reportHeight).observe(document.getElementById('mutation-view'),{subtree:true,childList:true});
  document.addEventListener('open',reportHeight);document.addEventListener('closed',reportHeight);window.addEventListener('resize',reportHeight);reportHeight();
})();
