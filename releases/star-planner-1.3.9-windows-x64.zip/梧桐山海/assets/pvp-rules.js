/* PVP预设表达属性取向；自填权重只调整属性分配比例，不代表战斗公式。 */
(function(root){
  'use strict';
  function createPvpRules(){
    const attributes=[
      {id:2012,name:'攻击',hint:'输出基础；收益还受技能倍率、增伤和对手减免影响。'},
      {id:2016,name:'防御穿透',hint:'结合对手防御判断；不把超过有效防御的穿透视为额外增伤。'},
      {id:2018,name:'暴击',hint:'结合对手韧性和可暴击伤害占比判断；暴击值不等于暴击率。'},
      {id:2050,name:'追加伤害',hint:'多段输出可重点关注；实际触发和结算仍取决于技能与对手。'},
      {id:2001,name:'生命',hint:'提高承伤空间；与恢复、减伤的配合取决于实际配置。'},
      {id:2014,name:'防御',hint:'结合对手穿透判断；面板增长不等于同比例减伤。'},
      {id:2021,name:'韧性',hint:'应对暴击类压力；收益取决于对手暴击与伤害组成。'},
      {id:2051,name:'抵挡伤害',hint:'应对多段伤害可重点关注；不能换算为固定百分比免伤。'}
    ];
    const presets=[
      {key:'tough-crit',name:'韧暴流',attrIds:[2018,2021],hint:'生命保障后兼顾韧性与暴击；结合对手暴击和韧性调整。'},
      {key:'attack-defense',name:'攻防流',attrIds:[2012,2014],hint:'生命保障后兼顾攻击与防御；结合双方穿透判断收益。'},
      {key:'crit-defense',name:'暴防流',attrIds:[2018,2014],hint:'生命保障后兼顾暴击与防御；结合对手韧性和穿透调整。'},
      {key:'custom',name:'自选属性',attrIds:[],hint:'勾选本套方案需要兼顾的属性。'}
    ];
    function normalize(value){
      if(!value||!presets.some(p=>p.key===value.preset)||!Array.isArray(value.attrIds)||!value.attrIds.length||value.attrIds.length>attributes.length||new Set(value.attrIds).size!==value.attrIds.length||value.attrIds.some(id=>!attributes.some(a=>a.id===id)))throw new Error('PVP属性至少选择一项，且不能重复或包含未知属性');
      const attrIds=attributes.filter(a=>value.attrIds.includes(a.id)).map(a=>a.id),preset=presets.find(p=>p.key===value.preset);
      const raw=value.weights===undefined?{}:value.weights;
      if(!raw||typeof raw!=='object'||Array.isArray(raw)||Object.keys(raw).some(id=>!attributes.some(a=>String(a.id)===id)))throw new Error('PVP权重包含未知属性');
      const weights={};
      for(const a of attributes){const weight=raw[a.id]===undefined?1:raw[a.id];if(typeof weight!=='number'||!Number.isFinite(weight)||weight<0||weight>100||Number(weight.toFixed(2))!==weight)throw new Error('PVP权重需为0～100的数字，最多两位小数');weights[a.id]=weight;}
      if(!attrIds.some(id=>weights[id]>0))throw new Error('至少一项已选PVP属性的权重大于0');
      return {preset:preset.attrIds.length===attrIds.length&&preset.attrIds.every(id=>attrIds.includes(id))?preset.key:'custom',attrIds,weights};
    }
    const label=value=>{const p=normalize(value);return presets.find(x=>x.key===p.preset).name+' · '+attributes.filter(a=>p.attrIds.includes(a.id)).map(a=>a.name+'×'+p.weights[a.id]).join('、');};
    return {attributes,presets,normalize,label,defaults:()=>normalize({preset:'tough-crit',attrIds:[2018,2021]})};
  }
  if(typeof module!=='undefined'&&module.exports)module.exports={createPvpRules};
  root.createPvpRules=createPvpRules;
})(globalThis);
