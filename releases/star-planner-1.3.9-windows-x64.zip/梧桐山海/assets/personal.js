/* 收藏与最近查询共用本机数据；对比只接受当前配置实际求出的完整解。 */
(() => {
  'use strict';
  const $=id=>document.getElementById(id),app=PlannerApp,core=PersonalCore,data=STAR_DATA,collections=core.createCollections(localStorage),cache=new Map();
  const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let collectionTab='favorites',pendingBackup=null,task=null,sequence=0;
  function openCollections(){
    const list=collections.read()[collectionTab];$('collection-count').textContent=list.length+'项';$('collection-clear').classList.toggle('hidden',collectionTab!=='recent'||!list.length);
    document.querySelectorAll('[data-collection-tab]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.collectionTab===collectionTab)));
    $('collection-list').innerHTML=list.length?list.map((item,i)=>`<mdui-card class="personal-item" variant="filled"><mdui-button data-open-collection="${i}" variant="text"><strong>${esc(item.title)}</strong><small>${esc(item.subtitle)}</small></mdui-button><mdui-button class="text-button" data-star-collection="${i}" aria-pressed="${collections.has(item)}" aria-label="${collections.has(item)?'取消收藏':'收藏'}${esc(item.title)}" variant="text">${collections.has(item)?'已收藏':'收藏'}</mdui-button></mdui-card>`).join(''):`<p class="personal-empty">${collectionTab==='favorites'?'在速查详情或筛选栏点击收藏。':'查看部位、特质或搜索后，记录会保存在这里。'}</p>`;
  }
  document.querySelectorAll('[data-collection-tab]').forEach(b=>b.addEventListener('click',()=>{collectionTab=b.dataset.collectionTab;openCollections();}));
  $('collection-list').addEventListener('click',async e=>{const b=e.target.closest('[data-open-collection],[data-star-collection]');if(!b)return;const index=Number(b.dataset.openCollection??b.dataset.starCollection),item=collections.read()[collectionTab][index];if(!item)return;try{if(b.dataset.openCollection!==undefined)await MutationTool.restore(item);else{collections.toggle(item);openCollections();}}catch(error){app.toast(error.message);}});
  $('collection-clear').addEventListener('click',()=>{try{collections.clearRecent();openCollections();}catch{app.toast('记录未能清空');}});
  window.addEventListener('storage',e=>{if(e.key==='wutong-collections-v1'&&document.body.dataset.page==='collection')openCollections();});
  function openCompare(){
    const plans=app.listPlans();
    for(const id of ['compare-a','compare-b']){const selected=$(id).value;$(id).innerHTML='<mdui-menu-item value="">选择方案</mdui-menu-item>'+plans.map(p=>`<mdui-menu-item value="${esc(p.id)}">${esc(p.name)}</mdui-menu-item>`).join('');if(plans.some(p=>p.id===selected))$(id).value=selected;}
    if(!$('compare-a').value&&plans.length)$('compare-a').value=plans[0].id;
    if(!$('compare-b').value&&plans.length>1)$('compare-b').value=plans[1].id;
    $('compare-run').disabled=plans.length<2;$('compare-status').textContent=plans.length<2?'先在星宿配置中另存两套方案。':'';$('compare-result').replaceChildren();
  }
  function cancel(){sequence++;task?.cancel();task=null;$('compare-run').disabled=app.listPlans().length<2;$('compare-cancel').classList.add('hidden');}
  $('compare-cancel').addEventListener('click',()=>{cancel();$('compare-status').textContent='已取消，方案未改动';});
  for(const id of ['compare-a','compare-b'])$(id).addEventListener('change',()=>{cancel();$('compare-result').replaceChildren();$('compare-status').textContent='';});
  document.addEventListener('planner-result-ready',e=>{if(e.detail.id&&e.detail.result.status==='optimal')cache.set(e.detail.id,{signature:core.configSignature(e.detail.config),result:e.detail.result});});
  $('compare-run').addEventListener('click',async()=>{
    const plans=app.listPlans(),pair=[$('compare-a').value,$('compare-b').value].map(id=>plans.find(p=>p.id===id));
    if(pair.some(p=>!p)||pair[0].id===pair[1].id){app.toast('请选择两套不同方案');return;}
    const current=++sequence;$('compare-run').disabled=true;$('compare-cancel').classList.remove('hidden');$('compare-result').replaceChildren();
    try{
      const results=[];
      for(const plan of pair){
        const signature=core.configSignature(plan.config),saved=cache.get(plan.id);let result=saved?.signature===signature?saved.result:null;
        if(!result){$('compare-status').textContent='正在计算：'+plan.name;task=solveOfflinePlan(data,plan.config,p=>{if(current===sequence)$('compare-status').textContent='正在计算：'+plan.name+' '+p+'%';});result=await task.promise;if(current!==sequence)return;if(result.status!=='optimal')throw new Error(plan.name+'点数不足，至少需要'+result.minimumCost+'点');cache.set(plan.id,{signature,result});}
        results.push(result);
      }
      if(current!==sequence)return;
      const actual=app.listPlans();if(pair.some(p=>core.configSignature(actual.find(x=>x.id===p.id)?.config||{})!==core.configSignature(p.config)))throw new Error('方案已变化，请重新对比');
      renderComparison(pair,results);$('compare-status').textContent='';
    }catch(e){if(current===sequence)$('compare-status').textContent=e.message;}finally{if(current===sequence){task=null;$('compare-run').disabled=false;$('compare-cancel').classList.add('hidden');}}
  });
  function renderComparison(plans,results){
    const summaries=results.map(r=>core.comparisonSummary(r,data)),stars=new Map(data.stars.map(s=>[s.id,s]));
    // 对比涉及PVP方案时同时列出生命、韧性等全部节点属性，避免仅看攻穿暴击。
    if(results.some(r=>r.pvpResult))summaries.forEach((s,i)=>{for(const a of createPvpRules().attributes)s['pvp'+a.id]=data.nodes.reduce((sum,n)=>sum+(n.attrId===a.id&&results[i].levels[n.id]?n.values[results[i].levels[n.id]-1]:0),0);});
    const metrics=results.some(r=>r.pvpResult)?[...createPvpRules().attributes.map(a=>[a.name,'pvp'+a.id]),['战力参考','power'],['投入点数','spent'],['携带费用','fees']]:[['暴击','crit'],['攻击','attack'],['穿透','penetration'],['战力参考','power'],['投入点数','spent'],['携带费用','fees']];
    const fmt=n=>Number(n).toLocaleString('zh-CN'),delta=n=>(n>0?'+':'')+fmt(n);
    const header=`<thead><tr><th>属性</th><th>${esc(plans[0].name)}<small>A</small></th><th>${esc(plans[1].name)}<small>B</small></th><th>B − A</th></tr></thead>`;
    const diffs=data.nodes.filter(n=>(results[0].levels[n.id]||0)!==(results[1].levels[n.id]||0));
    const talents=results.map(r=>new Set(r.targetIds));
    const talentName=id=>{const t=data.talents.find(t=>t.id===id),s=stars.get(t.starId);return s.weapon+' · '+s.name+' · '+({3:'绿',4:'紫',5:'红'}[t.quality]);};
    $('compare-result').innerHTML=`<table class="compare-table"><caption>收益对比</caption>${header}<tbody>${metrics.map(([name,key])=>{const d=summaries[1][key]-summaries[0][key];return `<tr><th scope="row">${name}</th><td>${fmt(summaries[0][key])}</td><td>${fmt(summaries[1][key])}</td><td class="${d>0?'positive':d<0?'negative':''}">${delta(d)}</td></tr>`;}).join('')}</tbody></table><p class="hint">均为星宿增量；战力统一计入节点与满级携带天赋。差值为B减A。</p><mdui-card class="card compare-talents" variant="filled"><h2>携带天赋差异</h2>${[0,1].map(i=>`<p><strong>仅${i?'B':'A'}携带：</strong>${[...talents[i]].filter(id=>!talents[1-i].has(id)).map(id=>esc(talentName(id))).join('；')||'无'}</p>`).join('')}<p><strong>元素目标：</strong>${plans.map((p,i)=>(i?'B':'A')+' '+esc(data.elements.flatMap(e=>e.options).filter(o=>p.config.elements.includes(o.key)).map(o=>o.name).concat((p.config.elementRules||[]).map(r=>createElementRules(data).label(r))).concat(createElementRules(data).summarizeStars(p.config.elementStars||[]).map(createElementRules(data).starLabel)).join('、')||'未选')).join('<br>')}</p></mdui-card><mdui-collapse accordion="" class="collapse-shell" value=""><mdui-collapse-item value="panel" class="compact-details"><mdui-list-item slot="header" class="collapse-heading"><h2>加点差异 · ${diffs.length}行</h2></mdui-list-item><div class="detail-content">${diffs.map(n=>{const s=stars.get(n.starId);return `<mdui-card class="personal-item" variant="filled"><div class="compare-talents"><strong>${esc(s.weapon+' · '+s.name+' · 第'+n.row+'行 '+n.attribute)}</strong><p>${esc(s.location)} A Lv${results[0].levels[n.id]||0} → B Lv${results[1].levels[n.id]||0}</p></div></mdui-card>`;}).join('')||'<p class="hint">两套方案的节点等级相同。</p>'}</div></mdui-collapse-item></mdui-collapse>`;
  }
  $('backup-export').addEventListener('click',()=>{
    try{const raw=app.backup();core.parseBackup(raw,data);if(typeof globalThis.AndroidPlanner?.exportBackup==='function'){AndroidPlanner.exportBackup(raw);return;}const url=URL.createObjectURL(new Blob([raw],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download='梧桐山海-星宿备份-'+new Date().toISOString().slice(0,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);}catch(e){app.toast(e.message);}
  });
  $('backup-import').addEventListener('click',()=>$('backup-file').click());
  $('backup-file').addEventListener('change',async()=>{
    const file=$('backup-file').files[0];$('backup-file').value='';if(!file)return;
    try{if(file.size>2000000)throw new Error('备份文件不能超过2MB');pendingBackup=core.parseBackup(await file.text(),data);$('backup-preview-body').innerHTML=`<p>${pendingBackup.plans.length}套方案${pendingBackup.draft?'，含未命名草稿':''}</p><ul>${pendingBackup.plans.map(p=>`<li>${esc(p.name)} · ${esc(p.config.budget||'未填')}点</li>`).join('')}</ul>${pendingBackup.source!==data.sourceSha256?'<p class="error">备份数据版本不同；导入后重新计算，原加点进度不迁入。</p>':''}`;$('backup-preview').showModal();}catch(e){pendingBackup=null;app.toast(e.message);}
  });
  $('backup-confirm').addEventListener('click',()=>{if(!pendingBackup)return;try{const result=app.importBackup(pendingBackup);pendingBackup=null;$('backup-preview').close();openCompare();app.toast('已导入'+result.added+'套，跳过'+result.skipped+'套相同方案');}catch(e){app.toast(e.message);}});
  document.addEventListener('click',e=>{const b=e.target.closest('[data-close-personal]');if(b)$(b.dataset.closePersonal).close();});
  globalThis.PersonalUI={openCollections,openCompare,leave:cancel,back(){if($('backup-preview').open){$('backup-preview').close();pendingBackup=null;return true;}return false;}};
})();
