/* 页面与计算线程共用基础兼容能力，已有原生实现保持不变。 */
(function(root){
  'use strict';
  function installWebViewCompat(){
    'use strict';
    if(!Array.prototype.at)Object.defineProperty(Array.prototype,'at',{configurable:true,writable:true,value:function(index){
      if(this==null)throw new TypeError('数组不能为空');
      const object=Object(this),length=Math.min(Math.max(Math.trunc(+object.length)||0,0),Number.MAX_SAFE_INTEGER);
      let offset=Math.trunc(+index)||0;if(offset<0)offset+=length;
      return offset<0||offset>=length?undefined:object[offset];
    }});
    if(globalThis.crypto&&!crypto.randomUUID)Object.defineProperty(crypto,'randomUUID',{configurable:true,writable:true,value:function(){
      const bytes=crypto.getRandomValues(new Uint8Array(16));bytes[6]=bytes[6]&15|64;bytes[8]=bytes[8]&63|128;
      const hex=Array.from(bytes,value=>value.toString(16).padStart(2,'0'));
      return hex.slice(0,4).join('')+'-'+hex.slice(4,6).join('')+'-'+hex.slice(6,8).join('')+'-'+hex.slice(8,10).join('')+'-'+hex.slice(10).join('');
    }});
    if(typeof Element==='undefined')return;
    for(const prototype of [Element.prototype,DocumentFragment.prototype])if(!prototype.replaceChildren)Object.defineProperty(prototype,'replaceChildren',{configurable:true,writable:true,value:function(...nodes){
      const fragment=this.ownerDocument.createDocumentFragment();fragment.append(...nodes);this.textContent='';this.appendChild(fragment);
    }});
    // 记录脚本启动的动画，使弹窗切换能在旧内核中取消尚未结束的动画。
    if(!Element.prototype.getAnimations){
      const animate=Element.prototype.animate,animations=new WeakMap();
      Element.prototype.animate=function(...args){
        const animation=animate.apply(this,args),active=animations.get(this)||new Set();animations.set(this,active);active.add(animation);
        const remove=()=>active.delete(animation);animation.addEventListener('finish',remove,{once:true});animation.addEventListener('cancel',remove,{once:true});return animation;
      };
      Object.defineProperty(Element.prototype,'getAnimations',{configurable:true,writable:true,value:function(){return Array.from(animations.get(this)||[]).filter(animation=>animation.playState!=='finished'&&animation.playState!=='idle');}});
    }
  }
  root.installWebViewCompat=installWebViewCompat;
  installWebViewCompat();
  if(typeof document==='undefined')return;
  document.documentElement.classList.toggle('legacy-focus-visible',!CSS.supports('selector(:focus-visible)'));
  const probe=document.createElement('div');probe.style.cssText='position:absolute;visibility:hidden;display:flex;flex-direction:column;row-gap:1px';
  for(let index=0;index<2;index++){const item=document.createElement('div');item.style.height='1px';probe.appendChild(item);}
  document.body.appendChild(probe);document.documentElement.classList.toggle('legacy-flex-gap',probe.scrollHeight===2);probe.remove();
  if(!CSS.supports('aspect-ratio','1')){
    const size=card=>{const height=card.getBoundingClientRect().width+'px';if(card.style.height!==height)card.style.height=height;};
    const observer=new ResizeObserver(entries=>entries.forEach(entry=>size(entry.target)));
    document.querySelectorAll('.tool-card').forEach(card=>{size(card);observer.observe(card);});
  }
})(globalThis);
