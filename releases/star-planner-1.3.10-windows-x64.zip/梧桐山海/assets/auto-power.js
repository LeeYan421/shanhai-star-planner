/* 节点、账号实际等级天赋与属性取整统一建模，只有证明最优后才输出方案。 */
(function(root){
  'use strict';
  /** 使用主界面提供的内置字节创建实例，计算线程不再读取文件或访问网络。 */
  async function loadOfflineOptimizer(factory,bytes){
    const compiled=await WebAssembly.compile(bytes);
    return factory({instantiateWasm(imports,receive){const instance=new WebAssembly.Instance(compiled,imports);receive(instance,compiled);return instance.exports;}});
  }
  function createAutoPowerEngine(data,createBase,optimizer,createNodeStrategy){
    const base=createBase(data),byId=new Map(data.nodes.map(n=>[n.id,n])),talentLevels=createTalentLevelRules(data);
    const ownNodes=new Map(data.stars.map(s=>[s.id,data.nodes.filter(n=>n.starId===s.id)]));
    const nodeVar=(id,level)=>'n'+id+'L'+level,talentVar=id=>'t'+id;
    function expression(terms){return terms.filter(([value])=>value!==0).map(([value,name])=>(value<0?' - ':' + ')+Math.abs(value)+' '+name).join('').replace(/^ \+ /,'')||'0 '+nodeVar(data.nodes[0].id,1);}
    function solve(input,progress=()=>{}){
      // 自选条目固定携带，其他天赋与节点在剩余容量内联合优化。
      const request={...input,talentIds:input.talentIds===undefined?[]:input.talentIds,strategy:'power'},prep=base.prepare(request),started=Date.now();
      const slotLimit=data.talentPower.baseSlots+data.talentPower.extraSlotRules.filter(r=>request.capacity>=r.cur_max).reduce((s,r)=>s+r.extra_config_limit,0);
      if(prep.targets.length>slotLimit)throw new Error('自选携带数量超过上限'+slotLimit+'项');
      if(request.budget<prep.minimumCost)return {status:'insufficient',minimumCost:prep.minimumCost,deficit:prep.minimumCost-request.budget,fees:prep.fees,budget:request.budget};
      if(!optimizer)throw new Error('本机联合计算组件尚未加载');
      const binary=[],integers=[],bounds=[],constraints=[],objective=[],spend=[],attributes=new Map();
      function constraint(terms,sign,value){constraints.push(' c'+constraints.length+': '+expression(terms)+' '+sign+' '+value);}
      for(const n of data.nodes){
        n.values.forEach((value,i)=>{
          const name=nodeVar(n.id,i+1),gain=value-(i?n.values[i-1]:0);
          if(!Number.isSafeInteger(gain)||!Number.isSafeInteger(n.costs[i]))throw new Error('节点数值超出精确计分范围');
          binary.push(name);spend.push([n.costs[i],name]);
          if(!attributes.has(n.attrId))attributes.set(n.attrId,[]);attributes.get(n.attrId).push([gain,name]);
          if(i)constraint([[1,name],[-1,nodeVar(n.id,i)]],'<=',0);
        });
        for(const id of n.pre)constraint([[1,nodeVar(n.id,1)],[-1,nodeVar(id,1)]],'<=',0);
        if(prep.required.has(n.id))constraint([[1,nodeVar(n.id,prep.required.get(n.id))]],'=',1);
      }
      constraint(spend,'<=',request.budget);
      const bonuses=new Map();
      for(const t of data.talents){
        if(!Array.isArray(t.power)||t.power.length!==t.effects.length||!t.power.every(v=>Number.isSafeInteger(v)&&v>=0)||!ownNodes.get(t.starId)?.length)throw new Error('天赋战力配置缺失');
        const score=t.power[talentLevels.level(t.id,prep.talentLevels)-1],name=talentVar(t.id);binary.push(name);bonuses.set(t.id,score);objective.push([score,name]);
        for(const n of ownNodes.get(t.starId)||[]){if(t.requiredLevel>n.values.length)throw new Error('天赋解锁等级异常');constraint([[1,name],[-1,nodeVar(n.id,t.requiredLevel)]],'<=',0);}
      }
      const carryRows=[],carryTerms=data.talents.map(t=>[bonuses.get(t.id),talentVar(t.id)]);
      for(const t of prep.targets){constraint([[1,talentVar(t.id)]],'=',1);carryRows.push(constraints.at(-1));}
      constraint(data.talents.map(t=>[t.cost,talentVar(t.id)]),'<=',request.capacity);carryRows.push(constraints.at(-1));
      constraint(data.talents.map(t=>[1,talentVar(t.id)]),'<=',slotLimit);carryRows.push(constraints.at(-1));
      for(let i=0;i<data.talents.length;i++)for(let j=i+1;j<data.talents.length;j++){
        const a=data.talents[i],b=data.talents[j];if(data.conflicts.some(c=>(c.id===a.conflictGroup&&c.exclusive_group.includes(b.conflictGroup))||(c.id===b.conflictGroup&&c.exclusive_group.includes(a.conflictGroup)))){constraint([[1,talentVar(a.id)],[1,talentVar(b.id)]],'<=',1);carryRows.push(constraints.at(-1));}
      }
      // 忽略解锁条件先求携带战力上界，再加入联合模型；这是有效约束，不会裁掉合法最优解。
      if(data.talents.length){const carryModel=['Maximize',' bonus: '+expression(carryTerms),'Subject To',...carryRows,'Binaries',data.talents.map(t=>talentVar(t.id)).join(' '),'End'].join('\n');const bound=optimizer.solve(carryModel,{output_flag:false,mip_rel_gap:0,mip_abs_gap:0,time_limit:5});if(bound.Status==='Optimal')constraint(carryTerms,'<=',Math.round(bound.ObjectiveValue));}
      for(const [id,terms]of attributes){
        const p=data.power.parameters[id];if(!p?.length)continue;
        const numerator=p[0],denominator=p.length===1?1:p[1],name='a'+id;
        if(!Number.isSafeInteger(numerator)||!Number.isSafeInteger(denominator)||numerator<0||denominator<=0)throw new Error('属性计分参数无效');
        integers.push(name);objective.push([1,name]);bounds.push(' 0 <= '+name+' <= '+base.resourceScore(p,terms.reduce((s,[v])=>s+v,0)));
        // 整数计分变量不超过原始有理数；最大化目标使其恰好等于同属性合计后的向下取整。
        constraint([[denominator,name],...terms.map(([v,n])=>[-numerator*v,n])],'<=',0);
      }
      // 可分解图沿用原有精确节点求解器给出上界，减少联合模型中的对称搜索。
      const core=new Set(data.core),gates=new Set(data.gates);
      const separable=data.nodes.every(n=>n.pre.every(id=>byId.get(id).starId===n.starId||(core.has(n.id)?core.has(id):gates.has(id))));
      const supported=[...attributes.keys()].every(id=>{const p=data.power.parameters[id];return !p?.length||Number.isSafeInteger(p[0]*100/(p.length===1?1:p[1]));});
      if(createNodeStrategy&&separable&&supported){const upper=createNodeStrategy({...data,talentPower:null},createBase).solve(request,p=>progress(Math.round(p*0.15)));if(upper.status==='optimal')constraint(integers.map(name=>[1,name]),'<=',upper.powerReference);}
      const maximum=objective.reduce((s,[v])=>s+Math.max(0,v),0);if(!Number.isSafeInteger(maximum))throw new Error('总计分超出精确整数范围');
      const model=(direction,terms)=>[direction,' goal: '+expression(terms),'Subject To',...constraints,'Bounds',...bounds,...(integers.length?['Generals',integers.join(' ')]:[]),'Binaries',binary.join(' '),'End'].join('\n');
      const settings={output_flag:false,presolve:'on',mip_rel_gap:0,mip_abs_gap:0,mip_feasibility_tolerance:1e-8,time_limit:120};
      progress(20);
      const first=optimizer.solve(model('Maximize',objective),settings);
      if(first.Status!=='Optimal')throw new Error('联合求解尚未完成，未生成最优方案，可重试或取消');
      const highestScore=Math.round(first.ObjectiveValue);constraint(objective,'=',highestScore);progress(65);
      // 固定最高总战力再最小化耗点，避免大权重影响整数规划的数值条件。
      const solved=optimizer.solve(model('Minimize',spend),settings);
      if(solved.Status!=='Optimal')throw new Error('联合求解尚未完成，未生成最优方案，可重试或取消');
      function integer(name){const value=solved.Columns[name]?.Primal;if(!Number.isFinite(value)||Math.abs(value-Math.round(value))>0.000001)throw new Error('求解结果未通过整数校验');return Math.round(value);}
      const levels=new Map();let spent=0;
      for(const n of data.nodes){let level=0;for(let i=0;i<n.values.length;i++){const active=integer(nodeVar(n.id,i+1));if(active!==0&&active!==1)throw new Error('节点等级状态无效');if(active){if(level!==i)throw new Error('节点升级顺序无效');level++;spent+=n.costs[i];}}if(level)levels.set(n.id,level);}
      const ids=data.talents.filter(t=>integer(talentVar(t.id))===1).map(t=>t.id);
      if(ids.length>slotLimit)throw new Error('携带数量超过上限');
      if(prep.targets.some(t=>!ids.includes(t.id)))throw new Error('求解未保留全部自选天赋');
      const finalRequest={...request,talentIds:ids},finalPrep=base.prepare(finalRequest);base.validate(levels,request.budget,finalPrep);
      const nodeScore=rows=>{const totals=new Map();for(const [id,level]of rows){const n=byId.get(id);totals.set(n.attrId,(totals.get(n.attrId)||0)+n.values[level-1]);}return [...totals].reduce((s,[id,v])=>s+base.resourceScore(data.power.parameters[id],v),0);};
      const talentScore=ids.reduce((s,id)=>s+bonuses.get(id),0),score=nodeScore(levels)+talentScore;
      // 该目标必为整数；先取最近整数消除求解器的浮点尾差，再与独立重算结果严格比较。
      if(score!==highestScore||Math.round(solved.ObjectiveValue)!==spent)throw new Error('联合计分复核不一致');
      const result=base.describe({levels,value:score,cost:spent},finalRequest,finalPrep,Date.now()-started,{evaluate:rows=>nodeScore(rows)+talentScore,description:'虚战优先：节点＋账号实际等级天赋战力最高，同分少耗点'});
      result.nodePowerReference=result.powerReference;result.talentPowerReference=talentScore;result.powerReference=score;result.autoTalents=true;result.carryLimit=slotLimit;
      result.pinnedTalentIds=prep.targets.map(t=>t.id);
      for(const t of result.unlocked){t.power=bonuses.get(t.id);t.pinned=result.pinnedTalentIds.includes(t.id);}
      progress(100);return result;
    }
    return {solve};
  }
  if(typeof module!=='undefined'&&module.exports)module.exports={createAutoPowerEngine,loadOfflineOptimizer};
  root.createAutoPowerEngine=createAutoPowerEngine;
  root.loadOfflineOptimizer=loadOfflineOptimizer;
})(globalThis);
