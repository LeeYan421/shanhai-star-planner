/* 星象与武器徽记来自原创图集；天赋品质由界面边框区分。 */
(function(root){
  'use strict';
  const names=['识海','青龙之魂','朱雀之魂','白虎之魂','玄武之魂','北斗之星','南斗之星','中天之星','飞曜之星'];
  const image=name=>'<img src="icons/account-talents/'+name+'.webp" alt="" draggable="false" decoding="async"/>';
  root.AccountTalentArt={icon:star=>image('star-'+Number(star.id)),family:name=>image('family-'+names.indexOf(name))};
})(globalThis);
