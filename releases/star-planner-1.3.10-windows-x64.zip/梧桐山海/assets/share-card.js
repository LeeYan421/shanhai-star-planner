/* 攻略卡使用实际求解和图鉴记录生成，图片与二维码均在本机绘制。 */
(function(root){
  'use strict';
  const rules={crit:'暴击优先',power:'虚战优先','attack-pen':'攻击穿透','crit-target':'暴击达标后加攻击',pvp:'PVP属性均衡'};
  const download='https://wutong.leeyan.site/download';
  const num=value=>Number(value).toLocaleString('zh-CN');
  function starModel(context,data,code){
    const r=context.result;if(r?.status!=='optimal')throw new Error('先生成完整方案，再制作攻略卡');
    const stars=new Map(data.stars.map(s=>[s.id,s])),selected=r.unlocked.filter(t=>t.selected),automatic=!!r.autoTalents;
    const sections=[{title:automatic?'携带天赋 · 账号实际等级':'目标天赋',rows:selected.map(t=>{const s=stars.get(t.starId);return s.weapon+' · '+s.name+' · '+({3:'绿',4:'紫',5:'红'}[t.quality])+'色 · Lv'+(t.equippedLevel||1)+(automatic?' · '+(t.pinned?'自选':'补充'):'');})}];
    if(!selected.length)sections[0].rows=['未指定武器天赋'];
    if(r.elementTargets.length)sections.push({title:'元素目标',rows:r.elementTargets.map(t=>t.name)});
    if(r.elementRuleResults?.length)sections.push({title:'元素自定义目标',rows:r.elementRuleResults.map(createElementRules(data).resultLabel)});
    if(r.elementStarResults?.length)sections.push({title:'元素逐行等级',rows:r.elementStarResults.map(createElementRules(data).starLabel)});
    if(r.critTarget!==undefined)sections.push({title:'暴击目标',rows:['至少＋'+num(r.critTarget)+'，实际＋'+num(r.crit)]});
    if(r.pvpResult?.life)sections.push({title:'高收益生命优选',rows:['生命 ＋'+num(r.pvpResult.life.value)+' · '+r.pvpResult.life.nodes.length+'个节点',...r.pvpResult.life.nodes.map(n=>n.name+'第'+n.row+'行 · Lv'+n.level)]});
    if(r.pvpResult)sections.push({title:'PVP加权均衡 · 非实战伤害最优',rows:r.pvpResult.attributes.map(a=>a.name+' ×'+(a.weight??1)+' ＋'+num(a.value)+' / '+num(a.maximum)+' · '+(a.ratio===null?'不可达':(a.ratio*100).toFixed(1)+'%'))});
    return {type:'star',title:'星宿加点方案',subtitle:rules[r.strategy]||rules.crit,icon:'icons/stars.png',
      summary:r.spent+' / '+r.budget+'点 · '+r.fees+' / '+r.capacity+'费 · '+r.stars.length+'步',
      metrics:r.pvpResult?r.pvpResult.attributes.slice(0,4).map(a=>({name:a.name,value:'＋'+num(a.value)})):[{name:'暴击',value:'＋'+num(r.crit)},{name:'攻击',value:'＋'+num(r.attack)},{name:'防御穿透',value:'＋'+num(r.penetration)},{name:automatic?'总战力参考':'节点战力参考',value:'＋'+num(r.powerReference)}],sections,
      notes:['暴击为星宿属性增量，不是暴击率。','战力为理论参考，天赋需在游戏中装备。'],url:download+'#p='+code,footer:'扫码查看配置 · 复制方案码',code};
  }
  function partModel(part){
    if(!part||!Number.isFinite(part.attributes?.['攻击'])||!Number.isInteger(part.attackTier))throw new Error('当前部位缺少可分享数值');
    const sections=[{title:'其他候选属性',rows:Object.entries(part.attributes).filter(([name])=>!['攻击','防御穿透'].includes(name)).map(([name,value])=>name+' ＋'+num(value))}];
    if(part.battle.length)sections.push({title:'斗兽特质',rows:part.battle});
    if(part.special.length)sections.push({title:'蜃兽特性候选',rows:part.special});
    return {type:'part',title:part.name+' · '+part.part,subtitle:part.year+' · 变异部位速查',icon:'icons/mutation.png',summary:'同年份档位比较 · 1档最高',
      metrics:[{name:'攻击',value:num(part.attributes['攻击']),note:part.attackTier+'档'},{name:'防御穿透',value:part.pierceTier==null?'—':num(part.attributes['防御穿透']),note:part.pierceTier==null?'':part.pierceTier+'档'}],sections:sections.filter(s=>s.rows.length),
      notes:['候选属性不保证同时获得，缺失数值以“—”表示。','元素数值分别计算，不将四元素相加。'],url:download,footer:'扫码下载 · 游戏内悬浮速查'};
  }
  function lines(ctx,text,width){const rows=[];let line='';for(const c of String(text)){if(c==='\n'){rows.push(line);line='';continue;}if(line&&ctx.measureText(line+c).width>width){rows.push(line);line=c;}else line+=c;}rows.push(line);return rows;}
  function qualityLine(ctx,text,x,y){const colors={'绿色':'#267047','蓝色':'#255f96','紫色':'#7046a1','橙色':'#945008','红色':'#b43f4b'};for(const word of text.split(/(绿色|蓝色|紫色|橙色|红色)/g)){ctx.fillStyle=colors[word]||'#50647e';ctx.fillText(word,x,y);x+=ctx.measureText(word).width;}}
  async function render(canvas,model,makeQr,loadImage){
    const width=1080,pad=64,gap=22,inner=width-pad*2,ctx=canvas.getContext('2d');canvas.width=width;canvas.height=400;
    ctx.font='30px system-ui,sans-serif';
    const sections=model.sections.map(s=>({...s,rows:s.rows.flatMap(text=>lines(ctx,text,inner-64))}));
    ctx.font='bold 54px system-ui,sans-serif';const titleLines=lines(ctx,model.title,inner-135);
    const titleHeight=titleLines.length*68+37,metricRows=Math.ceil(model.metrics.length/2);
    const bodyHeight=sections.reduce((sum,s)=>sum+86+s.rows.length*46+gap,0);
    const height=Math.max(1280,64+95+titleHeight+72+metricRows*176+36+bodyHeight+model.notes.length*40+390);
    if(height>4096)throw new Error('方案内容过长，请使用方案码分享完整配置');
    canvas.height=height;
    const box=(x,y,w,h,fill,r=24)=>{ctx.fillStyle=fill;ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();ctx.fill();};
    ctx.fillStyle='#f1f4f8';ctx.fillRect(0,0,width,height);
    const [logo,tool]=await Promise.all([loadImage('icons/app.png'),loadImage(model.icon)]);
    ctx.drawImage(logo,pad,48,76,76);ctx.fillStyle='#263b56';ctx.font='bold 35px system-ui,sans-serif';ctx.fillText('梧桐山海',pad+95,87);ctx.fillStyle='#75849a';ctx.font='22px system-ui,sans-serif';ctx.fillText('妄想山海 · 玩家工具箱',pad+95,121);
    let y=170;ctx.drawImage(tool,width-pad-100,y-7,100,100);ctx.font='bold 54px system-ui,sans-serif';ctx.fillStyle='#263b56';
    const heading=lines(ctx,model.title,inner-135);for(const line of heading){ctx.fillText(line,pad,y+48);y+=68;}
    ctx.font='30px system-ui,sans-serif';ctx.fillStyle='#3b5f8b';ctx.fillText(model.subtitle,pad,y+33);y+=72;
    ctx.font='25px system-ui,sans-serif';ctx.fillStyle='#74839a';ctx.fillText(model.summary,pad,y+22);y+=52;
    const cellW=(inner-gap)/2;
    for(let i=0;i<model.metrics.length;i++){
      const m=model.metrics[i],x=pad+(i%2)*(cellW+gap),yy=y+Math.floor(i/2)*176;box(x,yy,cellW,154,'#fff');
      ctx.font='27px system-ui,sans-serif';ctx.fillStyle='#6d7e95';ctx.fillText(m.name,x+28,yy+43);
      let size=66;ctx.font='bold '+size+'px system-ui,sans-serif';while(ctx.measureText(m.value).width>cellW-56&&size>35){size-=2;ctx.font='bold '+size+'px system-ui,sans-serif';}
      ctx.fillStyle='#27486f';ctx.fillText(m.value,x+25,yy+116);if(m.note){ctx.font='bold 27px system-ui,sans-serif';ctx.fillStyle='#8b6a2b';const w=ctx.measureText(m.note).width;ctx.fillText(m.note,x+cellW-28-w,yy+43);}
    }
    y+=metricRows*176+10;
    for(const section of sections){const h=86+section.rows.length*46;box(pad,y,inner,h,'#fff');ctx.font='bold 28px system-ui,sans-serif';ctx.fillStyle='#2c4666';ctx.fillText(section.title,pad+30,y+46);ctx.font='30px system-ui,sans-serif';section.rows.forEach((line,i)=>qualityLine(ctx,line,pad+30,y+95+i*46));y+=h+gap;}
    ctx.font='24px system-ui,sans-serif';ctx.fillStyle='#78869a';for(const note of model.notes){for(const line of lines(ctx,note,inner)){ctx.fillText(line,pad,y+30);y+=36;}}y+=34;
    const qr=makeQr(model.url),count=qr.getModuleCount(),scale=Math.floor(280/(count+8)),side=(count+8)*scale,x=width-pad-side-20,yy=Math.max(y,height-340);
    if(scale<2)throw new Error('方案码过长，请复制方案码分享');
    box(pad,yy-15,inner,side+46,'#fff');ctx.fillStyle='#fff';ctx.fillRect(x,yy,side,side);ctx.fillStyle='#23364e';
    for(let row=0;row<count;row++)for(let col=0;col<count;col++)if(qr.isDark(row,col))ctx.fillRect(x+(col+4)*scale,yy+(row+4)*scale,scale,scale);
    ctx.fillStyle='#2e4d74';ctx.font='bold 30px system-ui,sans-serif';ctx.fillText('把好用的结果分享出去',pad+30,yy+63);ctx.font='25px system-ui,sans-serif';ctx.fillStyle='#6c7f98';ctx.fillText(model.footer,pad+30,yy+111);ctx.fillText('wutong.leeyan.site',pad+30,yy+164);ctx.font='22px system-ui,sans-serif';ctx.fillText('离线计算 · 手动加点 · 悬浮速查',pad+30,yy+209);
    return {width,height,qr:{x,y:yy,size:side},url:model.url};
  }
  const api={starModel,partModel,render};if(typeof module!=='undefined')module.exports=api;else root.ShareCard=api;
})(globalThis);
