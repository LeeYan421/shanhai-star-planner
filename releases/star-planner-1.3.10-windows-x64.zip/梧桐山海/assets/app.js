/* 本地需求、天赋多选与加点清单；计算放在独立线程，输入变更立即作废旧结果。 */
(() => {
  'use strict';
  const data = globalThis.STAR_DATA, $ = id => document.getElementById(id);
  const floatingLookup=new URLSearchParams(location.search).get('floating')==='mutation';
  if(floatingLookup){document.body.dataset.floating='mutation';document.documentElement.dataset.floating='mutation';}
  const talents = new Map(data.talents.map(t => [t.id, t]));
  const stars = new Map(data.stars.map(s => [s.id, s]));
  const nodeById = new Map(data.nodes.map(n => [n.id, n]));
  const quality = { 3: '绿色', 4: '紫色', 5: '红色' };
  const storeKey = 'star-planner-v1';
  const starTitle = id => { const star = stars.get(id); return star.weapon + ' · ' + star.name; };
  const elementRules=createElementRules(data);
  const elementOptions = new Map(data.elements.flatMap(element => element.options).map(option => [option.key, option]));
  const starLocation = id => stars.get(id).location;
  const nodeTitle = node => '第' + node.row + '行 · ' + node.attribute;
  const ruleNames={crit:'暴击优先',power:'虚战优先','attack-pen':'攻击穿透','crit-target':'自定义目标',pvp:'PVP均衡'};
  const pvpRules=createPvpRules();
  const accountTalents=createAccountTalentStore(data,localStorage);
  globalThis.AccountTalentLevels=accountTalents;
  let pvpConfig=pvpRules.defaults();
  const talentInsights=createTalentInsights(data,globalThis.TALENT_DETAILS,createPlannerEngine);
  const formatNumber=value=>Number(value).toLocaleString('zh-CN');
  const scrollPositions={};
  const state = { strategy: 'crit', profileId: '', selected: new Set(), selectedElements: new Set(), elementRules: [], elementStars: [], result: null, worker: null, sequence: 0, busy: false, route: 'home', filter: '全部', checked: new Set() };
  const esc = v => String(v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let searchTimer;

  function toast(message) {
    $('toast').textContent=message;$('toast').open=true;
  }
  const profilesKey='star-saved-plans-v1';
  let savedPlans=[],draftPlan=null,deletedPlan=null,nameMode='new';
  function snapshot(){return {budget:$('budget').value,capacity:$('capacity').value,selected:[...state.selected],elements:[...state.selectedElements],strategy:state.strategy,...(state.strategy==='pvp'?{pvp:pvpRules.normalize(pvpConfig)}:{}),critTarget:$('crit-target').value,source:data.sourceSha256,...(state.elementStars.length?{elementStars:state.elementStars.map(s=>({starId:s.starId,levels:s.levels.slice()}))}:{}),...(state.elementRules.length?{elementRules:state.elementRules.map(r=>({...r}))}:{})};}
  function savePlans(){localStorage.setItem(profilesKey,JSON.stringify({plans:savedPlans,draft:draftPlan,deleted:deletedPlan}));}
  function saveDraft() {
    try {
      const config=snapshot();localStorage.setItem(storeKey,JSON.stringify({...config,profileId:state.profileId}));
      const profile=savedPlans.find(p=>p.id===state.profileId);
      if(profile)profile.config=config;else draftPlan=config;
      savePlans();
      return true;
    }catch{toast('本机保存不可用，关闭后可能无法保留方案');return false;}
  }
  function applySnapshot(saved){
    $('budget').value=typeof saved?.budget==='string'&&/^\d{0,7}$/.test(saved.budget)?saved.budget:'';
    $('capacity').value=/^\d{1,2}$/.test(String(saved?.capacity))&&Number(saved.capacity)<=data.maxCapacity?saved.capacity:50;
    $('crit-target').value=/^\d{0,7}$/.test(String(saved?.critTarget??''))?saved?.critTarget??'':'';
    state.selected=new Set(Array.isArray(saved?.selected)?saved.selected.filter(id=>talents.has(id)):[]);
    state.selectedElements=new Set(Array.isArray(saved?.elements)?saved.elements.filter(key=>elementOptions.has(key)):[]);
    state.elementRules=Array.isArray(saved?.elementRules)?saved.elementRules.map(r=>({...r})):[];
    state.elementStars=Array.isArray(saved?.elementStars)?elementRules.normalizeStars(saved.elementStars,state.selectedElements.size?[...state.selectedElements]:[],state.elementRules):[];
    pvpConfig=saved?.pvp?pvpRules.normalize(saved.pvp):pvpRules.defaults();
    state.strategy=ruleNames[saved?.strategy]?saved.strategy:'crit';updateRule();
  }
  function updateRule(){
    const automatic=state.strategy==='power';
    $('manual-talents').classList.remove('hidden');$('talent-selection-help').classList.toggle('hidden',!automatic);$('auto-talents').classList.toggle('hidden',!automatic);
    $('crit-target-fields').classList.toggle('hidden',state.strategy!=='crit-target');
    $('pvp-fields').classList.toggle('hidden',state.strategy!=='pvp');renderPvp();
    $('priority-rule').value=state.strategy;document.querySelectorAll('#priority-rule mdui-radio').forEach(input=>input.classList.toggle('selected',input.value===state.strategy));
    updateCarryLimit();
  }
  // 预设只修改属性勾选，手动调整后归入自选，不改变用户已有天赋和元素目标。
  function renderPvp(){
    if(!$('pvp-preset').children.length)$('pvp-preset').innerHTML=pvpRules.presets.map(p=>`<mdui-menu-item value="${p.key}">${p.name}</mdui-menu-item>`).join('');
    $('pvp-preset').value=pvpConfig.preset;
    $('pvp-preset-help').textContent=pvpRules.presets.find(p=>p.key===pvpConfig.preset).hint;
    // 复用组件实例，避免勾选事件中移除节点，打断MDUI异步有效性检查。
    if(!$('pvp-attributes').children.length)$('pvp-attributes').innerHTML=pvpRules.attributes.map(a=>`<div class="pvp-attribute"><mdui-checkbox data-pvp-attr="${a.id}">${a.name}</mdui-checkbox><mdui-text-field class="pvp-weight" data-pvp-weight="${a.id}" aria-label="${a.name}权重" label="权重" type="number" inputmode="decimal" min="0" max="100" step="0.01" variant="filled"></mdui-text-field><p class="hint">${a.hint}</p></div>`).join('');
    document.querySelectorAll('[data-pvp-attr]').forEach(input=>input.checked=pvpConfig.attrIds.includes(Number(input.dataset.pvpAttr)));
    document.querySelectorAll('[data-pvp-weight]').forEach(input=>{const id=Number(input.dataset.pvpWeight),selected=pvpConfig.attrIds.includes(id);input.value=String(pvpConfig.weights[id]);input.classList.toggle('hidden',!selected);input.disabled=state.busy||!selected;input.updateComplete.then(()=>input.setCustomValidity(''));});
  }
  $('pvp-preset').addEventListener('change',()=>{const p=pvpRules.presets.find(p=>p.key===$('pvp-preset').value);if(!p)return;try{pvpConfig=pvpRules.normalize({...pvpConfig,preset:p.key,attrIds:p.key==='custom'?pvpConfig.attrIds:p.attrIds.slice()});}catch(error){toast(error.message);renderPvp();return;}renderPvp();dirty();});
  $('pvp-attributes').addEventListener('change',event=>{const input=event.target.closest('[data-pvp-attr]');if(!input)return;const id=Number(input.dataset.pvpAttr);if(!input.checked&&pvpConfig.attrIds.length===1){input.checked=true;toast('PVP属性至少选择一项');return;}try{pvpConfig=pvpRules.normalize({...pvpConfig,preset:'custom',attrIds:pvpRules.attributes.filter(a=>a.id===id?input.checked:pvpConfig.attrIds.includes(a.id)).map(a=>a.id)});}catch(error){toast(error.message);renderPvp();return;}renderPvp();dirty();});
  // 未通过校验的输入不覆盖已保存权重，同时立即作废旧方案。
  $('pvp-attributes').addEventListener('input',event=>{const input=event.target.closest('[data-pvp-weight]');if(!input)return;try{pvpConfig=pvpRules.normalize({...pvpConfig,weights:{...pvpConfig.weights,[input.dataset.pvpWeight]:input.value===''?NaN:Number(input.value)}});input.setCustomValidity('');}catch(error){input.setCustomValidity(error.message);}dirty();});
  // 首页只复用星宿工具已有的方案和手动进度，不另建一套存储。
  function renderHome() {
    const recent=savedPlans.slice(-3).reverse();
    $('home-plan-list').innerHTML=recent.length?recent.map(plan=>{
      const config=plan.config||{},budget=/^\d+$/.test(String(config.budget))?formatNumber(config.budget)+'点':'点数待填';
      return `<mdui-card class="saved-plan" data-open-profile="${esc(plan.id)}" clickable role="button" tabindex="0" variant="filled"><span><strong>${esc(plan.name)}</strong><small>${budget} · ${esc(ruleNames[config.strategy]||ruleNames.crit)}</small></span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg></mdui-card>`;
    }).join(''):'<p class="home-empty">在星宿配置中另存方案，下次从这里打开。</p>';
    $('home-all-plans').classList.toggle('hidden',savedPlans.length<=3);
    const r=state.result,canResume=r?.status==='optimal'&&r.steps.length>state.checked.size;
    $('home-resume').classList.toggle('hidden',!canResume);
    if(canResume){const guide=guideGroups();$('home-resume').innerHTML=`<span><strong>继续加点</strong><small>${esc(r.profileName||profileName())} · ${guide.filter(g=>g.nodes.every(n=>state.checked.has(n.id))).length}/${guide.length}步</small></span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg>`;}
  }
  $('home-plan-list').addEventListener('click',event=>{
    const button=event.target.closest('[data-open-profile]');if(!button)return;
    route('config',true);$('profile-select').value=button.dataset.openProfile;$('profile-select').dispatchEvent(new Event('change'));
  });
  document.addEventListener('click',event=>{
    const menu=document.querySelector('.profile-manage');
    if(menu.open&&(!menu.contains(event.target)||event.target.closest('#profile-rename,#profile-delete')))menu.open=false;
  });
  function updateProfiles(){
    $('profile-select').innerHTML='<mdui-menu-item value="">未命名方案</mdui-menu-item>'+savedPlans.map(p=>`<mdui-menu-item value="${esc(p.id)}">${esc(p.name)}</mdui-menu-item>`).join('');$('profile-select').value=state.profileId;
    $('profile-rename').disabled=!state.profileId;$('profile-delete').disabled=!state.profileId;$('profile-undo').classList.toggle('hidden',!deletedPlan);
  }
  function loadDraft() {
    try {
      const stored=JSON.parse(localStorage.getItem(profilesKey)||'null'),session=JSON.parse(localStorage.getItem(storeKey)||'null');
      if(stored){savedPlans=Array.isArray(stored.plans)?stored.plans.filter(p=>typeof p.id==='string'&&/^[a-z0-9-]+$/.test(p.id)&&typeof p.name==='string'&&p.name.trim()&&p.name.length<=24&&p.config):[];draftPlan=stored.draft||null;deletedPlan=stored.deleted?.id&&stored.deleted?.name?stored.deleted:null;}
      state.profileId=savedPlans.some(p=>p.id===session?.profileId)?session.profileId:'';
      applySnapshot(session||draftPlan);if(!draftPlan&&!state.profileId)draftPlan=snapshot();
      if(session?.source&&session.source!==data.sourceSha256)toast('星宿数据已更新，请重新核对并计算');
    }catch{applySnapshot(null);toast('已忽略损坏的本机方案记录');}
    updateProfiles();
  }
  function profileName(){return savedPlans.find(p=>p.id===state.profileId)?.name||'未命名方案';}
  $('priority-rule').addEventListener('change',event=>{if(event.target!==$('priority-rule')||!ruleNames[event.target.value]||event.target.value===state.strategy)return;state.strategy=event.target.value;updateRule();updateSelection();dirty();});
  $('profile-select').addEventListener('change',()=>{
    const id=$('profile-select').value;if(id===state.profileId)return;saveDraft();const config=id?savedPlans.find(p=>p.id===id)?.config:draftPlan;
    state.profileId=id;applySnapshot(config);dirty();updateProfiles();updateSelection();updateElements();
    if(/^\d+$/.test($('budget').value))compute();else toast('已切换方案，填写点数后计算');
  });
  function openNameDialog(mode){nameMode=mode;$('profile-name-title').textContent=mode==='new'?'另存新方案':'重命名方案';$('profile-name').value=mode==='rename'?profileName():'';$('profile-name-error').classList.add('hidden');$('profile-name-dialog').showModal();}
  $('profile-new').addEventListener('click',()=>openNameDialog('new'));$('profile-rename').addEventListener('click',()=>openNameDialog('rename'));
  $('profile-name-cancel').addEventListener('click',()=>$('profile-name-dialog').close());
  $('profile-name-save').addEventListener('click',()=>{
    const name=$('profile-name').value.trim();
    if(!name||savedPlans.some(p=>p.name===name&&(nameMode==='new'||p.id!==state.profileId))){$('profile-name-error').textContent=!name?'请输入方案名称':'已有同名方案，请换一个名称';$('profile-name-error').classList.remove('hidden');return;}
    if(!saveDraft())return;
    let saved;
    if(nameMode==='new'){const id=Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,9);savedPlans.push({id,name,config:snapshot()});state.profileId=id;saved=dirty();}
    else{savedPlans.find(p=>p.id===state.profileId).name=name;if(state.result){state.result.profileName=name;renderResult();renderGuide();}saved=saveDraft();}
    if(!saved){updateProfiles();return;}
    updateProfiles();$('profile-name-dialog').close();toast('方案已保存在本机');
  });
  $('profile-delete').addEventListener('click',()=>{$('profile-delete-text').textContent='删除“'+profileName()+'”？当前需求保留为草稿，可撤销最近一次删除。';$('profile-delete-dialog').showModal();});
  $('profile-delete-cancel').addEventListener('click',()=>$('profile-delete-dialog').close());
  $('profile-delete-confirm').addEventListener('click',()=>{saveDraft();deletedPlan=savedPlans.find(p=>p.id===state.profileId);savedPlans=savedPlans.filter(p=>p.id!==state.profileId);state.profileId='';draftPlan=snapshot();const saved=dirty();updateProfiles();$('profile-delete-dialog').close();if(saved)toast('已删除方案，当前需求保留为草稿');});
  $('profile-undo').addEventListener('click',()=>{if(!deletedPlan)return;if(!savedPlans.some(p=>p.id===deletedPlan.id))savedPlans.push(deletedPlan);deletedPlan=null;const saved=saveDraft();updateProfiles();if(saved)toast('已恢复方案');});
  function dirty() {
    if (globalThis.AndroidPlanner && typeof AndroidPlanner.hideFloatingGuide === 'function') AndroidPlanner.hideFloatingGuide();
    state.result = null; $('input-error').classList.add('hidden'); updateNavigation(); return saveDraft();
  }
  document.addEventListener('account-talents-changed',()=>{state.sequence++;stopWorker();setBusy(false);dirty();});
  const aggregateMarkup=data.elements.map(e=>`<mdui-card variant="filled" class="element-block" data-element-block="${e.key}"><h3 class="element-star-title">${esc(e.name)}</h3><div class="element-rule-row"><mdui-select data-element-mode="${e.key}" aria-label="${esc(e.name)}合计目标" variant="filled"><mdui-menu-item value="full">点满属性</mdui-menu-item><mdui-menu-item value="points">指定点数</mdui-menu-item><mdui-menu-item value="attack">攻击目标</mdui-menu-item></mdui-select><label class="element-rule-value hidden"><span data-element-unit="${e.key}"></span><mdui-text-field type="number" min="0" max="1000000" step="1" inputmode="numeric" data-element-value="${e.key}" aria-label="${esc(e.name)}目标值" variant="filled"></mdui-text-field></label></div><div class="element-checks">${e.options.map(o=>`<label><mdui-checkbox data-element="${o.key}" aria-label="${esc(o.name)}"></mdui-checkbox><span>${esc(o.label)}</span></label>`).join('')}</div><p class="element-rule-hint hint hidden" data-element-hint="${e.key}"></p></mdui-card>`).join('');
  $('element-options').innerHTML=data.elements.map(e=>`<mdui-collapse accordion="" class="collapse-shell" value=""><mdui-collapse-item value="panel" class="element-scope"><mdui-list-item slot="header" class="collapse-heading"><strong>${esc(e.name)}</strong><span>${e.starNames.map(esc).join(' / ')}</span></mdui-list-item>${elementRules.stars.filter(s=>s.element.key===e.key).map(s=>`<mdui-card variant="filled" class="element-star" data-element-star="${s.id}"><h3 class="element-star-title">${esc(s.name)} <small>${esc(s.location)}</small></h3><div class="element-star-heading"><label><mdui-checkbox data-element-star-enable="${s.id}" aria-label="${esc(s.name)}逐行设置"></mdui-checkbox>逐行设置</label><span data-element-star-status="${s.id}" class="muted">自动</span><mdui-button class="text-button hidden" data-element-star-clear="${s.id}" variant="text">全部不点</mdui-button></div><div class="element-node-rows hidden">${s.nodes.map((n,i)=>`<label class="element-node-row"><span>${n.row||i+1}. ${esc(n.attribute)}</span><mdui-select data-element-star-level="${s.id}" data-element-row="${i}" aria-label="${esc(s.name)}第${n.row||i+1}行${esc(n.attribute)}等级" variant="filled">${Array.from({length:n.values.length+1},(_,lv)=>`<mdui-menu-item value="${lv}">${lv===0?'不点':lv+'级'}</mdui-menu-item>`).join('')}</mdui-select><small data-element-node-value="${n.id}">＋0 · 0点</small></label>`).join('')}</div></mdui-card>`).join('')}</mdui-collapse-item></mdui-collapse>`).join('')+`<mdui-collapse accordion="" class="collapse-shell" value=""><mdui-collapse-item value="panel" id="element-aggregate" class="compact-details"><mdui-list-item slot="header" class="collapse-heading"><h2>元素合计目标</h2></mdui-list-item><div class="detail-content"><p class="hint">与该元素的逐行设置互斥。</p>${aggregateMarkup}</div></mdui-collapse-item></mdui-collapse>`;
  function updateElements(){
    document.querySelectorAll('[data-element]').forEach(input=>{input.checked=state.selectedElements.has(input.dataset.element);});
    for(const s of elementRules.stars){
      const item=state.elementStars.find(x=>x.starId===s.id),block=document.querySelector('[data-element-star="'+s.id+'"]');
      block.querySelector('[data-element-star-enable]').checked=!!item;block.querySelector('.element-node-rows').classList.toggle('hidden',!item);block.querySelector('[data-element-star-clear]').classList.toggle('hidden',!item);
      block.querySelector('[data-element-star-status]').textContent=item?elementRules.summarizeStars([item])[0].spent+'点':'自动';
      s.nodes.forEach((n,i)=>{const level=item?.levels[i]||0,input=block.querySelector('[data-element-row="'+i+'"]');input.value=level;input.disabled=!item||state.busy;block.querySelector('[data-element-node-value="'+n.id+'"]').textContent='＋'+(level?n.values[level-1]:0)+' · '+n.costs.slice(0,level).reduce((a,b)=>a+b,0)+'点';});
    }
    for(const e of data.elements){
      const rule=state.elementRules.find(r=>r.key===e.key),block=document.querySelector('[data-element-block="'+e.key+'"]');
      block.querySelector('mdui-select').value=rule?.mode||'full';block.querySelector('.element-checks').classList.toggle('hidden',!!rule);block.querySelector('.element-rule-value').classList.toggle('hidden',!rule);
      const input=block.querySelector('[data-element-value]');if(document.activeElement!==input)input.value=rule?.value??'';
      block.querySelector('[data-element-unit]').textContent=rule?.mode==='attack'?'至少＋':'最多点数';const hint=block.querySelector('[data-element-hint]');hint.classList.toggle('hidden',!rule);hint.textContent=rule?.mode==='attack'?'允许整级超出目标，余点按总规则。':'先攻击后穿透；不要求用完上限。';
    }
    const hasAggregate=state.selectedElements.size+state.elementRules.length>0,details=$('element-aggregate');if(hasAggregate&&details.dataset.active!=='true')details.open=true;if(!hasAggregate&&details.dataset.active==='true')details.open=false;details.dataset.active=String(hasAggregate);
    const count=state.selectedElements.size+state.elementRules.length+state.elementStars.length;$('element-selection').textContent=count?'已设'+count+'项目标':'选填';
  }
  function clearAggregate(key){const e=data.elements.find(e=>e.key===key);state.elementRules=state.elementRules.filter(r=>r.key!==key);for(const o of e.options)state.selectedElements.delete(o.key);}
  function clearManual(key){const e=data.elements.find(e=>e.key===key);state.elementStars=state.elementStars.filter(s=>!e.starIds.includes(s.starId));}
  $('element-options').addEventListener('change',event=>{
    if(event.target.dataset.elementStarEnable){const id=Number(event.target.dataset.elementStarEnable),star=elementRules.stars.find(s=>s.id===id);if(state.elementStars.some(s=>s.starId===id)===event.target.checked)return;state.elementStars=state.elementStars.filter(s=>s.starId!==id);if(event.target.checked){clearAggregate(star.element.key);state.elementStars.push({starId:id,levels:star.nodes.map(()=>0)});}dirty();updateElements();updateSelection();return;}
    if(event.target.dataset.elementStarLevel){const id=Number(event.target.dataset.elementStarLevel),item=state.elementStars.find(s=>s.starId===id);if(!item||item.levels[Number(event.target.dataset.elementRow)]===Number(event.target.value))return;item.levels[Number(event.target.dataset.elementRow)]=Number(event.target.value);const requested=item.levels.slice();state.elementStars=elementRules.normalizeStars(state.elementStars,[...state.selectedElements],state.elementRules);const actual=state.elementStars.find(s=>s.starId===id);if(actual.levels.some((lv,i)=>lv>requested[i]))toast('必要前置已补到1级');dirty();updateElements();return;}
    const key=event.target.dataset.elementMode;
    if(key){if((state.elementRules.find(rule=>rule.key===key)?.mode||'full')===event.target.value)return;clearManual(key);clearAggregate(key);if(event.target.value!=='full')state.elementRules.push({key,mode:event.target.value,value:''});dirty();updateElements();updateSelection();return;}
    const option=event.target.dataset.element;if(!elementOptions.has(option)||state.selectedElements.has(option)===event.target.checked)return;
    if(event.target.checked){clearManual(data.elements.find(e=>e.options.some(o=>o.key===option)).key);state.selectedElements.add(option);}else state.selectedElements.delete(option);dirty();updateElements();updateSelection();
  });
  $('element-options').addEventListener('click',event=>{const button=event.target.closest('[data-element-star-clear]');if(!button)return;const item=state.elementStars.find(s=>s.starId===Number(button.dataset.elementStarClear));item.levels.fill(0);dirty();updateElements();});
  $('element-options').addEventListener('input',event=>{const rule=state.elementRules.find(r=>r.key===event.target.dataset.elementValue);if(!rule)return;rule.value=event.target.value;dirty();});
  function elementGoalText(result){return [...(result.elementRuleResults||[]).map(elementRules.resultLabel),...(result.elementStarResults||[]).map(elementRules.starLabel)].join('\n');}
  function powerLabel(value) { return value === null ? '未配置计分' : '+' + value.toLocaleString('zh-CN'); }
  function critTargetText(result) { return result.critTarget===undefined?'':`暴击目标至少+${result.critTarget} · 实际暴击+${result.crit} · 攻击+${result.attack}`; }
  function pvpText(r){return r.pvpResult?'PVP均衡：'+createPvpRules().label(r.pvpResult)+'\n'+(r.pvpResult.life?'高收益生命 +'+r.pvpResult.life.value+' · '+r.pvpResult.life.nodes.length+'个节点\n':'')+r.pvpResult.attributes.map(a=>a.name+' +'+a.value+' / '+a.maximum+'（'+(a.ratio===null?'当前预算不可达':(a.ratio*100).toFixed(1)+'%')+'）').join('；')+'\n属性均衡参考，非实战伤害最优。':'';}
  function levelText(step) { return step.levelGains.map(gain => `Lv${gain.from}→${gain.to}：${step.attribute}+${gain.value}；${gain.cost}点；战力参考${powerLabel(gain.powerDelta)}`).join('\n'); }
  function levelDetails(step, opened = false) {
    return `<mdui-collapse accordion="" class="collapse-shell" value="${opened?'panel':''}"><mdui-collapse-item value="panel" class="level-details" ${opened ? 'open' : ''}><mdui-list-item slot="header" class="collapse-heading">每级明细</mdui-list-item>${levelTable(step)}</mdui-collapse-item></mdui-collapse>`;
  }
  function levelTable(step) {
    return `<table><thead><tr><th>等级</th><th>属性增量</th><th>消耗</th><th>战力参考</th></tr></thead><tbody>${step.levelGains.map(g => `<tr><td>${g.from}→${g.to}</td><td>+${g.value}</td><td>${g.cost}点</td><td>${powerLabel(g.powerDelta)}</td></tr>`).join('')}</tbody></table>`;
  }
  function totalFees() { return [...state.selected].reduce((v, id) => v + talents.get(id).cost, 0); }
  function updateCarryLimit(){const capacity=Number($('capacity').value)||0;const max=data.talentPower.baseSlots+data.talentPower.extraSlotRules.filter(r=>capacity>=r.cur_max).reduce((sum,r)=>sum+r.extra_config_limit,0);$('auto-carry-limit').textContent=capacity+'费 · 最多'+max+'项';}
  function updateSelection() {
    const fee = totalFees(), capacity = $('capacity').value || '0'; updateCarryLimit();
    $('fee-label').textContent = state.selected.size?(state.strategy==='power'?'自选':'已选')+state.selected.size+'项 · '+fee+'/'+capacity+'费':state.strategy==='power'?'自动搭配':'选填';
    $('fee-label').style.color = fee > Number(capacity) ? '#943340' : '';
    $('picker-total').textContent = '已选' + state.selected.size + '项 · ' + fee + ' / ' + capacity + '费';
    $('pick-label').textContent = state.selected.size ? '继续选择' : '选择天赋';
    $('selected-list').innerHTML = [...state.selected].map(id => {
      const t = talents.get(id), s = stars.get(t.starId);
      return `<mdui-button class="selected-chip" data-remove="${id}" aria-label="移除${esc(starTitle(s.id))}${quality[t.quality]}天赋" variant="text"><span class="quality-dot q${t.quality}"></span>${esc(starTitle(s.id))} · ${quality[t.quality]}<span class="chip-remove" aria-hidden="true">×</span></mdui-button>`;
    }).join('');
    document.querySelectorAll('[data-talent]').forEach(el => { el.checked = state.selected.has(Number(el.dataset.talent)); });
    document.querySelectorAll('[data-star-count]').forEach(el => {
      const s = stars.get(Number(el.dataset.starCount)), count = s.talentIds.filter(id => state.selected.has(id)).length;
      el.textContent = count ? '已选' + count + '项' : s.talentIds.length + '项可选';
    });
    document.querySelectorAll('[data-talent-additional]').forEach(el=>{
      const own=talentInsights.additional(Number(el.dataset.talentAdditional),[...state.selected],[...state.selectedElements]);
      el.textContent=own.selected?'':own.points===null?'当前目标需调整后计算追加点数':own.points<0?'替换后可省'+(-own.points)+'点':own.points===0?'相对已选目标无需追加点数':'相对已选目标追加'+own.points+'点';
      el.classList.toggle('hidden',state.elementStars.length>0||state.elementRules.length>0||own.selected||state.selected.size+state.selectedElements.size===0);
    });
  }
  function selectTalent(id, selected) {
    if (selected) {
      const t = talents.get(id); let removed = false;
      for (const chosen of [...state.selected]) {
        const other = talents.get(chosen);
        if (data.conflicts.some(c => (c.id === t.conflictGroup && c.exclusive_group.includes(other.conflictGroup)) || (c.id === other.conflictGroup && c.exclusive_group.includes(t.conflictGroup)))) { state.selected.delete(chosen); removed = true; }
      }
      state.selected.add(id); if (removed) toast('已替换与此项互斥的天赋');
    } else state.selected.delete(id);
    dirty(); updateSelection();
  }
  function talentRows(star) {
    return star.talentIds.map(id => {
      const t = talents.get(id);
      const info=talentInsights.analyse(id,accountTalents.get()),efficiency=info.efficiency===null?'—':info.efficiency.toLocaleString('zh-CN',{minimumFractionDigits:2,maximumFractionDigits:2});
      const levels=t.effects.map((s,i)=>{const upgrade=info.upgrades?.find(u=>u.from===i+1),cost=i===t.effects.length-1?'已满级':upgrade?'升至Lv'+(i+2)+'：'+upgrade.items.map(item=>esc(item.name)+'×'+item.count).join('、'):'升级物品未录入';return `<section class="talent-level-block"><strong>Lv${i+1} · 天赋战力参考＋${t.power[i]}</strong><p>${esc(s)}</p><p>${cost}</p></section>`;}).join('');
      return `<mdui-card class="talent-row" variant="filled"><label class="talent-row-head"><mdui-checkbox data-talent="${id}" ${state.selected.has(id) ? 'checked' : ''}></mdui-checkbox><span class="q${t.quality}">${quality[t.quality]}天赋</span><span class="fee">${t.cost}费</span></label><p class="talent-effect">Lv1：${esc(t.effects[0])}</p><div class="talent-insights"><span><strong>解锁需${info.totalPoints}点</strong><small>本星宿${info.ownPoints} · 前置${info.prerequisitePoints}</small></span><span class="talent-efficiency"><strong data-talent-efficiency="${id}">${efficiency}战力/点</strong><small>单项Lv${info.level} · 不含前置</small></span></div><p class="talent-materials">升级用：${info.materials.length?info.materials.map(esc).join('、'):'材料未录入'}</p><p class="talent-additional hidden" data-talent-additional="${id}"></p><mdui-collapse accordion="" class="collapse-shell" value=""><mdui-collapse-item value="panel" class="effect-details"><mdui-list-item slot="header" class="collapse-heading">等级效果、升级物品与评分</mdui-list-item><p class="talent-score-details">本星宿全部节点达Lv${t.requiredLevel}解锁。节点战力${info.nodePower}＋天赋Lv${info.level}战力${info.talentPower}＝${info.nodePower+info.talentPower}，除以本星宿${info.ownPoints}点。公共前置不计入效率。</p>${levels}<p class="talent-picker-help">物品为每次升级消耗，不含通用货币。战力效率只作虚战参考，不代表实战强弱。</p></mdui-collapse-item></mdui-collapse></mdui-card>`;
    }).join('');
  }
  function renderOptions() {
    const query = $('talent-search').value.trim().toLowerCase();
    const available = data.stars.filter(s => s.talentIds.length && (state.filter === '全部' || s.family === state.filter));
    const found = available.filter(s => !query || [s.name, s.family, s.weapon, ...s.talentIds.flatMap(id => talents.get(id).effects)].join(' ').toLowerCase().includes(query));
    $('talent-options').innerHTML = found.map(s => {
      const count = s.talentIds.filter(id => state.selected.has(id)).length, opened = !!query;
      return `<mdui-collapse accordion="" class="collapse-shell" value="${opened?'panel':''}"><mdui-collapse-item value="panel" class="talent-star" data-star="${s.id}" ${opened ? 'open' : ''}><mdui-list-item slot="header" class="collapse-heading"><div class="star-label"><strong>${esc(s.weapon)} · ${esc(s.name)}</strong><small>${esc(s.family)}<span class="star-location">${esc(starLocation(s.id))}</span></small></div><span class="star-count" data-star-count="${s.id}">${count ? '已选' + count + '项' : s.talentIds.length + '项可选'}</span><span class="chevron" aria-hidden="true">›</span></mdui-list-item><div data-options="${s.id}" ${opened ? 'data-loaded="true"' : ''}>${opened ? talentRows(s) : ''}</div></mdui-collapse-item></mdui-collapse>`;
    }).join('') || '<p class="empty">没有找到对应天赋，试试武器名或星象名。</p>';
    updateSelection();
  }
  const families = ['全部', ...new Set(data.stars.filter(s => s.talentIds.length).map(s => s.family))];
  $('family-filters').innerHTML = families.map(f => `<mdui-button data-family="${esc(f)}" class="${f === '全部' ? 'active' : ''}" aria-pressed="${f === '全部'}" variant="text">${esc(f)}</mdui-button>`).join('');
  $('family-filters').addEventListener('click', e => {
    const button = e.target.closest('[data-family]'); if (!button) return;
    state.filter = button.dataset.family;
    document.querySelectorAll('[data-family]').forEach(b => { b.classList.toggle('active', b === button); b.setAttribute('aria-pressed', b === button ? 'true' : 'false'); });
    renderOptions();
  });
  $('talent-options').addEventListener('toggle', e => {
    const id = Number(e.target.dataset.star); if (!id || !e.target.open) return;
    const host = e.target.querySelector('[data-options]');
    if (!host.dataset.loaded) { host.innerHTML = talentRows(stars.get(id)); host.dataset.loaded = 'true'; }
  }, true);
  $('talent-options').addEventListener('change', e => { if (e.target.dataset.talent&&state.selected.has(Number(e.target.dataset.talent))!==e.target.checked) selectTalent(Number(e.target.dataset.talent), e.target.checked); });
  $('talent-search').addEventListener('input', () => { clearTimeout(searchTimer); searchTimer = setTimeout(renderOptions, 100); });
  $('selected-list').addEventListener('click', e => { const b = e.target.closest('[data-remove]'); if (b) selectTalent(Number(b.dataset.remove), false); });
  $('pick-button').addEventListener('click', () => { renderOptions(); $('picker').showModal(); document.body.classList.add('no-scroll'); });
  function closePicker() { $('picker').close(); document.body.classList.remove('no-scroll'); }
  $('close-picker').addEventListener('click', closePicker); $('confirm-picker').addEventListener('click', closePicker);
  $('picker').addEventListener('close', () => document.body.classList.remove('no-scroll'));
  $('about-button').addEventListener('click', () => $('about').showModal()); $('close-about').addEventListener('click', () => $('about').close());
  // 邀请由QQ群官网生成；网页预览使用同一官方邀请页，不自动申请入群。
  const qqWebInvite='https://qm.qq.com/cgi-bin/qm/qr?k=TAvXmS48OgUF46n1FxgorLCQJrOx_y4f&jump_from=webapi&authKey=G3G0tcQscGC3M9IcD4e8sqCKx5iGxX/4kUg0oXlq3PdsSZkOCvDFR5wX2j+gzHt/';
  function openQQInvitePage(){
    if(globalThis.AndroidPlanner&&typeof AndroidPlanner.openQQInvitePage==='function')AndroidPlanner.openQQInvitePage();
    else window.open(qqWebInvite,'_blank','noopener,noreferrer');
  }
  $('qq-group-open').addEventListener('click',()=>{$('qq-group-status').textContent='';$('qq-group').showModal();});
  $('qq-group-close').addEventListener('click',()=>$('qq-group').close());
  $('qq-group-web').addEventListener('click',openQQInvitePage);
  $('qq-group-join').addEventListener('click',()=>{
    if(globalThis.AndroidPlanner&&typeof AndroidPlanner.joinQQGroup==='function')AndroidPlanner.joinQQGroup();
    else openQQInvitePage();
  });
  $('qq-group-copy').addEventListener('click',async()=>{
    try {
      const number=$('qq-group-number').textContent.trim();
      if(globalThis.AndroidPlanner){if(!AndroidPlanner.copyText(number))throw new Error('复制失败');}
      else await navigator.clipboard.writeText(number);
      $('qq-group-status').textContent='已复制群号';
    }catch{$('qq-group-status').textContent='复制失败，可手动输入群号';}
  });
  // 赞赏图按需加载，独立弹层关闭后保留原来的帮助位置。
  $('appreciation-open').addEventListener('click',()=>{
    if(!$('appreciation-code').getAttribute('src'))$('appreciation-code').src='support/appreciation-code.png';
    $('appreciation').showModal();
  });
  $('appreciation-close').addEventListener('click',()=>$('appreciation').close());
  $('check-update').addEventListener('click', () => {
    if (globalThis.AndroidPlanner && typeof AndroidPlanner.checkForUpdates === 'function') AndroidPlanner.checkForUpdates();
    else toast('请在安卓App内检查更新');
  });
  for (const id of ['budget', 'capacity', 'crit-target']) $(id).addEventListener('input', () => { dirty(); updateSelection(); });

  function updateNavigation() {
    document.querySelectorAll('[data-route]').forEach(button=>{
      const name=button.dataset.route,active=name===state.route;button.disabled=name==='result'&&!state.result||name==='guide'&&state.result?.status!=='optimal';
      button.classList.toggle('active',active);button.setAttribute('aria-current',active?'step':'false');
      button.setAttribute('aria-disabled',name==='result'&&!state.result||name==='guide'&&state.result?.status!=='optimal'?'true':'false');
    });
    if(['config','result','guide'].includes(state.route))$('tool-nav').value=state.route;
    const home=state.route==='home',titles={talents:'账号天赋',equipment:'词条搭配',chiyou:'蚩尤旗兵魂',mutation:'变异速查',collection:'收藏与最近',compare:'星宿方案',community:'意见与需求',clock:'悬浮时钟',beasts:'资源刷新时钟'};
    $('tool-nav').classList.toggle('hidden',!['config','result','guide'].includes(state.route));$('tool-home').classList.toggle('hidden',home);
    $('brand-title').textContent=home?'梧桐山海':titles[state.route]||'星宿配置';document.body.dataset.page=state.route;
    if(typeof globalThis.AndroidPlanner?.setStarLandscape==='function')AndroidPlanner.setStarLandscape(state.route==='talents');
  }
  // 工具内保留阅读位置；离开正在计算的工具时先取消线程并保留输入。
  function route(name,reset=false) {
    if(!['home','config','result','guide','mutation','collection','compare','community','clock','chiyou','beasts','talents','equipment'].includes(name))return;
    if(['result','guide'].includes(name)&&!state.result){toast('先生成方案');return;}
    if(name==='guide'&&state.result.status!=='optimal'){toast('点数不足，请调整配置');return;}
    if(['home','mutation','collection','compare','community','clock','chiyou','beasts','talents','equipment'].includes(name)&&state.busy){state.sequence++;stopWorker();setBusy(false);toast('已取消计算');}
    if(state.route==='equipment'&&name!=='equipment')globalThis.EquipmentTool?.leave();
    if(state.route==='chiyou'&&name!=='chiyou')globalThis.ChiyouTool?.leave();
    if(state.route==='clock'&&name!=='clock')globalThis.ClockUI?.leave();
    if(state.route==='beasts'&&name!=='beasts')globalThis.BeastTimersUI?.leave();
    if(state.route==='talents'&&name!=='talents')globalThis.AccountTalentUI?.leave();
    if(state.route==='compare'&&name!=='compare')globalThis.PersonalUI?.leave();
    scrollPositions[state.route]=window.scrollY;state.route=name;
    for(const key of ['home','config','result','guide','mutation','collection','compare','community','clock','chiyou','beasts','talents','equipment'])$(key+'-view').classList.toggle('hidden',key!==name);
    if(name==='home')renderHome();
    if(name==='talents')globalThis.AccountTalentUI?.open();
    if(name==='mutation')MutationTool.open();
    if(name==='chiyou')globalThis.ChiyouTool?.open();
    if(name==='equipment')globalThis.EquipmentTool?.open();
    if(name==='beasts')globalThis.BeastTimersUI?.open();
    if(name==='collection')globalThis.PersonalUI?.openCollections();
    if(name==='compare')globalThis.PersonalUI?.openCompare();
    if(name==='community')globalThis.CommunityUI?.open();
    updateNavigation();if(name==='clock')globalThis.ClockUI?.open();window.scrollTo(0,reset?0:scrollPositions[name]||0);$('main').focus({preventScroll:true});
  }
  document.querySelector('.tool-nav').addEventListener('click',event=>{const button=event.target.closest('[data-route]');if(button)route(button.dataset.route);});
  document.addEventListener('click',event=>{const button=event.target.closest('[data-go]');if(button)route(button.dataset.go,state.route==='home');});
  function setBusy(busy) {
    state.busy = busy; if(busy)$('compute-text').textContent='正在计算…'; $('compute-button').disabled = busy; $('pick-button').disabled = busy; $('budget').disabled = busy; $('capacity').disabled = busy;
    document.querySelectorAll('[data-element], [data-element-mode], [data-element-value], [data-element-star-enable], [data-element-star-level], [data-element-star-clear], [data-remove]').forEach(input => { input.disabled = busy; });
    document.querySelectorAll('[data-pvp-attr]').forEach(input=>input.disabled=busy);$('pvp-preset').disabled=busy;
    document.querySelectorAll('[data-pvp-weight]').forEach(input=>input.disabled=busy||!pvpConfig.attrIds.includes(Number(input.dataset.pvpWeight)));
    for(const id of ['priority-rule','profile-select','profile-new','profile-undo','crit-target'])$(id).disabled=busy;
    $('profile-rename').disabled=busy||!state.profileId;$('profile-delete').disabled=busy||!state.profileId;
    $('compute-status').classList.toggle('hidden', !busy); $('compute-button').textContent = busy ? '正在计算…' : '生成方案 →';
    updateElements();
  }
  function stopWorker() { if (state.worker) state.worker.terminate(); state.worker = null; }
  function fail(message) { stopWorker(); setBusy(false); $('input-error').textContent = message; $('input-error').classList.remove('hidden'); }
  async function compute() {
    let talentLevels;try{talentLevels=accountTalents.get();}catch(error){fail(error.message);return;}
    if(state.strategy==='pvp'){const invalid=[...document.querySelectorAll('[data-pvp-weight]')].find(input=>!input.disabled&&!input.checkValidity());if(invalid){fail(invalid.validationMessage||'请填写有效的PVP权重');invalid.reportValidity();return;}}
    for (const [id, label] of [['budget', '星宿点'], ['capacity', '天赋容量']]) {
      if (!/^\d+$/.test($(id).value)) { fail('请填写有效的' + label + '整数'); $(id).focus(); return; }
    }
    const request = { budget: Number($('budget').value), capacity: Number($('capacity').value), talentIds: [...state.selected], talentLevels, elementKeys: [...state.selectedElements], elementRules:state.elementRules,elementStars:state.elementStars, strategy: state.strategy, pvp:state.strategy==='pvp'?pvpRules.normalize(pvpConfig):undefined };
    if(state.strategy==='crit-target'){
      if(!/^\d+$/.test($('crit-target').value)){fail('请填写有效的暴击目标整数');$('crit-target').focus();return;}
      request.critTarget=Number($('crit-target').value);
    }
    try { createPlannerEngine(data).prepare(request); } catch (e) { fail(e.message); return; }
    dirty(); setBusy(true); const sequence = ++state.sequence;
    let vendorSource='',wasmBytes;
    if(['power','crit-target','pvp'].includes(request.strategy)||request.elementRules.length||request.elementStars.length){
      try {
        const responses=await Promise.all(['highs.js','highs.wasm'].map(file=>fetch(new URL('vendor/'+file,location.href))));
        if(responses.some(response=>!response.ok))throw new Error('资源缺失');
        [vendorSource,wasmBytes]=await Promise.all([responses[0].text(),responses[1].arrayBuffer()]);
      }catch{if(sequence===state.sequence)fail('本机联合计算组件未能加载，请重新打开App后重试');return;}
      if(sequence!==state.sequence||!state.busy)return;
    }
    // 将完整纯函数送入Worker，避免依赖网络脚本或阻塞输入线程。
    const source=createPlannerWorkerSource(vendorSource);
    const url = URL.createObjectURL(new Blob([source], { type: 'text/javascript' }));
    try {
      const worker = new Worker(url); state.worker = worker;
      worker.onmessage = e => {
        if (sequence !== state.sequence) return;
        if (e.data.progress !== undefined) { $('compute-text').textContent = '正在计算… ' + e.data.progress + '%'; return; }
        if (e.data.error) { globalThis.Diagnostics?.record('planner',{name:e.data.errorName,message:e.data.error,stack:e.data.errorStack});fail(e.data.error); return; }
        state.result = e.data.result; state.result.profileName = profileName(); stopWorker(); setBusy(false); loadChecks(); renderResult(); renderGuide(); scrollPositions.guide=0; route('result',true);
        document.dispatchEvent(new CustomEvent('planner-result-ready',{detail:{id:state.profileId,config:snapshot(),result:state.result}}));
      };
      worker.onerror = e => { globalThis.Diagnostics?.record('planner',e.error||{message:e.message,stack:(e.filename||'')+':'+e.lineno+':'+e.colno});if (sequence === state.sequence) fail('计算线程未能完成，请重试或关闭后重新打开应用'); };
      worker.postMessage({ data, request, wasmBytes },wasmBytes?[wasmBytes]:[]);
    } catch { fail('当前系统组件无法启动离线计算，请更新Android系统WebView后重试'); }
    finally { URL.revokeObjectURL(url); }
  }
  $('compute-button').addEventListener('click', compute);
  $('cancel-button').addEventListener('click', () => { state.sequence++; stopWorker(); setBusy(false); toast('已取消计算，需求已保留'); });

  function renderResult() {
    const r=state.result;
    if(r.status==='insufficient'){
      $('result-view').innerHTML=`<div class="page-heading"><h1 id="result-title">还差${r.deficit}点</h1><span class="pill">未达标</span></div><mdui-card class="card" variant="filled"><div class="section-heading"><h2>最少需要</h2><strong class="insufficient-value">${r.minimumCost}<small>点</small></strong></div><p class="result-description">当前${r.budget}点，已计入全部目标与前置。${r.critTarget===undefined?'':`暴击目标至少+${r.critTarget}。`}</p></mdui-card><mdui-button class="primary-button" data-go="config" variant="filled">调整配置</mdui-button>`;return;
    }
    const automatic=!!r.autoTalents,custom=r.critTarget!==undefined,selected=r.unlocked.filter(t=>t.selected);
    const hero=r.pvpResult?r.pvpResult.attributes.slice(0,2).map(a=>[a.name,a.value]):automatic?[['虚战参考',r.powerReference],['暴击',r.crit]]:r.strategy==='attack-pen'?[['攻击',r.attack],['穿透',r.penetration]]:custom?[['攻击',r.attack],['暴击',r.crit]]:[['暴击',r.crit],['攻击',r.attack]];
    const talentRows=selected.map(t=>`<mdui-collapse accordion="" class="collapse-shell" value=""><mdui-collapse-item value="panel" class="talent-result"><mdui-list-item slot="header" class="collapse-heading"><span><strong>${esc(starTitle(t.starId))}</strong><small><span class="quality-dot q${t.quality}"></span> ${automatic?(t.pinned?'自选':'补充')+' · ':''}${quality[t.quality]} · ${t.cost}费${' · Lv'+(t.equippedLevel||1)}</small></span></mdui-list-item><div class="talent-detail"><span class="star-location">${esc(starLocation(t.starId))}</span><p>${automatic?'Lv'+t.equippedLevel+' · 战力参考+'+t.power:'Lv'+(t.equippedLevel||1)}：${esc(t.effects[(t.equippedLevel||1)-1])}</p></div></mdui-collapse-item></mdui-collapse>`).join('');
    const talentsSection=selected.length||automatic?`<mdui-collapse accordion="" class="collapse-shell" value="${automatic?'panel':''}"><mdui-collapse-item value="panel" class="compact-details" ${automatic?'open':''}><mdui-list-item slot="header" class="collapse-heading"><h2>${automatic?(r.pinnedTalentIds?.length?'携带天赋':'推荐天赋'):'目标天赋'}</h2><span class="muted">${selected.length}项 · ${r.fees}/${r.capacity}费</span></mdui-list-item><div class="detail-content">${automatic&&r.pinnedTalentIds?.length?`<p class="hint carry-origin-summary">自选${r.pinnedTalentIds.length}项 · 自动补充${selected.length-r.pinnedTalentIds.length}项</p>`:''}${talentRows||'<p class="hint">当前点数与容量下，没有推荐天赋。</p>'}<p class="hint">解锁后在游戏里装备，天赋升级材料另算。</p></div></mdui-collapse-item></mdui-collapse>`:'';
    const allocation=r.stars.map(star=>`<mdui-collapse accordion="" class="collapse-shell" value=""><mdui-collapse-item value="panel" class="allocation"><mdui-list-item slot="header" class="collapse-heading"><div><strong>${esc(starTitle(star.id))}</strong><span class="star-location">${esc(starLocation(star.id))}</span></div><span>${star.cost}点</span><span aria-hidden="true">›</span></mdui-list-item><div class="allocation-body">${star.nodes.map(node=>`<div class="allocation-line"><span>${esc(nodeTitle(node))}</span><span>${node.level?'Lv'+node.level+' · '+node.cost+'点':'不点'}</span></div>`).join('')}</div></mdui-collapse-item></mdui-collapse>`).join('');
    const elements=r.elementBenefits.length?`<mdui-collapse accordion="" class="collapse-shell" value=""><mdui-collapse-item value="panel" class="compact-details element-benefits"><mdui-list-item slot="header" class="collapse-heading"><h2>四元素收益</h2><span class="muted">${r.elementTargets.length+(r.elementStarResults?.length||0)}项目标</span></mdui-list-item><div class="detail-content">${r.elementBenefits.map(element=>`<h3>${esc(element.name)}</h3>${element.values.map(value=>`<div class="element-value"><span>${esc(value.name)}</span><strong>+${value.value}</strong></div>`).join('')}`).join('')}<p class="hint">含前置节点收益。</p></div></mdui-collapse-item></mdui-collapse>`:'';
    $('result-view').innerHTML=`
      <div class="page-heading"><div><div class="eyebrow">${esc(r.profileName||profileName())}</div><h1 id="result-title">加点方案</h1></div><span class="pill">${esc(ruleNames[r.strategy]||ruleNames.crit)}</span></div>
      <mdui-card class="result-hero" variant="filled"><div class="stats">${hero.map(([label,value])=>`<div><div class="stat-label">${label}</div><div class="stat-value"><span>+</span>${formatNumber(value)}</div></div>`).join('')}</div><div class="points-summary"><span>${r.spent}/${r.budget}点</span><span>剩余${r.remaining}点</span></div>${automatic?`<div class="score-breakdown"><div><span>节点</span><strong>+${formatNumber(r.nodePowerReference)}</strong></div><div><span>账号天赋</span><strong>+${formatNumber(r.talentPowerReference)}</strong></div></div>`:''}</mdui-card>
      ${r.pvpResult?`<mdui-card class="card pvp-results" variant="filled"><div class="section-heading"><h2>${esc(pvpRules.presets.find(p=>p.key===r.pvpResult.preset).name)}</h2><strong>${r.pvpResult.balance===null?'无可达属性':(r.pvpResult.balance*100).toFixed(1)+'%加权均衡度'}</strong></div><p class="goal-status">高收益生命 +${formatNumber(r.pvpResult.life.value)} · ${r.pvpResult.life.nodes.length}/${r.pvpResult.life.available}个节点</p><p class="hint">${r.pvpResult.life.nodes.length?r.pvpResult.life.nodes.map(n=>esc(n.name)+'第'+n.row+'行 Lv'+n.level).join('、'):'当前预算与目标下，暂无可投入的高收益生命节点。'}</p><div class="pvp-result-head"><span>属性</span><span>增量 / 可达上限</span><span>达成率</span></div>${r.pvpResult.attributes.map(a=>`<div class="pvp-result-row"><span>${a.name}<small class="pvp-result-weight">权重 ${a.weight??1}</small></span><strong>+${formatNumber(a.value)} / ${formatNumber(a.maximum)}</strong><span>${a.ratio===null?'不可达':(a.ratio*100).toFixed(1)+'%'}</span></div>`).join('')}<p class="hint">上限保留本套生命优选收益，按相同预算与全部目标分别求解；各项上限通常不能同时达到。零权重和不可达项不参与加权均衡。</p><p class="hint">属性均衡参考，非实战伤害或胜率最优。同均衡度先优化高权重属性，权重相同按属性列表顺序择优。</p></mdui-card>`:''}
      ${custom?`<p class="goal-status">暴击目标 ≥${r.critTarget} · 已达标</p>`:''}
      <p class="result-meta">${guideGroups().length}步${selected.length?' · '+selected.length+'项天赋':''} · ${r.pvpResult?'所选属性均衡最优':automatic?'按账号实际等级计算':'暴击为点数，非暴击率'}</p>
      <div class="action-row"><mdui-button class="primary-button" data-go="guide" variant="filled">开始加点</mdui-button><mdui-button class="secondary-button" data-guide-card aria-label="生成攻略卡" variant="outlined">攻略卡</mdui-button></div>
      ${r.remaining?`<p class="hint">剩余${r.remaining}点可分配给其他属性。</p>`:''}
      ${r.elementRuleResults?.length?`<mdui-card class="card element-goal-results" variant="filled"><h2>元素目标 · 已达标</h2>${r.elementRuleResults.map(rule=>`<p>${esc(elementRules.resultLabel(rule))}</p>`).join('')}<p class="hint">实投仅计元素盘；公共前置已计入总耗点。</p></mdui-card>`:''}${r.elementStarResults?.length?`<mdui-collapse accordion="" class="collapse-shell" value=""><mdui-collapse-item value="panel" class="compact-details"><mdui-list-item slot="header" class="collapse-heading"><h2>元素逐行等级</h2><span class="muted">${r.elementStarResults.length}个星宿</span></mdui-list-item><div class="detail-content">${r.elementStarResults.map(s=>`<h3>${esc(s.name)} · ${s.spent}点</h3><p class="hint">${esc(s.location)}</p>${s.rows.map(n=>`<div class="element-value"><span>${n.row}. ${esc(n.attribute)}</span><strong>${n.level?'Lv'+n.level+' · ＋'+n.value:'不点'}</strong></div>`).join('')}`).join('')}</div></mdui-collapse-item></mdui-collapse>`:''}${talentsSection}${elements}
      <mdui-collapse accordion="" class="collapse-shell" value=""><mdui-collapse-item value="panel" class="compact-details"><mdui-list-item slot="header" class="collapse-heading"><h2>收益明细</h2></mdui-list-item><div class="detail-content result-stats">${[['暴击',r.crit],['攻击',r.attack],['穿透',r.penetration],['战力参考',r.powerReference]].map(([label,value])=>`<div><span>${label}</span><strong>+${formatNumber(value)}</strong></div>`).join('')}</div></mdui-collapse-item></mdui-collapse>
      <mdui-collapse accordion="" class="collapse-shell" value=""><mdui-collapse-item value="panel" class="compact-details"><mdui-list-item slot="header" class="collapse-heading"><h2>星宿分配</h2><span class="muted">${r.stars.length}个星宿</span></mdui-list-item><div class="detail-content">${allocation}</div></mdui-collapse-item></mdui-collapse>
      <div class="more-actions"><mdui-button class="text-button" data-go="config" variant="text">调整配置</mdui-button><mdui-button class="text-button" data-copy aria-label="复制方案" variant="text">复制指导</mdui-button><mdui-button class="text-button" data-plan-code variant="text">方案码</mdui-button><mdui-button class="text-button" data-share variant="text">文字分享</mdui-button></div>`;
  }
  function planKey() {
    if (!state.result || state.result.status !== 'optimal') return '';
    const content = [data.sourceSha256, state.result.budget, state.result.targetIds.slice().sort((a, b) => a - b), state.result.levels];
    if(state.result.pvpResult)content.push(['pvp',state.result.pvpResult.attrIds]);
    if(state.result.critTarget!==undefined)content.push(['crit-target',state.result.critTarget]);
    if(state.result.elementRules?.length)content.push(['elements',state.result.elementRules]);
    if(state.result.elementStars?.length)content.push(['element-stars',state.result.elementStars]);
    if(state.profileId)content.push(state.profileId);
    const text = JSON.stringify(content);
    let h = 2166136261; for (let i = 0; i < text.length; i++) h = Math.imul(h ^ text.charCodeAt(i), 16777619);
    return 'star-guide-' + (h >>> 0).toString(16);
  }
  function loadChecks() {
    state.checked = new Set(); if (!planKey()) return;
    try {
      let saved = JSON.parse(localStorage.getItem('star-guide-progress-'+planKey()) || localStorage.getItem('star-guide-progress') || 'null');
      if (globalThis.AndroidPlanner && typeof AndroidPlanner.getGuideProgress === 'function') {
        const shared = AndroidPlanner.getGuideProgress(planKey());
        if (shared !== null) saved = { plan: planKey(), ids: JSON.parse(shared) };
      }
      if (saved && saved.plan === planKey() && Array.isArray(saved.ids)) {
        for (const step of state.result.steps) if (saved.ids.includes(step.id) && nodeById.get(step.id).pre.every(id => state.checked.has(id))) state.checked.add(step.id);
      }
    } catch { /* 损坏的勾选记录不影响重新计算和查看方案。 */ }
  }
  function saveChecks() {
    try {
      const raw=JSON.stringify({ plan: planKey(), ids: [...state.checked] });
      localStorage.setItem('star-guide-progress',raw);localStorage.setItem('star-guide-progress-'+planKey(),raw);
      if (globalThis.AndroidPlanner && typeof AndroidPlanner.saveGuideProgress === 'function' && !AndroidPlanner.saveGuideProgress(planKey(), JSON.stringify([...state.checked]))) toast('悬浮窗进度未能同步');
    } catch { toast('勾选记录未能保存'); }
  }

  // 展示按星宿合并，节点顺序与勾选标识保持不变，兼容已有进度和逐级战力取整。
  function guideGroups() {
    const groups=new Map();
    for(const node of state.result.steps){
      if(!groups.has(node.starId))groups.set(node.starId,{starId:node.starId,location:node.location,nodes:[],cost:0,cumulative:0});
      const group=groups.get(node.starId);group.nodes.push(node);group.cost+=node.cost;group.cumulative=node.cumulative;
    }
    return [...groups.values()];
  }
  // 只传递当前已验证方案及手动勾选，不向悬浮窗开放游戏数据或系统文件。
  function floatingPlan() {
    const r = state.result;
    return {
      key: planKey(), name: r.profileName || profileName(), goal: [pvpText(r),critTargetText(r),elementGoalText(r)].filter(Boolean).join('\n'), talents: r.autoTalents?r.unlocked.filter(t=>t.selected).map(t=>starTitle(t.starId)+' · '+(t.pinned?'自选':'补充')+' · '+quality[t.quality]+'天赋 · Lv'+t.equippedLevel+' · '+t.cost+'费 · 战力参考+'+t.power+'\n'+t.effects[(t.equippedLevel||1)-1]):[], budget: r.budget, spent: r.spent, checked: [...state.checked],
      steps: r.steps.map(step => ({ id: step.id, starId: step.starId, title: starTitle(step.starId), row: step.row, attribute: step.attribute, location: step.location, levelText: levelText(step), level: step.level, value: step.value, cost: step.cost, cumulative: step.cumulative, preIds: nodeById.get(step.id).pre, preText: step.pre.join('、') })),
      groups: guideGroups().map(group => { const star=r.stars.find(s=>s.id===group.starId);return { title: starTitle(star.id), location: starLocation(star.id), cost: star.cost, rows: star.nodes.map(node => ({ id: node.id, row: node.row, attribute: node.attribute, level: node.level })) }; })
    };
  }
  function renderGuide() {
    const r=state.result;if(!r||r.status!=='optimal')return;
    const fullOpen=!!$('complete-guide')?.open,moreOpen=!!$('guide-options')?.open;
    const opened=new Set([...$('guide-view').querySelectorAll('.guide-group[open]')].map(el=>el.dataset.guideStar));
    const guide=guideGroups(),isDone=group=>group.nodes.every(n=>state.checked.has(n.id));
    const current=guide.find(group=>!isDone(group)),count=guide.filter(isDone).length;
    const steps=new Map(r.steps.map(step=>[step.id,step]));
    const rowsFor=(star,withDetails=true)=>star.nodes.map(node=>{
      const step=steps.get(node.id);
      if(!step)return `<div class="guide-step skipped"><span class="row-placeholder" aria-hidden="true"></span><span class="guide-step-main"><strong>${esc(nodeTitle(node))} · 不点</strong></span></div>`;
      return `<div class="guide-entry"><label class="guide-step ${state.checked.has(step.id)?'checked':''}"><mdui-checkbox data-step="${step.id}" ${state.checked.has(step.id)?'checked':''}></mdui-checkbox><span class="guide-step-main"><strong>${esc(nodeTitle(step))} → Lv${step.level}</strong><small>+${step.value} · ${step.cost}点</small></span></label>${withDetails?levelDetails(step):''}</div>`;
    }).join('');
    const order=group=>`<p class="hint">点亮顺序：${group.nodes.map(n=>n.row).join(' → ')}行</p>`;
    const active=current?`<mdui-card class="current-step" variant="filled"><div class="step-kicker">第${guide.indexOf(current)+1}/${guide.length}步 · ${current.cost}点</div><h2>${esc(starTitle(current.starId))}</h2><p class="location-note">${esc(current.location)}</p>${order(current)}${rowsFor(r.stars.find(s=>s.id===current.starId),false)}<mdui-collapse accordion="" class="collapse-shell" value=""><mdui-collapse-item value="panel" class="level-details"><mdui-list-item slot="header" class="collapse-heading">每级属性与战力</mdui-list-item>${current.nodes.map(node=>`<h3>${esc(nodeTitle(node))}</h3>${levelTable(node)}`).join('')}</mdui-collapse-item></mdui-collapse><div class="step-cost"><span>本步完成后</span><span>累计${current.cumulative}/${r.spent}点</span></div><mdui-button class="primary-button" data-done-star="${current.starId}" variant="filled">完成本星宿，下一步</mdui-button></mdui-card>`:`<mdui-card class="complete-card" variant="filled"><strong>${guide.length?'全部加点已完成':'当前没有加点步骤'}</strong><p>${r.targetIds.length?'记得在游戏里装备天赋。':'可返回方案复核配置。'}</p><mdui-button class="secondary-button" data-go="${guide.length?'result':'config'}" variant="outlined">${guide.length?'查看方案':'调整配置'}</mdui-button></mdui-card>`;
    const groups=guide.map((group,i)=>{
      const star=r.stars.find(s=>s.id===group.starId),complete=group.nodes.filter(node=>state.checked.has(node.id)).length;
      return `<mdui-collapse accordion="" class="collapse-shell" value="${opened.has(String(star.id))?'panel':''}"><mdui-collapse-item value="panel" class="guide-group" data-guide-star="${star.id}" ${opened.has(String(star.id))?'data-loaded="true"':''} ${opened.has(String(star.id))?'open':''}><mdui-list-item slot="header" class="collapse-heading"><div>第${i+1}步 · ${esc(starTitle(star.id))}<small class="star-location">${esc(starLocation(star.id))}</small></div><span>${complete}/${group.nodes.length}项 · ${star.cost}点</span></mdui-list-item>${opened.has(String(star.id))?order(group)+rowsFor(star):''}</mdui-collapse-item></mdui-collapse>`;
    }).join('');
    $('guide-view').innerHTML=`<div class="page-heading"><h1 id="guide-title">加点指导</h1><mdui-button class="text-button" data-floating-open variant="text">悬浮指导</mdui-button></div>${r.pvpResult?`<p class="goal-status">${esc(pvpRules.label(r.pvpResult))} · 属性均衡参考</p>`:''}${r.critTarget===undefined?'':`<p class="goal-status">目标暴击 ≥${r.critTarget} · 实际+${r.crit}</p>`}${(r.elementRuleResults?.length||r.elementStarResults?.length)?`<p class="goal-status">${esc(elementGoalText(r)).replace(/\n/g,'<br>')}</p>`:''}<div class="guide-progress"><mdui-linear-progress class="progress-track" aria-label="加点进度"></mdui-linear-progress><span>${count}/${guide.length}步</span></div>${active}<mdui-collapse accordion="" class="collapse-shell" value="${fullOpen?'panel':''}"><mdui-collapse-item value="panel" id="complete-guide" class="compact-details" ${fullOpen?'data-loaded="true"':''} ${fullOpen?'open':''}><mdui-list-item slot="header" class="collapse-heading"><h2>完整加点清单</h2><span class="muted">${guide.length}步</span></mdui-list-item><div class="detail-content">${fullOpen?groups:''}</div></mdui-collapse-item></mdui-collapse><mdui-collapse accordion="" class="collapse-shell" value="${moreOpen?'panel':''}"><mdui-collapse-item value="panel" id="guide-options" class="compact-details guide-options" ${moreOpen?'open':''}><mdui-list-item slot="header" class="collapse-heading"><h2>更多操作</h2></mdui-list-item><div class="detail-content more-actions"><mdui-button class="text-button" data-copy variant="text">复制完整指导</mdui-button><mdui-button class="text-button" data-share variant="text">分享</mdui-button><mdui-button class="text-button" data-reset-checks variant="text">重置进度</mdui-button><mdui-button class="text-button" data-floating-close variant="text">关闭悬浮窗</mdui-button></div></mdui-collapse-item></mdui-collapse>`;
    const bar=$('guide-view').querySelector('mdui-linear-progress');bar.max=guide.length||1;bar.value=count;
  }
  // 完整清单和星宿逐级明细按展开加载，避免初次计算创建大量隐藏组件。
  $('guide-view').addEventListener('toggle',event=>{const item=event.target;if(item.open&&(item.id==='complete-guide'||item.dataset.guideStar)&&!item.dataset.loaded){item.dataset.loaded='true';requestAnimationFrame(()=>{if(item.isConnected&&item.open)renderGuide();});}},true);
  function markStep(id, checked) {
    const steps = state.result.steps, step = steps.find(s => s.id === id);
    const node = nodeById.get(id);
    if (checked && node.pre.some(p => !state.checked.has(p))) { toast('请先完成本步的前置节点'); renderGuide(); return; }
    if (checked) state.checked.add(id);
    else {
      state.checked.delete(id); let changed = true;
      while (changed) { changed = false; for (const s of steps) if (state.checked.has(s.id) && nodeById.get(s.id).pre.some(p => !state.checked.has(p))) { state.checked.delete(s.id); changed = true; } }
    }
    saveChecks(); renderGuide();
  }
  $('guide-view').addEventListener('change', e => { if (e.target.dataset.step) markStep(Number(e.target.dataset.step), e.target.checked); });
  $('guide-view').addEventListener('click', e => {
    if (e.target.closest('[data-floating-open]')) {
      if (!state.result || state.result.status !== 'optimal' || !state.result.steps.length) { toast('当前没有可显示的加点步骤'); return; }
      if (!globalThis.AndroidPlanner || typeof AndroidPlanner.showFloatingGuide !== 'function') { toast('悬浮指导需使用安卓安装版'); return; }
      AndroidPlanner.showFloatingGuide(JSON.stringify(floatingPlan()));
    }
    if (e.target.closest('[data-floating-close]') && globalThis.AndroidPlanner && typeof AndroidPlanner.hideFloatingGuide === 'function') AndroidPlanner.hideFloatingGuide();
    const done = e.target.closest('[data-done-star]');
    if(done){
      const group=guideGroups().find(g=>g.starId===Number(done.dataset.doneStar)),checked=new Set(state.checked);
      for(const node of group.nodes){if(nodeById.get(node.id).pre.some(id=>!checked.has(id))){toast('请先完成本星宿的前置节点');return;}checked.add(node.id);}
      state.checked=checked;saveChecks();renderGuide();$('guide-view').querySelector('.current-step,.complete-card')?.scrollIntoView({block:'start'});
    }
    if (e.target.closest('[data-reset-checks]')) { state.checked.clear(); saveChecks(); renderGuide(); toast('进度已重置'); }
  });
  function guideText() {
    const r = state.result; if (!r || r.status !== 'optimal') return '';
    const selected = r.unlocked.filter(t => t.selected);
    const rows = r.stars.flatMap(star => ['', '【' + starTitle(star.id) + ' / ' + star.family + '】' + star.cost + '点', '方位：' + starLocation(star.id), ...star.nodes.map(node => nodeTitle(node) + '：' + (node.level ? 'Lv' + node.level + '，' + node.cost + '点' : '不点'))]);
    if(r.pvpResult)rows.unshift(pvpText(r));
    if(r.critTarget!==undefined)rows.unshift('自定义目标：'+critTargetText(r));
    if(r.elementRuleResults?.length||r.elementStarResults?.length)rows.unshift('元素目标（实投不含公共前置）：\n'+elementGoalText(r));
    return ['妄想山海 · 星宿配置方案', '方案：'+(r.profileName || profileName()), '优先规则：先满足全部目标；'+r.objective, `星宿点：${r.spent} / ${r.budget}，剩余${r.remaining}`, `大荒节点收益：暴击+${r.crit}，攻击+${r.attack}，穿透+${r.penetration}`, `资源计分参考：+${r.powerReference}`, ...(r.autoTalents?[`节点战力参考：+${r.nodePowerReference}；携带天赋战力参考：+${r.talentPowerReference}`,`自动携带：按账号实际等级，${r.targetIds.length} / ${r.carryLimit}项`]:[]), `天赋费用：${r.fees} / ${r.capacity}`, '所选元素属性：' + (r.elementTargets.map(e => e.name).concat((r.elementStarResults||[]).map(s=>s.name+'逐行设置')).join('、') || '未选'), ...r.elementBenefits.flatMap(e => e.values.map(v => v.name + '+' + v.value)), '', r.autoTalents?'推荐携带天赋（账号实际等级）：':'目标天赋：', ...selected.map(t => `${starTitle(t.starId)}·${quality[t.quality]}（${t.cost}费）${r.autoTalents?' · '+(t.pinned?'自选':'补充')+' · Lv'+t.equippedLevel+' · 战力参考+'+t.power+' · '+t.effects[(t.equippedLevel||1)-1]:''}`), selected.length ? '' : '未指定', '方位按星盘默认俯视朝向标注；旋转后请恢复默认方向。', '各星象属性（游戏内从上到下，未投入的行标为“不点”）：', ...rows, '', '从零加点顺序（按前置）：', ...guideGroups().flatMap((group, i) => [`${i + 1}. ${starTitle(group.starId)} / ${group.location}；本星宿${group.cost}点，累计${group.cumulative}点`, '    点亮顺序：'+group.nodes.map(n=>n.row).join(' → ')+'行', ...group.nodes.flatMap(step => [`    ${nodeTitle(step)} → Lv${step.level}；${step.attribute}+${step.value}；${step.cost}点${step.pre.length ? '；前置：' + step.pre.join('、') : ''}`, ...levelText(step).split('\n').map(line => '        ' + line)])]), '', '战力按资源计分规则，依本方案顺序从零累计属性并处理取整；未包含角色当前的额外比例加成和状态，实际以游戏显示为准。', '解锁后在天赋配置中装备所选条目。暴击点数不等同于暴击率。'].join('\n');
  }
  // 分享附软件下载页，复制加点清单仍保持纯指导内容。
  function shareText() { const text=guideText();return text?text+'\n\n软件下载：https://wutong.leeyan.site/download':''; }
  document.addEventListener('click', async e => {
    if (e.target.closest('[data-copy]')) {
      try { if (globalThis.AndroidPlanner) { if (!AndroidPlanner.copyText(guideText())) throw new Error('复制失败'); } else await navigator.clipboard.writeText(guideText()); toast('已复制完整加点方案'); }
      catch { toast('复制失败，请使用分享功能'); }
    }
    if (e.target.closest('[data-share]')) {
      try { if (globalThis.AndroidPlanner) AndroidPlanner.shareText(shareText()); else if (navigator.share) await navigator.share({ title: '星宿配置方案', text: shareText() }); else { await navigator.clipboard.writeText(shareText()); toast('已复制方案，可粘贴分享'); } }
      catch (error) { if (error.name !== 'AbortError') toast('未能打开分享，请尝试复制方案'); }
    }
  });
  globalThis.handlePlannerBack = () => {
    if(globalThis.NativeUI?.back())return true;
    if(globalThis.ShareUI?.back())return true;
    if(globalThis.PersonalUI?.back()||globalThis.CommunityUI?.back())return true;
    if(globalThis.ChiyouTool?.back())return true;
    if(globalThis.EquipmentTool?.back())return true;
    if (MutationTool.back()) return true;
    if ($('qq-group').open) { $('qq-group').close(); return true; }
    if ($('appreciation').open) { $('appreciation').close(); return true; }
    if ($('picker').open) { closePicker(); return true; }
    if ($('profile-name-dialog').open) { $('profile-name-dialog').close(); return true; }
    if ($('profile-delete-dialog').open) { $('profile-delete-dialog').close(); return true; }
    if ($('about').open) { $('about').close(); return true; }
    const menu=document.querySelector('.profile-manage');if(menu.open){menu.open=false;return true;}
    if(state.busy){state.sequence++;stopWorker();setBusy(false);toast('已取消计算');return true;}
    if(state.route==='guide'){route('result');return true;}
    if(state.route==='result'){route('config');return true;}
    if(state.route==='config'){route('home');return true;}
    if(state.route==='mutation'){route('home');return true;}
    if(state.route==='collection'){route(floatingLookup?'mutation':'home');return true;}
    if(state.route==='talents'&&globalThis.AccountTalentUI?.back())return true;
    if(['compare','community','clock','chiyou','beasts','talents','equipment'].includes(state.route)){route('home');return true;}
    return false;
  };
  globalThis.handlePlannerResume = () => {
    globalThis.BeastTimersUI?.refresh();
    if (state.result && state.result.status === 'optimal') { loadChecks(); renderGuide(); if(state.route==='home')renderHome(); }
    if(state.route==='collection')globalThis.PersonalUI?.openCollections();
    if(state.route==='clock')globalThis.ClockUI?.refresh();
  };
  // 只向本机工具模块提供方案操作，不开放任意文件路径或游戏接口。
  globalThis.PlannerApp={route,toast,
    shareContext(){return {config:snapshot(),result:state.result?JSON.parse(JSON.stringify(state.result)):null};},
    importSharedPlan(config){
      const checked=PersonalCore.validateConfig(config,data);createPlannerEngine(data).prepare({budget:Number(checked.budget),capacity:Number(checked.capacity),strategy:checked.strategy,pvp:checked.pvp,talentIds:checked.selected,elementKeys:checked.elements,elementRules:checked.elementRules,elementStars:checked.elementStars,critTarget:checked.strategy==='crit-target'?Number(checked.critTarget):undefined});
      const id=crypto.randomUUID();this.importBackup({plans:[{id,name:(ruleNames[checked.strategy]+' '+checked.budget+'点').slice(0,24),config:checked}],draft:null,active:'',progress:{},source:data.sourceSha256});this.openProfile(id);
    },
    listPlans(){saveDraft();return JSON.parse(JSON.stringify(savedPlans));},
    openProfile(id){route('config',true);$('profile-select').value=id;$('profile-select').dispatchEvent(new Event('change'));},
    backup(){
      if(!saveDraft())throw new Error('本机方案未能保存');
      for(const config of [...savedPlans.map(p=>p.config),draftPlan].filter(Boolean))PersonalCore.validateConfig(config,data);
      if(state.result?.status==='optimal'){loadChecks();saveChecks();}
      const progress={};for(let i=0;i<localStorage.length;i++){const key=localStorage.key(i);if(/^star-guide-progress-star-guide-[a-f0-9]+$/.test(key))progress[key.slice(20)]=JSON.parse(localStorage.getItem(key));}
      const talentLevels=accountTalents.get();
      return JSON.stringify({format:'wutong-star-backup',schema:5,talentLevels,source:data.sourceSha256,createdAt:new Date().toISOString(),plans:savedPlans,draft:draftPlan,active:state.profileId,progress},null,2);
    },
    importBackup(incoming){
      if(!saveDraft())throw new Error('本机方案未能保存');
      const merged=PersonalCore.mergeBackup(savedPlans,incoming,()=>Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,9));
      const writes=new Map(),session=JSON.parse(localStorage.getItem(storeKey)||'{}');
      if(incoming.talentLevels!==undefined)writes.set(accountTalents.key,accountTalents.serialize(incoming.talentLevels));
      const restoreDraft=savedPlans.length===0&&!session.budget;
      writes.set(profilesKey,JSON.stringify({plans:merged.plans,draft:restoreDraft?incoming.draft:draftPlan,deleted:deletedPlan}));
      if(restoreDraft){const active=merged.plans.find(p=>p.id===incoming.active);writes.set(storeKey,JSON.stringify({...active?.config||incoming.draft||snapshot(),profileId:active?.id||''}));}
      if(!merged.remapped.size&&incoming.source===data.sourceSha256)for(const [key,value]of Object.entries(incoming.progress)){const storageKey='star-guide-progress-'+key;if(!localStorage.getItem(storageKey))writes.set(storageKey,JSON.stringify(value));}
      const previous=new Map([...writes.keys()].map(key=>[key,localStorage.getItem(key)]));
      try{for(const [key,value]of writes)localStorage.setItem(key,value);}catch(error){for(const [key,value]of previous){try{if(value===null)localStorage.removeItem(key);else localStorage.setItem(key,value);}catch{}}throw new Error('存储空间不足，导入未完成');}
      if(typeof globalThis.AndroidPlanner?.hideFloatingGuide==='function')AndroidPlanner.hideFloatingGuide();
      loadDraft();updateSelection();updateElements();state.result=null;renderHome();updateNavigation();document.dispatchEvent(new CustomEvent('account-talents-changed'));return merged;
    }
  };
  loadDraft(); updateSelection(); updateElements(); renderHome(); updateNavigation();
  if(floatingLookup)route('mutation',true);
})();
