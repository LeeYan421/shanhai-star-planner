/* 词条查询独立保存筛选状态，首次进入才加载本地资料。 */
(() => {
  'use strict';
  const $=id=>document.getElementById(id),esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const paths={weapon:'m6 18 3-3m0 0L18 3l3-1-1 3L9 15ZM4 12l8 8M4 20l-2 2',helmet:'M4 18v-6a8 8 0 0 1 16 0v6l-5 3h-6ZM4 12h16M9 12v4m6-4v4M12 4V1',body:'m8 3-6 4 3 5 3-1v10h8V11l3 1 3-5-6-4-4 3ZM8 13h8',shoulder:'M12 3 3 7l-1 8 5 4 5-4 5 4 5-4-1-8ZM3 9l5 3 4-3 4 3 5-3',mask:'m4 4 8 3 8-3-2 13-6 5-6-5ZM7 10l3 2m4 0 3-2m-7 7h4',earring:'M12 3a5 5 0 0 1 4 8l-2 2v3h-4v-3l-2-2a5 5 0 0 1 4-8Zm0 13-4 4 4 3 4-3ZM12 1v4',ring:'M7 10a8 8 0 1 0 10 0M7 5l5-3 5 3-5 7ZM7 5h10'};
  const icon=part=>`<svg aria-hidden="true" slot="icon" viewBox="0 0 24 24"><path d="${paths[part]}"/></svg>`;
  const state={index:null,loading:false,subject:'player',goal:'combat',part:'weapon',type:10100,grade:'',quality:'',tab:'recommend',search:'',special:false,limit:24,result:null,detail:null,detailTab:'qualities',sourceQuery:'',sourceLimit:36};
  const format=value=>Number(value.toFixed(3)).toLocaleString('zh-CN',{maximumFractionDigits:3}),valueLabel=word=>word.value===null?'效果词条':format(word.value)+word.unit;
  function syncFilters(){
    const types=state.index.weaponTypes(state.subject);if(!types.some(t=>t.id===state.type))state.type=types[0]?.id||0;
    const typeKey=types.map(t=>t.id).join(',');if($('eq-type').dataset.options!==typeKey){$('eq-type').innerHTML=types.map(t=>`<mdui-menu-item value="${t.id}">${esc(t.name)}</mdui-menu-item>`).join('');$('eq-type').dataset.options=typeKey;}$('eq-type').value=String(state.type);$('eq-type').classList.toggle('hidden',state.part!=='weapon');
    const grades=state.index.grades(state);if(!grades.includes(state.grade))state.grade=grades.find(g=>g==='15品史诗')||grades[0]||'';
    const gradeKey=grades.join(',');if($('eq-grade').dataset.options!==gradeKey){$('eq-grade').innerHTML=grades.map(g=>`<mdui-menu-item value="${esc(g)}">${esc(g)}</mdui-menu-item>`).join('');$('eq-grade').dataset.options=gradeKey;}$('eq-grade').value=state.grade;
    $('eq-quality').value=state.quality||'all';
    if(!$('eq-parts').children.length)$('eq-parts').innerHTML=state.index.data.parts.map(p=>`<mdui-button variant="text" aria-pressed="${state.part===p.id}" data-eq-part="${p.id}">${icon(p.id)}${esc(p.name)}</mdui-button>`).join('');
    $('eq-parts').querySelectorAll('[data-eq-part]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.eqPart===state.part)));
    for(const [key,attribute]of[['subject','data-eq-subject'],['goal','data-eq-goal']]){$('eq-'+key).value=state[key];document.querySelectorAll('['+attribute+']').forEach(b=>b.setAttribute('aria-pressed',String(b.getAttribute(attribute)===state[key])));}
  }
  function rowHtml(row,i){const w=row.word,virtual=state.goal==='power';return `<mdui-card class="eq-row" variant="filled" clickable role="button" tabindex="0" data-eq-word="${row.key}" aria-label="查看${esc(row.name)}详情"><span class="eq-rank">${String(i+1).padStart(2,'0')}</span><span><strong>${esc(row.name)}</strong>${row.special?'<span class="eq-tag">特殊</span>':''}<p>${esc(virtual?w.description:row.rule.reason)}</p></span><span class="eq-value">${virtual?format(w.power):esc(valueLabel(w))}<small>${virtual?'词条配置战力':esc(state.index.data.qualities[w.quality]+'上限')}　›</small></span></mdui-card>`;}
  function render(){
    if(!state.index)return;const catalog=state.tab==='catalog',options={...state,search:catalog?state.search:'',special:catalog&&state.special};state.result=state.index.query(options);const {rows,sources,combination}=state.result;
    $('eq-tabs').value=state.tab;document.querySelectorAll('[data-eq-tab]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.eqTab===state.tab)));
    $('eq-recommend').classList.toggle('hidden',catalog);$('eq-catalog-tools').classList.toggle('hidden',!catalog);$('eq-list-title').textContent=catalog?'可携带词条':state.goal==='power'?'战力从高到低':'推荐顺序';$('eq-count').textContent=`${rows.length}类词条 · ${new Set(sources.map(x=>x.name)).size}种来源装备`;
    const name=state.part==='weapon'?state.index.types.get(state.type)?.name:state.index.data.parts.find(p=>p.id===state.part)?.name;
    $('eq-scope').textContent=(state.subject==='player'?'人物':'侍从')+' · '+state.grade+' · '+(state.index.data.qualities[Number(state.quality)]&&state.quality!==''?state.index.data.qualities[Number(state.quality)]+'词条':'全部词条品质');
    $('eq-heading').textContent=name+' · '+(state.goal==='power'?'虚战搭配':'实战搭配');
    $('eq-summary').textContent=state.goal==='power'?'优先选择词条配置战力较高的属性，具体战力以游戏装备结果为准。':'优先考虑增伤与输出属性；距离、元素不匹配时，换用暴击、攻击等通用候选。';
    $('eq-combination').innerHTML=combination?combination.rows.map(row=>`<mdui-card variant="filled" clickable role="button" tabindex="0" data-eq-word="${row.key}" data-eq-variant="${row.word.id}" aria-label="查看${esc(row.name)}详情"><strong>${esc(row.name)}</strong><span>${state.goal==='power'?format(row.word.power)+' 战力':esc(valueLabel(row.word))}</span></mdui-card>`).join(''):'';
    $('eq-combination-note').textContent=combination?'目标：'+combination.item.name+'。已纳入同类、同品质及以下来源；实际条数与互斥以游戏为准。':'当前品质暂无兼容搭配，试试全部词条品质。';
    $('eq-results').innerHTML=rows.slice(0,state.limit).map(rowHtml).join('')||'<p class="eq-empty">没有匹配的词条<br>试试其他品质、品阶或搜索词。</p>';$('eq-more').classList.toggle('hidden',rows.length<=state.limit);
    $('eq-footnote').textContent=state.index.data.sourceNote+' 实战为通用参考排序，条件词条请先核对生效范围。';
  }
  async function open(){
    if(state.index){render();return;}if(state.loading)return;state.loading=true;$('equipment-status').textContent='正在读取装备资料…';$('equipment-retry').classList.add('hidden');
    try{const response=await fetch('equipment-data.json');if(!response.ok)throw new Error('装备资料载入失败');state.index=EquipmentCore.createEquipmentIndex(await response.json());syncFilters();render();$('equipment-status').textContent='';$('equipment-content').classList.remove('hidden');}
    catch(error){globalThis.Diagnostics?.record('equipment',error);$('equipment-status').textContent='装备资料载入失败，请重试';$('equipment-retry').classList.remove('hidden');}finally{state.loading=false;}
  }
  function renderDetail(){
    const row=state.detail;if(!row)return;$('eq-detail-title').textContent=row.name;
    const matching=state.index.equivalentWords(row),conditionSets=[...new Map(matching.filter(w=>w.conditions.length).map(w=>[JSON.stringify(w.conditions.slice().sort()),w.conditions])).values()];
    const pending=matching.some(w=>w.unresolvedConditions||w.conditional&&!w.conditions.length);
    $('eq-detail-content').innerHTML=`<p class="eq-description">${esc(row.word.description)}</p>${conditionSets.map((conditions,i)=>`<p>${conditionSets.length>1?'条件版本 '+(i+1)+'：':''}${conditions.map(esc).join('；')}</p>`).join('')}${pending?'<p class="eq-filter-hint">部分生效条件尚未收录，不能视为常驻加成，请在游戏内核对。</p>':''}<mdui-tabs value="${state.detailTab}" full-width variant="secondary" aria-label="词条详情"><mdui-tab data-eq-detail-tab="qualities" value="qualities">各品质最高值</mdui-tab><mdui-tab data-eq-detail-tab="sources" value="sources">产出方式</mdui-tab></mdui-tabs><div id="eq-detail-panel"></div>`;
    if(state.detailTab==='qualities'){
      $('eq-detail-panel').innerHTML=`<p class="eq-filter-hint">目标：${esc(state.grade)} · ${state.subject==='servant'?'侍从装备':'人物装备'} · 含兼容来源上限</p><table class="eq-quality-table"><thead><tr><th>品质</th><th>最高值／效果与来源</th><th>配置战力</th></tr></thead><tbody>${state.index.qualityMax(row).map(({name,word,sources},i)=>`<tr><td><span class="mutation-quality" data-quality="${i}">${esc(name)}</span></td><td>${word?esc(word.value===null?word.description:valueLabel(word)):'—'}${word?`<br><small class="eq-filter-hint">${esc([...new Set(sources.map(x=>x.name+' · '+(x.grade||'品阶未收录')))].slice(0,2).join('、'))}</small>`:''}</td><td>${word?format(word.power):'—'}</td></tr>`).join('')}</tbody></table><p class="eq-filter-hint">已合并同类型、同装备品质及以下的词条来源，来源品阶可与目标不同。— 表示兼容范围未收录该品质。</p>`;
    }else{
      $('eq-detail-panel').innerHTML=`${row.methods.map(m=>`<div class="eq-source"><strong>${esc(m.name)}</strong><p>${esc(m.description)}</p><p>消耗：${m.materials.map(x=>esc(x.name)+' × '+x.count).join('、')}</p></div>`).join('')}<div class="eq-source"><strong>当前词条的产出装备</strong><p>包含可向目标装备转移的来源，具体掉落途径及转移限制尚未完整收录。</p></div><mdui-text-field id="eq-source-search" label="筛选可出装备" aria-label="筛选可出装备" value="${esc(state.sourceQuery)}" type="search" clearable variant="filled"></mdui-text-field><div class="eq-source-list" id="eq-source-items"></div><mdui-button id="eq-source-more" class="eq-detail-actions hidden" variant="text">加载更多装备</mdui-button><p class="eq-filter-hint">客户端配置参考，未核对当前实时投放。</p>`;renderSources();
    }
  }
  function renderSources(){const names=[...new Set(state.index.sourcesFor(state.detail).map(x=>x.name+' · '+(x.grade||'品阶未收录')))].filter(n=>n.includes(state.sourceQuery.trim())).sort((a,b)=>a.localeCompare(b,'zh-CN'));$('eq-source-items').innerHTML=names.slice(0,state.sourceLimit).map(n=>`<span>${esc(n)}</span>`).join('')||'<p>没有匹配的装备</p>';$('eq-source-more').classList.toggle('hidden',names.length<=state.sourceLimit);}
  function show(key,variant){const row=state.result.rows.find(r=>r.key===key);if(!row)return;state.detail={...row,word:row.variants.find(w=>w.id===Number(variant))||row.word};state.detailTab='qualities';state.sourceQuery='';state.sourceLimit=36;renderDetail();$('eq-detail').showModal();}
  function back(){for(const id of['eq-detail','eq-rules-dialog'])if($(id).open){$(id).close();return true;}return false;}
  $('equipment-view').addEventListener('click',event=>{
    const button=event.target.closest('[data-eq-part],[data-eq-subject],[data-eq-goal],[data-eq-tab],[data-eq-word]');if(!button||!state.index)return;
    if(button.dataset.eqWord){show(button.dataset.eqWord,button.dataset.eqVariant);return;}
    for(const key of['part','subject','goal','tab'])if(button.hasAttribute('data-eq-'+key))state[key]=button.getAttribute('data-eq-'+key);
    state.limit=24;syncFilters();render();
  });
  for(const key of['type','grade','quality'])$('eq-'+key).addEventListener('change',event=>{if(event.target!==$('eq-'+key)||!state.index)return;const raw=event.target.value,value=key==='type'?Number(raw):key==='quality'&&raw==='all'?'':raw;if(value===state[key])return;state[key]=value;state.limit=24;if(key!=='quality')syncFilters();render();});
  $('eq-query').addEventListener('input',()=>{state.search=$('eq-query').value;state.limit=24;render();});$('eq-special').addEventListener('change',()=>{state.special=$('eq-special').checked;state.limit=24;render();});
  $('eq-more').addEventListener('click',()=>{state.limit+=24;render();});$('equipment-retry').addEventListener('click',open);
  $('eq-detail-content').addEventListener('click',event=>{const tab=event.target.closest('[data-eq-detail-tab]');if(tab){state.detailTab=tab.dataset.eqDetailTab;renderDetail();}else if(event.target.closest('#eq-source-more')){state.sourceLimit+=36;renderSources();}});
  $('eq-detail-content').addEventListener('input',event=>{if(event.target.id==='eq-source-search'){state.sourceQuery=event.target.value;state.sourceLimit=36;renderSources();}});
  $('eq-detail-close').addEventListener('click',()=>$('eq-detail').close());$('eq-rules').addEventListener('click',()=>$('eq-rules-dialog').showModal());$('eq-rules-close').addEventListener('click',()=>$('eq-rules-dialog').close());
  globalThis.EquipmentTool={open,back,leave(){for(const id of['eq-detail','eq-rules-dialog'])if($(id).open)$(id).close();}};
})();
