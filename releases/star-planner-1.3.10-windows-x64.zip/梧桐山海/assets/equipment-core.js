/* 可出词条由实际装备池限定；实战采用公开的通用优先级，虚战使用客户端词条计分。 */
(function(root){
  'use strict';
  const excluded=['脑念仪','耳涡器','肩吞器','传动甲','指感仪','滤面甲'];
  const compareName=(a,b)=>a.localeCompare(b,'zh-CN'),unique=values=>[...new Set(values)];
  function combatRule(word){
    const name=word.name;
    if(word.unresolvedConditions)return {order:90,reason:'生效条件尚未完整收录，暂作候选'};
    if(word.conditional)return {order:80,reason:'触发型效果，需结合生效条件选择'};
    if(/近距离.*伤害|近距离增伤/.test(name))return {order:2,reason:'近距离输出优先；远程作战时换用远距离增伤'};
    if(/远距离.*伤害|远距离增伤/.test(name))return {order:2,reason:'远距离输出优先；近战时换用近距离增伤'};
    if(/伤害加成|伤害增加/.test(name)&&!/暴击|受到|受玩家|受巨兽|追加/.test(name))return {order:1,reason:'优先考虑直接增伤，注意效果适用范围'};
    if(/元素穿透|元素.*穿透|烈金.*穿透|青木.*穿透|流火.*穿透|朔风.*穿透/.test(name))return {order:3,reason:'元素输出候选，需匹配武器元素和目标抗性'};
    if(/元素攻击|烈金攻击|青木攻击|流火攻击|朔风攻击/.test(name))return {order:4,reason:'元素输出候选，需匹配实际使用的元素'};
    if(/暴击/.test(name)&&!/抵抗|抗暴|减|受到/.test(name))return {order:/伤害/.test(name)?6:5,reason:'暴击收益取决于暴击率与目标韧性'};
    if(/攻击/.test(name)&&!/受到|受玩家|受巨兽|抵抗|减/.test(name))return {order:7,reason:'通用输出属性，适合补充基础攻击'};
    if(/穿透/.test(name)&&!/抵抗|减/.test(name))return {order:8,reason:'针对目标防御补充穿透'};
    if(/追加伤害/.test(name))return {order:9,reason:'补充伤害，需结合实际攻击方式选择'};
    if(/减伤|伤害减免|抵挡伤害|韧性|防御|生命/.test(name))return {order:20,reason:'生存候选，按实战承伤需求替换输出词条'};
    return {order:40,reason:'功能候选，按武器操作和战斗场景选择'};
  }
  function createEquipmentIndex(data){
    if(data?.schema!==1||!['items','words','pools','types','parts','methods'].every(k=>Array.isArray(data[k])))throw new Error('装备资料格式无效');
    const words=new Map(data.words.map(w=>[w.id,w])),pools=new Map(data.pools.map(p=>[p.id,p])),types=new Map(data.types.map(t=>[t.id,t]));
    if(words.size!==data.words.length||pools.size!==data.pools.length)throw new Error('装备资料包含重复编号');
    const items=data.items.filter(x=>!excluded.some(n=>x.name.includes(n))),byItem=new Map(items.map(x=>[x.id,x]));
    for(const p of pools.values())if(!p.words.every(id=>words.has(id)))throw new Error('装备词条池引用缺失');
    for(const item of items)if(!types.has(item.type)||!item.pools.every(id=>pools.has(id)))throw new Error('装备资料关联缺失');
    for(const w of words.values())if(!Number.isFinite(w.power)||w.power<0||!w.description||/%[a-z]/i.test(w.description))throw new Error('词条数值无效');
    // 列表按效果归组，原始条件版本保留在variants中，不作为重复卡片展示。
    const series=new Map(),seriesKeys=new Map(),effectShape=value=>String(value).replace(/\d+(?:\.\d+)?/g,'#').replace(/\s+/g,'');
    const effectText=value=>String(value).replace(/\d+(?:\.\d+)?/g,n=>String(Number(n))).replace(/\s+/g,'');
    for(const w of [...words.values()].sort((a,b)=>a.id-b.id)){
      const signature=JSON.stringify([w.name,effectShape(w.description),w.unit,!!w.conditional,!!w.missingEffectValue]);
      if(!series.has(signature))series.set(signature,'affix-'+w.id);seriesKeys.set(w.id,series.get(signature));
    }
    function carriers(options={}){return items.filter(x=>(options.subject!=='servant'||x.servant)&&(!options.part||x.part===options.part)&&(options.part!=='weapon'||!options.type||x.type===Number(options.type))&&(!options.grade||x.grade===options.grade));}
    // 原生炼器按同类型和装备品质筛选来源，不要求来源与目标同一品阶。
    function compatibleSources(targets){const caps=new Map();for(const item of targets)caps.set(item.type,Math.max(caps.get(item.type)??-1,item.color));return items.filter(x=>caps.has(x.type)&&x.color<=caps.get(x.type));}
    function weaponTypes(subject){const ids=new Set(carriers({subject,part:'weapon'}).map(x=>x.type));return [...types.values()].filter(t=>t.part==='weapon'&&ids.has(t.id)).sort((a,b)=>compareName(a.name,b.name));}
    function grades(options){return unique(carriers({...options,grade:''}).map(x=>x.grade).filter(Boolean)).sort((a,b)=>(Number(b.match(/\d+/)?.[0])||0)-(Number(a.match(/\d+/)?.[0])||0)||(/传说/.test(b)-/传说/.test(a))||compareName(a,b));}
    const best=(variants,goal)=>variants.slice().sort((a,b)=>goal==='power'?b.power-a.power||b.quality-a.quality||a.id-b.id:(b.value??-Infinity)-(a.value??-Infinity)||b.power-a.power||a.id-b.id)[0];
    function query(options={}){
      const selected=carriers(options),sources=compatibleSources(selected),ids=new Set(selected.map(x=>x.id)),groups=new Map(),naturalSources=new Map();
      function add(id,itemId,method){const w=words.get(id);if(!w)return;const key=seriesKeys.get(id);let g=groups.get(key);if(!g){g={key,name:w.name,variants:new Map(),carriers:new Set(),methods:new Set(),wordSources:new Map()};groups.set(key,g);}g.variants.set(id,w);g.carriers.add(itemId);if(!g.wordSources.has(id))g.wordSources.set(id,new Set());g.wordSources.get(id).add(itemId);if(method)g.methods.add(method);else{if(!naturalSources.has(id))naturalSources.set(id,new Set());naturalSources.get(id).add(itemId);}}
      for(const item of sources)for(const pid of item.pools)for(const id of pools.get(pid).words)add(id,item.id);
      for(const method of data.methods)for(const id of method.items)if(ids.has(id))for(const word of method.words)add(word,id,method.id);
      let rows=[];
      for(const g of groups.values()){
        const all=[...g.variants.values()],variants=all.filter(w=>options.quality===''||options.quality==null||w.quality===Number(options.quality));if(!variants.length)continue;
        const word=best(variants,options.goal),rule=combatRule(word),special=word.conditional||g.methods.size>0||word.value===null;
        if(options.special&&!special)continue;
        const row={...g,variants:all,word,rule,special,carriers:[...g.carriers].map(id=>byItem.get(id)),methods:[...g.methods].map(id=>data.methods.find(m=>m.id===id))};
        if(options.search&&!`${row.name} ${all.map(w=>w.description+' '+w.conditions.join(' ')).join(' ')} ${row.carriers.map(x=>x.name).join(' ')}`.includes(options.search.trim()))continue;
        rows.push(row);
      }
      rows.sort((a,b)=>options.goal==='power'?b.word.power-a.word.power||compareName(a.name,b.name):a.rule.order-b.rule.order||compareName(a.name,b.name)||b.word.power-a.word.power);
      // 组合可跨兼容来源池，容量取目标装备；相同属性组只保留一条。
      let combination=null;const seen=new Set();
      if(!options.search&&!options.special)for(const item of selected){
        const capacity=Math.min(3,Math.max(0,...item.pools.map(pid=>pools.get(pid)).filter(p=>p.notrepeat===1).map(p=>p.max))),signature=[item.type,item.color,capacity].join(':');
        if(!capacity||seen.has(signature))continue;seen.add(signature);
        const candidates=rows.map(row=>{
          const variants=row.variants.filter(w=>(options.quality===''||options.quality==null||w.quality===Number(options.quality))&&!w.unresolvedConditions&&[...naturalSources.get(w.id)||[]].some(id=>{const source=byItem.get(id);return source.type===item.type&&source.color<=item.color;}));
          return variants.length?{...row,word:best(variants,options.goal)}:null;
        }).filter(Boolean);
        if(options.goal==='power')candidates.sort((a,b)=>b.word.power-a.word.power||compareName(a.name,b.name));
        const picked=[],groups=new Set();
        for(const row of candidates){
          const word=row.word;if(word.group&&groups.has(word.group)||options.goal!=='power'&&(row.rule.order>=40||/近距离|远距离|烈金|青木|流火|朔风/.test(word.name)))continue;
          const source=[...naturalSources.get(word.id)].map(id=>byItem.get(id)).find(x=>x.type===item.type&&x.color<=item.color);
          picked.push({...row,source});if(word.group)groups.add(word.group);if(picked.length>=capacity)break;
        }
        if(!picked.length)continue;
        const score=options.goal==='power'?picked.reduce((sum,r)=>sum+r.word.power,0):picked.reduce((sum,r)=>sum+100-r.rule.order,0);
        if(!combination||picked.length>combination.rows.length||picked.length===combination.rows.length&&score>combination.score)combination={rows:picked,item,capacity,score};
      }
      return {rows,items:selected,sources,combination};
    }
    function equivalentWords(row,word=row.word){return row.variants.filter(w=>w.quality===word.quality&&w.power===word.power&&w.value===word.value&&w.unit===word.unit&&effectText(w.description)===effectText(word.description));}
    function sourcesFor(row,word=row.word){return unique(equivalentWords(row,word).flatMap(w=>[...row.wordSources.get(w.id)||[]])).map(id=>byItem.get(id));}
    function qualityMax(row){return data.qualities.map((name,quality)=>{const word=best(row.variants.filter(w=>w.quality===quality),'combat');return {name,word,sources:word?sourcesFor(row,word):[]};});}
    return {data,words,pools,types,items,byItem,weaponTypes,grades,carriers,compatibleSources,equivalentWords,sourcesFor,query,qualityMax,combatRule};
  }
  const api={createEquipmentIndex,combatRule,excluded};if(typeof module!=='undefined'&&module.exports)module.exports=api;root.EquipmentCore=api;
})(globalThis);
