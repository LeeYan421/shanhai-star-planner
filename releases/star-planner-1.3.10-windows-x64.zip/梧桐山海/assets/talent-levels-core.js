/* 账号天赋等级与星宿节点等级独立；未录入项按用户选择的1级计算。 */
(function(root){
  'use strict';
  function createTalentLevelRules(data){
    const limits=new Map(data.talents.map(t=>[t.id,Math.max(1,t.effects?.length||t.power?.length||1)]));
    function normalize(value){
      if(value===undefined)return {};
      if(!value||typeof value!=='object'||Array.isArray(value))throw new Error('账号天赋等级格式无效');
      const levels={};
      for(const [key,level]of Object.entries(value)){
        const id=Number(key),max=limits.get(id);
        if(String(id)!==key||!max||!Number.isInteger(level)||level<1||level>max)throw new Error('天赋等级需为1至'+(max||6)+'级，且必须属于当前星宿');
        if(level!==1)levels[id]=level;
      }
      return levels;
    }
    return {normalize,level:(id,levels)=>levels?.[id]??1,maxLevel:id=>limits.get(Number(id)),ids:[...limits.keys()].sort((a,b)=>a-b)};
  }
  function createAccountTalentStore(data,storage){
    const rules=createTalentLevelRules(data),key='wutong-account-talent-levels-v1';
    function get(){
      const raw=storage.getItem(key);if(raw===null)return {};
      try{const value=JSON.parse(raw);if(value.schema!==1)throw Error();return rules.normalize(value.levels);}catch{throw new Error('账号天赋配置未能读取，请检查或重置等级');}
    }
    function serialize(levels){return JSON.stringify({schema:1,levels:rules.normalize(levels)});}
    function save(levels){const raw=serialize(levels);storage.setItem(key,raw);if(storage.getItem(key)!==raw)throw new Error('天赋等级未能保存，请重试');return rules.normalize(levels);}
    return {key,get,save,serialize,rules};
  }
  const api={createTalentLevelRules,createAccountTalentStore};
  if(typeof module==='object'&&module.exports)module.exports=api;
  Object.assign(root,api);
})(globalThis);
