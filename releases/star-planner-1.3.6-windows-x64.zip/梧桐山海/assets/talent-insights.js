/* 单天赋效率只计算本星宿自身，公共前置用于解锁点数说明，不参与评分。 */
(function(root){
  'use strict';
  function createTalentInsights(data,details,createEngine){
    const engine=createEngine(data),talents=new Map(data.talents.map(t=>[t.id,t])),byStar=new Map(),cache=new Map();
    for(const node of data.nodes){if(!byStar.has(node.starId))byStar.set(node.starId,[]);byStar.get(node.starId).push(node);}
    const request=(ids,elements=[])=>({budget:1000000,capacity:data.maxCapacity,talentIds:ids,elementKeys:elements});
    function analyse(id){
      if(cache.has(id))return cache.get(id);const t=talents.get(id);if(!t)throw new Error('天赋不存在');
      const nodes=byStar.get(t.starId),attributes=new Map();let ownPoints=0;
      for(const node of nodes){const level=t.requiredLevel;ownPoints+=node.costs.slice(0,level).reduce((a,b)=>a+b,0);attributes.set(node.attrId,(attributes.get(node.attrId)||0)+node.values[level-1]);}
      const nodePower=[...attributes].reduce((sum,[attr,value])=>sum+engine.resourceScore(data.power.parameters[attr],value),0);
      const totalPoints=engine.prepare(request([id])).minimumCost,talentPower=t.power.at(-1),efficiency=ownPoints>0?(nodePower+talentPower)/ownPoints:null;
      const upgrades=details?.talents?.[id]||null,materials=[...new Set((upgrades||[]).flatMap(s=>s.items.map(i=>i.name)))];
      const result={id,ownPoints,prerequisitePoints:totalPoints-ownPoints,totalPoints,nodePower,talentPower,efficiency,level:t.power.length,upgrades,materials};cache.set(id,result);return result;
    }
    function additional(id,selected,elements){
      if(selected.includes(id))return {points:0,selected:true,replaced:false};
      const target=talents.get(id),next=selected.filter(otherId=>{const other=talents.get(otherId);return !data.conflicts.some(c=>c.id===target.conflictGroup&&c.exclusive_group.includes(other.conflictGroup)||c.id===other.conflictGroup&&c.exclusive_group.includes(target.conflictGroup));});
      const replaced=next.length!==selected.length;next.push(id);
      try{return {points:engine.prepare(request(next,elements)).minimumCost-engine.prepare(request(selected,elements)).minimumCost,replaced,selected:false};}
      catch{return {points:null,replaced,selected:false};}
    }
    return {analyse,additional};
  }
  if(typeof module!=='undefined')module.exports={createTalentInsights};else root.createTalentInsights=createTalentInsights;
})(globalThis);
