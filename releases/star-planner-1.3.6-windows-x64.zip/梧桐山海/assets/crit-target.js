/* 暴击作为必须满足的下限，联合选择节点；达标后只提高攻击，同收益少耗点。 */
(function(root){
  'use strict';
  function createCritTargetEngine(data,createBase,optimizer){
    const base=createBase(data),byId=new Map(data.nodes.map(n=>[n.id,n]));
    const variable=(id,level)=>'n'+id+'L'+level;
    const expression=terms=>terms.filter(([v])=>v!==0).map(([v,n])=>(v<0?' - ':' + ')+Math.abs(v)+' '+n).join('').replace(/^ \+ /,'')||'0 '+variable(data.nodes[0].id,1);
    function solve(request,progress=()=>{}){
      const started=Date.now(),prep=base.prepare(request),target=request.critTarget;
      if(!Number.isSafeInteger(target)||target<0||target>1000000)throw new Error('暴击目标请输入0至1000000之间的整数');
      const maximum=data.nodes.filter(n=>n.attrId===data.objective.crit).reduce((s,n)=>s+Math.max(...n.values),0);
      if(target>maximum)throw new Error('暴击目标超过全部星宿上限，最多可提供+'+maximum+'点暴击');
      if(!optimizer)throw new Error('本机目标计算组件尚未加载');
      const binary=[],constraints=[],spend=[],crit=[],attack=[];
      function constraint(terms,sign,value){constraints.push(' c'+constraints.length+': '+expression(terms)+' '+sign+' '+value);}
      for(const n of data.nodes){
        n.values.forEach((value,i)=>{
          const name=variable(n.id,i+1),gain=value-(i?n.values[i-1]:0);
          if(!Number.isSafeInteger(gain)||!Number.isSafeInteger(n.costs[i]))throw new Error('节点数值超出精确计算范围');
          binary.push(name);spend.push([n.costs[i],name]);
          if(n.attrId===data.objective.crit)crit.push([gain,name]);
          if(n.attrId===data.objective.attack)attack.push([gain,name]);
          if(i)constraint([[1,name],[-1,variable(n.id,i)]],'<=',0);
        });
        for(const id of n.pre)constraint([[1,variable(n.id,1)],[-1,variable(id,1)]],'<=',0);
        if(prep.required.has(n.id))constraint([[1,variable(n.id,prep.required.get(n.id))]],'=',1);
      }
      constraint(crit,'>=',target);
      const model=(direction,terms)=>[direction,' goal: '+expression(terms),'Subject To',...constraints,'Binaries',binary.join(' '),'End'].join('\n');
      const settings={output_flag:false,presolve:'on',mip_rel_gap:0,mip_abs_gap:0,mip_feasibility_tolerance:1e-8,time_limit:120};
      function optimize(direction,terms){
        const result=optimizer.solve(model(direction,terms),settings);
        if(result.Status!=='Optimal')throw new Error('自定义目标求解尚未完成，未生成最优方案，可重试或取消');
        if(!Number.isFinite(result.ObjectiveValue)||Math.abs(result.ObjectiveValue-Math.round(result.ObjectiveValue))>0.000001)throw new Error('求解目标未通过整数校验');
        return result;
      }
      // 最低点数仅用于检查缺口，不固定其节点组合，避免限制后续攻击最优解。
      progress(10);
      const minimumCost=Math.round(optimize('Minimize',spend).ObjectiveValue);
      if(request.budget<minimumCost)return {status:'insufficient',critTarget:target,minimumCost,deficit:minimumCost-request.budget,fees:prep.fees,budget:request.budget};
      constraint(spend,'<=',request.budget);progress(35);
      const highestAttack=Math.round(optimize('Maximize',attack).ObjectiveValue);
      constraint(attack,'=',highestAttack);progress(70);
      const solved=optimize('Minimize',spend),levels=new Map();let spent=0;
      for(const n of data.nodes){
        let level=0;
        for(let i=0;i<n.values.length;i++){
          const value=solved.Columns[variable(n.id,i+1)]?.Primal,active=Math.round(value);
          if(!Number.isFinite(value)||Math.abs(value-active)>0.000001||(active!==0&&active!==1))throw new Error('节点等级未通过整数校验');
          if(active){if(level!==i)throw new Error('节点升级顺序无效');level++;spent+=n.costs[i];}
        }
        if(level)levels.set(n.id,level);
      }
      base.validate(levels,request.budget,prep);
      const total=(rows,id)=>[...rows].reduce((sum,[nodeId,lv])=>sum+(byId.get(nodeId).attrId===id?byId.get(nodeId).values[lv-1]:0),0);
      if(total(levels,data.objective.crit)<target||total(levels,data.objective.attack)!==highestAttack||spent!==Math.round(solved.ObjectiveValue))throw new Error('自定义目标方案复核不一致');
      const result=base.describe({levels,value:highestAttack,cost:spent},request,prep,Date.now()-started,{evaluate:rows=>total(rows,data.objective.attack),description:'暴击至少+'+target+'后攻击最高，同收益少耗点'});
      result.critTarget=target;result.minimumCost=minimumCost;progress(100);return result;
    }
    return {solve};
  }
  if(typeof module!=='undefined'&&module.exports)module.exports={createCritTargetEngine};
  root.createCritTargetEngine=createCritTargetEngine;
})(globalThis);
