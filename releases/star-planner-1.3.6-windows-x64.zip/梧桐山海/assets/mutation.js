/* 图鉴按需读取本机数据，筛选分组独立于星宿方案与加点进度。 */
(() => {
  'use strict';
  const $=id=>document.getElementById(id),esc=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const quality=['白','绿','蓝','紫','橙','红'],category={0:'基础词条',1:'特质词条',4:'特殊词条'};
  const state={tab:'parts',page:0,word:'',specialId:'',data:null,index:null,loading:null};
  const pageSize=24;
  const collections=PersonalCore.createCollections(localStorage);
  let detailItem=null;
  let timer;
  const names=row=>row.battle.map(id=>state.index.battle.get(id).name).join('、');
  const partLabel=row=>row.sourcePos===8||row.sourcePos===12?state.data.positions[row.sourcePos]:state.data.parts[row.part];
  const qualityTag=q=>`<span class="mutation-quality" data-quality="${q}">${quality[q]}色</span>`;
  const wordLevel=(id,word)=>{const level=state.index.specialWords.get(Number(id))?.level;return level?` · 等级＋${level}`:word.level?` · ${word.level}级`:'';};
  function specialBadges(row,id){
    const groups=new Map();for(const word of state.index.specialOptions(row,id)){if(!groups.has(word.quality))groups.set(word.quality,[]);groups.get(word.quality).push(word.level);}
    return [...groups].map(([q,levels])=>`<span class="mutation-special-option">${qualityTag(q)}＋${levels.sort((a,b)=>a-b).join('/')}级</span>`).join('');
  }
  function partCard(row){
    const notes=[row.battle.length?`<span class="mutation-traits">${esc(names(row))}</span>`:'',...(row.special||[]).map(id=>`<span class="mutation-special-source">${esc(state.index.special.get(id).name)} ${specialBadges(row,id)}</span>`)].filter(Boolean).join('');
    return `<button class="mutation-row mutation-part-row" data-mutation-row="${row.id}" aria-label="${esc(row.name+' '+row.year+' '+partLabel(row))}"><span class="mutation-source"><strong>${esc(row.name)}</strong><small>${esc(row.year)} · ${esc(partLabel(row))}</small></span><span class="mutation-number" aria-label="攻击${row.attributes['攻击']}，${row.attackTier}档"><b>${row.attributes['攻击']}</b><em>${row.attackTier}档</em></span><span class="mutation-number" aria-label="穿透${row.attributes['防御穿透']??'无'}"><b>${row.attributes['防御穿透']??'—'}</b>${row.pierceTier==null?'':`<em>${row.pierceTier}档</em>`}</span>${notes?`<span class="mutation-row-notes">${notes}</span>`:''}</button>`;
  }
  function tokensMatch(text){return $('mutation-query').value.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean).every(token=>text.toLocaleLowerCase().includes(token));}
  function sourceNote(){return '<p class="mutation-note">候选属性不保证同时获得；档位按同年份从高到低编号。金、木、火、风数值相同，分别计算。</p>';}
  function render(){
    if(!state.data)return;
    const isParts=state.tab==='parts',isWords=state.tab==='words';
    document.querySelectorAll('[data-mutation-tab]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.mutationTab===state.tab)));
    $('mutation-part-filters').classList.toggle('hidden',!isParts);$('mutation-word-filters').classList.toggle('hidden',!isWords);$('mutation-sort').classList.toggle('hidden',!isParts);$('mutation-table-head').classList.toggle('hidden',!isParts);
    $('mutation-query').placeholder=isParts?'搜索巨兽、特质或属性':state.tab==='battle'?'搜索特质名称或效果':state.tab==='special'?'搜索特性名称或效果':'搜索词条效果';
    $('mutation-query').setAttribute('aria-label',$('mutation-query').placeholder);
    let entries=[],card;
    if(isParts){
      entries=state.index.search({query:$('mutation-query').value,part:$('mutation-part').value,trait:$('mutation-trait').value,age:$('mutation-age').value,sort:$('mutation-sort').value,word:state.word,specialId:state.specialId});card=partCard;
    }else if(state.tab==='battle'){
      entries=state.data.battle.filter(t=>tokensMatch(t.name+' '+t.variants.map(v=>v.description).join(' ')));
      card=trait=>{const peak=trait.variants.reduce((a,b)=>a.strength>b.strength?a:b);return `<button class="mutation-row" data-mutation-battle="${trait.id}"><span class="mutation-row-title"><strong>${esc(trait.name)}</strong><small>${trait.variants.length}组 · 来源 ›</small></span><p class="mutation-trait-desc mutation-effect" data-quality="${peak.quality}">${qualityTag(peak.quality)} ${esc(peak.description)}</p></button>`;};
    }else if(state.tab==='special'){
      entries=state.data.special.filter(t=>tokensMatch(t.name+' '+t.summary));card=trait=>`<button class="mutation-row" data-mutation-special="${trait.id}"><span class="mutation-row-title"><strong>${esc(trait.name)}</strong><small>等级 · 来源 ›</small></span><p class="mutation-trait-desc">${esc(trait.levels.find(l=>l.level===3).description)}</p></button>`;
    }else{
      entries=Object.entries(state.data.words).filter(([,w])=>isVisibleMutationWord(w)&&($('mutation-category').value===''||w.categories.includes(Number($('mutation-category').value)))&&($('mutation-word-quality').value===''||w.quality===Number($('mutation-word-quality').value))&&tokensMatch(w.description)).sort((a,b)=>b[1].quality-a[1].quality||Number(a[0])-Number(b[0]));
      card=([id,word])=>`<button class="mutation-row" data-mutation-word="${id}"><small>${qualityTag(word.quality)} · ${esc(word.categories.filter(c=>category[c]).map(c=>category[c]).join('、'))}${wordLevel(id,word)}</small><p class="mutation-trait-desc mutation-effect" data-quality="${word.quality}">${esc(word.description)}</p></button>`;
    }
    const pages=Math.max(1,Math.ceil(entries.length/pageSize));state.page=Math.min(state.page,pages-1);
    $('mutation-total').textContent=`${entries.length}条`;
    $('mutation-results').innerHTML=entries.length?entries.slice(state.page*pageSize,(state.page+1)*pageSize).map(card).join(''):'<div class="mutation-empty">没有符合条件的数据，试试减少筛选条件。</div>';
    $('mutation-pagination').classList.toggle('hidden',pages===1);$('mutation-page').textContent=`${state.page+1} / ${pages}`;
    $('mutation-prev').disabled=state.page===0;$('mutation-next').disabled=state.page===pages-1;
    $('mutation-filter-word').classList.toggle('hidden',!isParts||(state.word===''&&state.specialId===''));
    $('mutation-filter-word').textContent=state.specialId!==''?state.index.special.get(Number(state.specialId)).name+' · 清除':state.word===''?'':'已按词条筛选 · 清除';
    $('mutation-footnote').innerHTML=isParts?`<details class="mutation-legend"><summary>数值说明</summary>${sourceNote()}</details>`:'';
  }
  function changeTab(tab,clearQuery=true){state.tab=tab;state.page=0;if(clearQuery)$('mutation-query').value='';render();}
  function showDetail(title,content){$('mutation-detail-title').textContent=title;$('mutation-detail-body').innerHTML=content;const saved=detailItem&&collections.has(detailItem);$('mutation-favorite').classList.toggle('hidden',!detailItem);$('mutation-share-card').classList.toggle('hidden',detailItem?.type!=='part'||document.body.dataset.floating==='mutation');$('mutation-favorite').textContent=saved?'已收藏':'收藏';$('mutation-favorite').setAttribute('aria-pressed',String(!!saved));if(detailItem){try{collections.visit(detailItem);}catch{globalThis.PlannerApp?.toast('最近查询未能保存');}}if(!$('mutation-detail').open)$('mutation-detail').showModal();$('mutation-detail').scrollTop=0;}
  function wordList(ids){const visible=ids.filter(id=>isVisibleMutationWord(state.data.words[id]));return visible.length?visible.map(id=>{const word=state.data.words[id];return `<div class="mutation-word"><small>${qualityTag(word.quality)}${wordLevel(id,word)}</small><div class="mutation-effect" data-quality="${word.quality}">${esc(word.description)}</div></div>`;}).join(''):'<p class="mutation-note">该部位没有此类候选。</p>';}
  function rowDetail(id){
    const row=state.data.rows[Number(id)];
    detailItem={type:'part',id:row.sourceId+':'+row.sourcePos,title:row.name+' · '+partLabel(row),subtitle:row.year+' · 攻击'+row.attributes['攻击']+'（'+row.attackTier+'档） · 穿透'+(row.attributes['防御穿透']??'—')+(row.pierceTier==null?'':'（'+row.pierceTier+'档）')};
    const attributes=Object.entries({...row.attributes,...(row.pierceTier==null?{'防御穿透':null}:{})}).map(([name,value])=>{const tier=name==='攻击'?row.attackTier:name==='防御穿透'?row.pierceTier:null;return `<div><dt>${esc(name)}</dt><dd>${value??'—'}${tier==null?'':` <em>${tier}档</em>`}</dd></div>`;}).join('');
    const pools=Object.keys(category).map(Number).map(c=>{
      const ids=state.index.poolWords(row,c);if(!ids.length)return '';
      return `<details class="mutation-pool"><summary>${category[c]} · ${ids.length}项</summary>${wordList(ids)}</details>`;
    }).join('');
    const uncertain=Object.values(row.options).some(opt=>[opt.pools[0],opt.pools[1],...opt.special].some(p=>state.data.pools[p].uncertain));
    showDetail(row.name+' · '+partLabel(row),`<p class="mutation-note">${esc(row.year)}</p><dl class="mutation-attributes">${attributes}</dl><div class="mutation-related">${row.battle.map(family=>`<button class="secondary-button" data-mutation-battle="${family}" data-source-row="${row.id}">${esc(state.index.battle.get(family).name)} ›</button>`).join('')}${(row.special||[]).map(id=>`<button class="secondary-button" data-mutation-special="${id}">${esc(state.index.special.get(id).name)} ${specialBadges(row,id)} ›</button>`).join('')}</div>${pools}${uncertain?'<p class="mutation-note">部分候选权重不完整，获取情况以游戏为准。</p>':''}`);
  }
  function battleDetail(id,rowId){
    const trait=state.index.battle.get(Number(id)),row=rowId==null?null:state.data.rows[Number(rowId)];
    detailItem={type:'battle',id:String(id),title:trait.name,subtitle:'斗兽特质 · 效果与来源'};
    const variants=row?state.index.variants(row,id):trait.variants;
    showDetail(trait.name,`${row?`<p class="mutation-note">${esc(row.name+' · '+row.year+' · '+partLabel(row))}</p>`:''}<div class="mutation-detail-tools"><label for="mutation-quality" class="sr-only">品质</label><select id="mutation-quality" class="mutation-quality"><option value="">全部品质</option>${[...new Set(variants.map(v=>v.quality))].sort().map(q=>`<option value="${q}" class="mutation-quality" data-quality="${q}">${quality[q]}色</option>`).join('')}</select><button class="secondary-button" data-mutation-find-trait="${trait.id}">查来源</button></div><div class="mutation-variant-list">${[...variants].sort((a,b)=>b.strength-a.strength).map(v=>`<div class="mutation-word" data-variant-quality="${v.quality}"><small>${qualityTag(v.quality)} · 实力 ${v.strength}</small><div class="mutation-effect" data-quality="${v.quality}">${esc(v.description)}</div></div>`).join('')}</div><p class="mutation-note">实力与效果文案如有差异，以游戏为准。</p>`);
  }
  function specialDetail(id){const trait=state.index.special.get(Number(id)),count=state.index.search({specialId:id}).length;detailItem={type:'special',id:String(id),title:trait.name,subtitle:'蜃兽特性 · 等级与来源'};showDetail(trait.name,`<button class="secondary-button" data-mutation-find-special="${trait.id}">查来源 · ${count}条部位</button><p class="mutation-note">同名特性累计等级</p><div class="mutation-special-levels">${groupMutationLevels(trait.levels).map(l=>`<div class="mutation-word"><small>${l.from===l.to?l.from:l.from+'–'+l.to}级</small><span>${esc(l.description)}</span></div>`).join('')}</div>`);}
  function findSources({trait='',word='',specialId=''}){
    $('mutation-detail').close();state.word=word;state.specialId=specialId;for(const id of ['mutation-part','mutation-age'])$(id).value='';$('mutation-trait').value=trait;
    changeTab('parts');window.scrollTo(0,0);$('mutation-query').focus({preventScroll:true});
    rememberQuery();
  }
  async function open(){
    if(state.data){render();return;}
    if(state.loading)return state.loading;
    $('mutation-message').textContent='正在载入图鉴…';$('mutation-message').classList.remove('hidden');$('mutation-retry').classList.add('hidden');
    state.loading=(async()=>{
      try{
        const response=await fetch('mutation-data.json');if(!response.ok)throw new Error('data');const data=await response.json();if(data.schema!==1||!Array.isArray(data.rows)||!data.battle?.length)throw new Error('schema');
        state.index=createMutationIndex(data);state.data=data;
        $('mutation-part').innerHTML='<option value="">全部部位</option>'+[0,1,13,9,10,8,11].map(id=>`<option value="${id}">${esc(data.parts[id])}</option>`).join('');
        $('mutation-trait').innerHTML='<option value="">全部特质</option>'+data.battle.map(t=>`<option value="${t.id}">${esc(t.name)}</option>`).join('');
        $('mutation-age').innerHTML='<option value="">全部年份</option>'+[8,1,2,3,4,6,9].map(id=>`<option value="${id}">${esc(data.ages[id])}</option>`).join('');
        $('mutation-content').classList.remove('hidden');$('mutation-message').classList.add('hidden');render();
      }catch{$('mutation-message').textContent='图鉴未能载入，请重试。';$('mutation-retry').classList.remove('hidden');}
      finally{state.loading=null;}
    })();return state.loading;
  }
  const queryFields=['mutation-query','mutation-part','mutation-trait','mutation-age','mutation-sort','mutation-category','mutation-word-quality'];
  function queryItem(){const values=Object.fromEntries(queryFields.map(id=>[id,$(id).value]));const labels=[{parts:'部位',battle:'斗兽特质',special:'蜃兽特性',words:'词条'}[state.tab],$('mutation-query').value.trim(),...['mutation-part','mutation-trait','mutation-age','mutation-category','mutation-word-quality'].filter(id=>$(id).value!=='').map(id=>$(id).selectedOptions[0]?.textContent),state.specialId?state.index.special.get(Number(state.specialId))?.name:'',state.word?'词条来源':''].filter(Boolean);return {type:'query',id:JSON.stringify({tab:state.tab,values,word:state.word,specialId:state.specialId}),title:labels.join(' · ').slice(0,120),subtitle:'筛选条件 · '+$('mutation-total').textContent};}
  function rememberQuery(){if(!state.data)return;const active=$('mutation-query').value.trim()||['mutation-part','mutation-trait','mutation-age','mutation-category','mutation-word-quality'].some(id=>$(id).value)||state.word||state.specialId;if(active)try{collections.visit(queryItem());}catch{globalThis.PlannerApp?.toast('最近查询未能保存');}}
  $('mutation-save-query').addEventListener('click',()=>{try{const added=collections.toggle(queryItem());globalThis.PlannerApp?.toast(added?'已收藏当前筛选':'已取消收藏');}catch(e){globalThis.PlannerApp?.toast(e.message);}});
  $('mutation-favorite').addEventListener('click',()=>{if(!detailItem)return;try{const added=collections.toggle(detailItem);$('mutation-favorite').textContent=added?'已收藏':'收藏';$('mutation-favorite').setAttribute('aria-pressed',String(added));}catch(e){globalThis.PlannerApp?.toast(e.message);}});
  $('mutation-query').addEventListener('input',()=>{clearTimeout(timer);state.page=0;timer=setTimeout(()=>{render();rememberQuery();},400);});
  for(const id of ['mutation-part','mutation-trait','mutation-age','mutation-sort','mutation-category','mutation-word-quality'])$(id).addEventListener('change',()=>{state.page=0;render();rememberQuery();});
  $('mutation-clear').addEventListener('click',()=>{state.word='';state.specialId='';for(const id of ['mutation-query','mutation-part','mutation-trait','mutation-age','mutation-category','mutation-word-quality'])$(id).value='';$('mutation-word-quality').removeAttribute('data-quality');state.page=0;render();});
  $('mutation-filter-word').addEventListener('click',()=>{state.word='';state.specialId='';state.page=0;render();});
  $('mutation-prev').addEventListener('click',()=>{state.page--;render();$('mutation-results').scrollIntoView({block:'start'});});
  $('mutation-next').addEventListener('click',()=>{state.page++;render();$('mutation-results').scrollIntoView({block:'start'});});
  $('mutation-detail-close').addEventListener('click',()=>$('mutation-detail').close());$('mutation-retry').addEventListener('click',open);
  $('mutation-floating-open').addEventListener('click',()=>{
    if(typeof globalThis.AndroidPlanner?.showMutationLookup==='function')AndroidPlanner.showMutationLookup();
    else $('mutation-floating-status').textContent='请使用安卓安装版开启悬浮速查。';
  });
  document.addEventListener('change',e=>{if(['mutation-quality','mutation-word-quality'].includes(e.target.id)){e.target.dataset.quality=e.target.value;if(e.target.id==='mutation-quality')document.querySelectorAll('[data-variant-quality]').forEach(row=>row.classList.toggle('hidden',e.target.value!==''&&row.dataset.variantQuality!==e.target.value));}});
  document.addEventListener('click',event=>{
    const button=event.target.closest('[data-mutation-tab],[data-mutation-row],[data-mutation-battle],[data-mutation-special],[data-mutation-word],[data-mutation-find-trait],[data-mutation-find-special]');if(!button)return;
    const d=button.dataset;
    if(d.mutationTab)changeTab(d.mutationTab);
    else if(d.mutationRow!=null)rowDetail(d.mutationRow);
    else if(d.mutationBattle!=null)battleDetail(d.mutationBattle,d.sourceRow);
    else if(d.mutationSpecial!=null)specialDetail(d.mutationSpecial);
    else if(d.mutationWord!=null)findSources({word:d.mutationWord});
    else if(d.mutationFindTrait!=null)findSources({trait:d.mutationFindTrait});
    else if(d.mutationFindSpecial!=null)findSources({specialId:d.mutationFindSpecial});
  });
  globalThis.MutationTool={open,sharePart(){
    if(detailItem?.type!=='part')throw new Error('请先打开一个巨兽部位');const row=state.data.rows.find(r=>r.sourceId+':'+r.sourcePos===detailItem.id);
    return {name:row.name,part:partLabel(row),year:row.year,attributes:{...row.attributes},attackTier:row.attackTier,pierceTier:row.pierceTier,battle:row.battle.map(id=>state.index.battle.get(id).name),special:(row.special||[]).map(id=>{const groups=new Map();for(const w of state.index.specialOptions(row,id)){if(!groups.has(w.quality))groups.set(w.quality,[]);groups.get(w.quality).push(w.level);}return state.index.special.get(id).name+' · '+[...groups].map(([q,levels])=>quality[q]+'色＋'+levels.sort((a,b)=>a-b).join('/')+'级').join('，');})};
  },async restore(item){
    await open();if(!state.data)throw new Error('图鉴未能载入');globalThis.PlannerApp?.route('mutation');
    if(item.type==='part'){const row=state.data.rows.find(r=>r.sourceId+':'+r.sourcePos===item.id);if(!row)throw new Error('当前数据未找到这个部位');rowDetail(row.id);}
    else if(item.type==='battle'){if(!state.index.battle.has(Number(item.id)))throw new Error('特质已不可用');battleDetail(item.id);}
    else if(item.type==='special'){if(!state.index.special.has(Number(item.id)))throw new Error('特性已不可用');specialDetail(item.id);}
    else if(item.type==='word')findSources({word:item.id});
    else if(item.type==='query'){
      const query=JSON.parse(item.id);if(!['parts','battle','special','words'].includes(query.tab))throw new Error('筛选条件无效');
      for(const id of queryFields){const value=query.values?.[id]??'';if(typeof value!=='string'||value.length>200||id!=='mutation-query'&&![...$(id).options].some(o=>o.value===value))throw new Error('筛选条件已不可用');}
      if(query.specialId&&!state.index.special.has(Number(query.specialId))||query.word&&!isVisibleMutationWord(state.data.words[query.word]))throw new Error('筛选词条已不可用');
      state.tab=query.tab;state.word=query.word||'';state.specialId=query.specialId||'';state.page=0;for(const id of queryFields)$(id).value=query.values[id];$('mutation-word-quality').dataset.quality=$('mutation-word-quality').value;render();rememberQuery();
    }
  },back(){if($('mutation-detail').open){$('mutation-detail').close();return true;}return false;}};
})();
