/* 收藏、最近查询与星宿备份只写本机存储，导入前完整校验。 */
(function(root){
  'use strict';
  if(typeof module!=='undefined'&&module.exports)require('./element-rules.js');
  const collectionKey='wutong-collections-v1';
  const rules=new Set(['crit','power','attack-pen','crit-target']);
  const clone=value=>JSON.parse(JSON.stringify(value));
  function createCollections(storage){
    const valid=item=>item&&['part','battle','special','word','query'].includes(item.type)&&typeof item.id==='string'&&item.id.length<=500&&typeof item.title==='string'&&item.title.length<=120&&typeof item.subtitle==='string'&&item.subtitle.length<=180;
    function read(){try{const raw=JSON.parse(storage.getItem(collectionKey)||'{}');return {favorites:(Array.isArray(raw?.favorites)?raw.favorites:[]).filter(valid).slice(0,200),recent:(Array.isArray(raw?.recent)?raw.recent:[]).filter(valid).slice(0,40)};}catch{return {favorites:[],recent:[]};}}
    const key=item=>item.type+':'+item.id;
    function write(value){storage.setItem(collectionKey,JSON.stringify(value));return value;}
    return {read,key,has(item){return read().favorites.some(x=>key(x)===key(item));},toggle(item){if(!valid(item))throw new Error('收藏内容无效');const all=read(),exists=all.favorites.some(x=>key(x)===key(item));if(!exists&&all.favorites.length>=200)throw new Error('最多收藏200项');all.favorites=exists?all.favorites.filter(x=>key(x)!==key(item)):[clone(item),...all.favorites];write(all);return !exists;},visit(item){if(!valid(item))throw new Error('查询记录无效');const all=read();all.recent=[clone(item),...all.recent.filter(x=>key(x)!==key(item))].slice(0,40);write(all);},clearRecent(){const all=read();all.recent=[];write(all);}};
  }
  function configSignature(config){return JSON.stringify([String(config.budget??''),String(config.capacity??''),config.strategy, String(config.critTarget??''),[...config.selected].sort((a,b)=>a-b),[...config.elements].sort(),config.source||'',...(config.elementStars?.length?[['stars',config.elementStars.slice().sort((a,b)=>a.starId-b.starId).map(s=>[s.starId,s.levels])]]:[]),...(config.elementRules?.length?[config.elementRules.slice().sort((a,b)=>a.key.localeCompare(b.key)).map(r=>[r.key,r.mode,Number(r.value)])]:[])]);}
  function validateConfig(config,data){
    if(!config||typeof config!=='object'||Array.isArray(config))throw new Error('方案配置无效');
    const number=(value,max,empty=false)=>{const s=String(value??'');if(empty&&s==='')return '';if(!/^\d{1,7}$/.test(s)||Number(s)>max)throw new Error('方案点数或目标超出范围');return String(Number(s));};
    if(!rules.has(config.strategy))throw new Error('不支持的加点规则');
    const talents=new Set(data.talents.map(t=>t.id)),elements=new Set(data.elements.flatMap(e=>e.options.map(o=>o.key)));
    if(!Array.isArray(config.selected)||config.selected.length>data.talents.length||config.selected.some(id=>!Number.isInteger(id)||!talents.has(id)))throw new Error('方案包含当前数据没有的天赋');
    if(!Array.isArray(config.elements)||config.elements.length>elements.size||config.elements.some(id=>!elements.has(id)))throw new Error('方案包含无效元素目标');
    const elementRules=createElementRules(data).normalize(config.elementRules,config.elements);
    const elementStars=createElementRules(data).normalizeStars(config.elementStars,config.elements,elementRules);
    return {...(elementStars.length?{elementStars}:{}),...(elementRules.length?{elementRules}:{}),budget:number(config.budget,1000000,true),capacity:number(config.capacity,data.maxCapacity),strategy:config.strategy,critTarget:number(config.critTarget,1000000,true),selected:[...new Set(config.selected)],elements:[...new Set(config.elements)],source:typeof config.source==='string'?config.source.slice(0,100):''};
  }
  function parseBackup(raw,data){
    if(typeof raw!=='string'||new TextEncoder().encode(raw).length>2000000)throw new Error('备份文件不能超过2MB');
    let value;try{value=JSON.parse(raw);}catch{throw new Error('不是有效的JSON备份');}
    if(value.format!=='wutong-star-backup'||![1,2,3].includes(value.schema)||!Array.isArray(value.plans)||value.plans.length>200)throw new Error('不支持的备份格式');
    const ids=new Set();
    const plans=value.plans.map(plan=>{
      if(!plan||typeof plan.id!=='string'||!/^[a-z0-9-]{1,80}$/.test(plan.id)||ids.has(plan.id)||typeof plan.name!=='string'||!plan.name.trim()||plan.name.length>24)throw new Error('方案编号或名称无效');
      ids.add(plan.id);return {id:plan.id,name:plan.name.trim(),config:validateConfig(plan.config,data)};
    });
    const progress={};
    if(value.progress&&typeof value.progress==='object'&&!Array.isArray(value.progress)){
      const nodes=new Set(data.nodes.map(n=>n.id)),entries=Object.entries(value.progress);if(entries.length>1000)throw new Error('进度记录过多');
      for(const [key,p] of entries){if(!/^star-guide-[a-f0-9]{1,8}$/.test(key)||p?.plan!==key||!Array.isArray(p.ids)||p.ids.length>data.nodes.length||p.ids.some(id=>!nodes.has(id)))throw new Error('加点进度格式不正确');progress[key]={plan:key,ids:[...new Set(p.ids)]};}
    }
    return {plans,draft:value.draft?validateConfig(value.draft,data):null,active:typeof value.active==='string'&&ids.has(value.active)?value.active:'',progress,source:typeof value.source==='string'?value.source:'',createdAt:typeof value.createdAt==='string'?value.createdAt:''};
  }
  // 合并保留现有方案，同编号同配置跳过；冲突创建副本并保留原编号对应的进度。
  function mergeBackup(existing,incoming,newId){
    const plans=clone(existing),remapped=new Set();let added=0,skipped=0;
    for(const source of incoming.plans){
      const same=plans.find(p=>p.id===source.id);
      if(same&&configSignature(same.config)===configSignature(source.config)&&same.name===source.name){skipped++;continue;}
      const plan=clone(source);if(same){plan.id=newId();remapped.add(source.id);}
      const names=new Set(plans.map(p=>p.name));let suffix=1,name=plan.name;while(names.has(name)){const tail='（导入'+suffix+++'）';name=plan.name.slice(0,24-tail.length)+tail;}plan.name=name;
      plans.push(plan);added++;
    }
    if(plans.length>200)throw new Error('合并后超过200套方案，请先整理现有方案');
    return {plans,added,skipped,remapped};
  }
  function comparisonSummary(result,data){
    if(result.status!=='optimal')throw new Error('未求出完整方案');
    const carried=new Set(result.targetIds),talentScore=data.talents.filter(t=>carried.has(t.id)).reduce((sum,t)=>sum+(t.power?.at(-1)||0),0);
    return {crit:result.crit,attack:result.attack,penetration:result.penetration,power:(result.nodePowerReference??result.powerReference)+talentScore,spent:result.spent,fees:result.fees};
  }
  const api={createCollections,configSignature,validateConfig,parseBackup,mergeBackup,comparisonSummary};
  if(typeof module!=='undefined')module.exports=api;else root.PersonalCore=api;
})(globalThis);
