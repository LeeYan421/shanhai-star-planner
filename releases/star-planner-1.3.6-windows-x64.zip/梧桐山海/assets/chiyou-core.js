/* 兵魂与宠物保持双向索引；来源按名称去重，不使用支援宠物或年份归组。 */
(function(root){
  'use strict';
  const normalize=value=>String(value||'').normalize('NFKC').toLocaleLowerCase().replace(/[《》·・\s，,。；;：:]/g,'');
  function createChiyouIndex(data){
    if(data?.schema!==1||!Array.isArray(data.souls)||!data.souls.length||!Array.isArray(data.pets)||!data.pets.length||!Array.isArray(data.qualities)||data.qualities.length!==6||data.qualities.some(q=>typeof q!=='string'||!q))throw new Error('兵魂资料格式无效');
    const souls=new Map(),pets=new Map();
    for(const row of data.souls){if(!Number.isSafeInteger(row.id)||row.id<=0||souls.has(row.id)||typeof row.name!=='string'||!row.name.trim()||typeof row.description!=='string')throw new Error('兵魂资料不完整');souls.set(row.id,{...row,pets:[]});}
    for(const row of data.pets){if(typeof row.name!=='string'||!row.name.trim()||pets.has(row.name)||!Array.isArray(row.souls)||!row.souls.length||new Set(row.souls).size!==row.souls.length||row.souls.some(id=>!souls.has(id)))throw new Error('宠物来源关系无效');const pet={name:row.name,souls:row.souls.map(id=>souls.get(id))};pets.set(row.name,pet);for(const soul of pet.souls)soul.pets.push(pet);}
    for(const soul of souls.values()){if(!soul.pets.length)throw new Error('兵魂缺少核心宠物来源');soul.search=normalize(soul.name+' '+soul.description+' '+soul.pets.map(p=>p.name).join(' '));soul.pets.sort((a,b)=>a.name.localeCompare(b.name,'zh-Hans-CN'));}
    for(const pet of pets.values())pet.search=normalize(pet.name+' '+pet.souls.map(s=>s.name+' '+s.description).join(' '));
    const match=(row,query)=>String(query||'').trim().split(/\s+/).filter(Boolean).every(word=>row.search.includes(normalize(word)));
    return {souls,pets,qualities:data.qualities,searchSouls:query=>[...souls.values()].filter(s=>match(s,query)),searchPets:query=>[...pets.values()].filter(p=>match(p,query)).sort((a,b)=>a.name.localeCompare(b.name,'zh-Hans-CN')),sources:(id,query='')=>{const soul=souls.get(Number(id));if(!soul)return [];const words=String(query).trim().split(/\s+/).filter(Boolean).map(normalize);return soul.pets.filter(p=>words.every(word=>normalize(p.name).includes(word)));}};
  }
  if(typeof module!=='undefined'&&module.exports)module.exports={createChiyouIndex,normalize};root.createChiyouIndex=createChiyouIndex;
})(globalThis);
