/* 日志仅在用户点击时提交，失败沿用同一编号与内容，用户界面不展示诊断正文。 */
(() => {
  'use strict';
  const core=DiagnosticCore,store=core.createStore({getItem:key=>localStorage.getItem(key),setItem:(key,value)=>localStorage.setItem(key,value)}),pendingKey='wutong-diagnostic-pending-v1',sentKey='wutong-diagnostic-sent-v1';let sending=false;
  function record(module,error){try{store.record(module,error);}catch{}}
  function collect(){
    let native={};try{if(typeof globalThis.AndroidPlanner?.getDiagnosticLogs==='function')native=JSON.parse(AndroidPlanner.getDiagnosticLogs());}catch{}
    const version=document.querySelector('.version-row span')?.textContent.match(/^\d+\.\d+\.\d+/)?.[0]||'unknown';
    return core.report({appVersion:native.versionName||version,versionCode:native.versionCode,dataId:globalThis.STAR_DATA?.sourceSha256?.slice(0,16)},[...(Array.isArray(native.events)?native.events:[]),...store.read()]);
  }
  async function submit(){
    if(sending)return;sending=true;const buttons=[...document.querySelectorAll('[data-submit-diagnostics]')];buttons.forEach(b=>b.disabled=true);
    const status=document.getElementById('diagnostic-status'),notice=text=>{if(status)status.textContent=text;globalThis.PlannerApp?.toast(text);};
    try{
      let pending;try{const saved=JSON.parse(localStorage.getItem(pendingKey)||'null');if(saved&&/^[a-f0-9-]{36}$/.test(saved.id))pending={id:saved.id,body:core.sanitizeReport(saved.body)};}catch{}
      if(!pending){const body=collect();if(localStorage.getItem(sentKey)===body){notice('这份日志已提交，可在“我的记录”查看处理进度');return;}pending={id:crypto.randomUUID(),body};localStorage.setItem(pendingKey,JSON.stringify(pending));}
      notice('正在提交日志…');await CommunityUI.submitDiagnostic(pending.id,pending.body);
      localStorage.setItem(sentKey,pending.body);localStorage.removeItem(pendingKey);notice('日志已提交，可在“我的记录”查看处理进度');
    }catch{notice('日志未确认提交成功，请检查网络后重试');}finally{sending=false;buttons.forEach(b=>b.disabled=false);}
  }
  globalThis.Diagnostics={record,submit};
  window.addEventListener('error',event=>record('app',event.error||{name:'Error',message:event.message,stack:(event.filename||'')+':'+event.lineno+':'+event.colno}));
  window.addEventListener('unhandledrejection',event=>record('app',event.reason));
  document.addEventListener('click',event=>{if(event.target.closest('[data-submit-diagnostics]'))submit();});
})();
