/* 悬浮模式使用HTML选择器，避免依赖Activity才能显示的系统下拉弹层。 */
(() => {
  'use strict';
  if(document.body.dataset.floating!=='mutation')return;
  const picker=document.createElement('dialog');picker.className='about-dialog lookup-picker';picker.id='lookup-picker';picker.setAttribute('aria-labelledby','lookup-picker-title');
  picker.innerHTML='<div class="section-heading"><h2 id="lookup-picker-title">选择</h2><button class="icon-button" id="lookup-picker-close" aria-label="关闭选项">×</button></div><div id="lookup-picker-options" role="listbox" aria-labelledby="lookup-picker-title"></div>';
  document.body.append(picker);
  let selected=null,nativeFocus=false;
  function openSelect(select){
    if(picker.open)return;
    selected=select;
    document.getElementById('lookup-picker-title').textContent=select.labels?.[0]?.firstChild?.textContent.trim()||'选择';
    const options=document.getElementById('lookup-picker-options');options.replaceChildren();
    for(const option of select.options){
      const button=document.createElement('button');button.className='lookup-option';button.type='button';button.setAttribute('role','option');button.setAttribute('aria-selected',String(option.selected));button.disabled=option.disabled;button.textContent=option.textContent;
      if(option.dataset.quality!=null){button.classList.add('mutation-quality');button.dataset.quality=option.dataset.quality;}
      button.addEventListener('click',()=>{select.value=option.value;select.dispatchEvent(new Event('change',{bubbles:true}));picker.close();});options.append(button);
    }
    picker.showModal();options.querySelector('[aria-selected=true]')?.focus({preventScroll:true});
  }
  // 只接管悬浮窗内的下拉框；选值仍走原页面的change处理。
  for(const eventName of ['mousedown','click'])document.addEventListener(eventName,event=>{if(event.target instanceof HTMLSelectElement){event.preventDefault();openSelect(event.target);}},true);
  document.addEventListener('keydown',event=>{if(event.target instanceof HTMLSelectElement&&['Enter',' ','ArrowDown','ArrowUp'].includes(event.key)){event.preventDefault();openSelect(event.target);}});
  document.getElementById('lookup-picker-close').addEventListener('click',()=>picker.close());
  picker.addEventListener('close',()=>{selected?.focus({preventScroll:true});selected=null;});
  document.addEventListener('focusin',event=>{if(!nativeFocus&&event.target.id==='mutation-query'&&typeof globalThis.MutationOverlay?.requestKeyboard==='function')MutationOverlay.requestKeyboard();});
  globalThis.handleFloatingLookupBack=()=>{if(picker.open){picker.close();return true;}if(document.body.dataset.page==='collection')return handlePlannerBack();return MutationTool.back();};
  globalThis.focusFloatingMutationSearch=()=>{
    if(picker.open)picker.close();MutationTool.back();nativeFocus=true;
    document.getElementById('mutation-query').focus({preventScroll:true});nativeFocus=false;return true;
  };
  // 自然内容高度与窗口高度分开计算，避免固定大窗和反复撑高。
  let frame,lastHeight=0;
  function reportHeight(){
    cancelAnimationFrame(frame);frame=requestAnimationFrame(()=>{
      if(document.getElementById('mutation-content').classList.contains('hidden'))return;
      const box=document.getElementById('main').getBoundingClientRect();if(box.width<100)return;
      const modal=picker.open||document.getElementById('mutation-detail').open;
      const height=modal?552:Math.max(180,Math.min(552,Math.ceil(box.height)));
      if(height!==lastHeight&&typeof globalThis.MutationOverlay?.reportContentHeight==='function'){lastHeight=height;MutationOverlay.reportContentHeight(height);}
    });
  }
  if(globalThis.ResizeObserver)new ResizeObserver(reportHeight).observe(document.getElementById('main'));
  else new MutationObserver(reportHeight).observe(document.getElementById('mutation-view'),{subtree:true,childList:true});
  const dialogs=new MutationObserver(reportHeight);for(const node of [picker,document.getElementById('mutation-detail')])dialogs.observe(node,{attributes:true,attributeFilter:['open']});
  window.addEventListener('resize',reportHeight);reportHeight();
})();
