/* 用户主动生成、复制和分享；不读取剪贴板，不上传图片或方案码。 */
(() => {
  'use strict';
  const $=id=>document.getElementById(id),app=PlannerApp,data=STAR_DATA,labels={crit:'暴击优先',power:'虚战优先','attack-pen':'攻击穿透','crit-target':'自定义暴击目标'};
  const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let generation=0,currentImage=null,currentCode='',incoming=null;
  const images=new Map(),pending=new Map();
  function loadImage(src){if(!images.has(src))images.set(src,new Promise((resolve,reject)=>{const image=new Image();image.onload=()=>resolve(image);image.onerror=()=>reject(new Error('图标未能载入'));image.src=src;}));return images.get(src);}
  function validConfig(config){const normalized=PersonalCore.validateConfig(config,data);if(!/^\d+$/.test(normalized.budget)||normalized.strategy==='crit-target'&&!/^\d+$/.test(normalized.critTarget))throw new Error('先填写完整点数与目标');createPlannerEngine(data).prepare({budget:Number(normalized.budget),capacity:Number(normalized.capacity),strategy:normalized.strategy,talentIds:normalized.selected,elementKeys:normalized.elements,elementRules:normalized.elementRules,elementStars:normalized.elementStars,critTarget:normalized.strategy==='crit-target'?Number(normalized.critTarget):undefined});return normalized;}
  function planCode(){return ShareCodec.encode(validConfig(app.shareContext().config),data);}
  async function copy(text){if(typeof globalThis.AndroidPlanner?.copyText==='function'){if(!AndroidPlanner.copyText(text))throw new Error('复制失败');}else await navigator.clipboard.writeText(text);}
  function openCode(){try{currentCode=planCode();$('plan-code-text').value=currentCode;$('plan-code-status').textContent='';$('plan-code-dialog').showModal();}catch(e){app.toast(e.message);}}
  async function openCard(type){
    const seq=++generation;currentImage=null;$('guide-card-preview').removeAttribute('src');$('guide-card-status').textContent='正在生成攻略卡…';for(const id of ['guide-card-save','guide-card-share','guide-card-code'])$(id).disabled=true;
    if(!$('guide-card-dialog').open)$('guide-card-dialog').showModal();
    try{
      let model;if(type==='star'){const context=app.shareContext();currentCode=ShareCodec.encode(validConfig(context.config),data);model=ShareCard.starModel(context,data,currentCode);}else{currentCode='';model=ShareCard.partModel(MutationTool.sharePart());}
      $('guide-card-title').textContent=type==='star'?'星宿攻略卡':'部位攻略卡';$('guide-card-code').classList.toggle('hidden',type!=='star');
      const layout=await ShareCard.render($('guide-card-canvas'),model,url=>{const qr=qrcode(0,'M');qr.addData(url,'Byte');qr.make();return qr;},loadImage);
      if(seq!==generation||!$('guide-card-dialog').open)return;const image=$('guide-card-canvas').toDataURL('image/png');
      currentImage={image,model,layout};$('guide-card-preview').src=image;$('guide-card-preview').alt=model.title+'；'+model.metrics.map(m=>m.name+m.value+(m.note?'，'+m.note:'')).join('；');$('guide-card-status').textContent='';for(const id of ['guide-card-save','guide-card-share','guide-card-code'])$(id).disabled=false;
    }catch(e){if(seq===generation)$('guide-card-status').textContent=e.message;}
  }
  function pngFile(){const raw=atob(currentImage.image.split(',')[1]),bytes=Uint8Array.from(raw,c=>c.charCodeAt(0));return new File([bytes],currentImage.model.type==='star'?'梧桐山海-星宿攻略卡.png':'梧桐山海-部位攻略卡.png',{type:'image/png'});}
  function downloadImage(){const a=document.createElement('a');a.href=currentImage.image;a.download=pngFile().name;a.click();}
  async function imageAction(saveOnly){
    if(!currentImage)return;
    const caption=currentImage.model.title+'\n'+(currentCode?'方案码：'+currentCode+'\n':'')+'梧桐山海：https://wutong.leeyan.site/download';
    try{
      if(typeof globalThis.AndroidPlanner?.shareGuideImage==='function'){
        const id=crypto.randomUUID();pending.set(id,generation);$('guide-card-save').disabled=true;$('guide-card-share').disabled=true;$('guide-card-status').textContent=saveOnly?'请选择图片保存位置':'正在打开系统分享…';AndroidPlanner.shareGuideImage(id,currentImage.image,caption,saveOnly);return;
      }
      const file=pngFile();if(!saveOnly&&navigator.canShare?.({files:[file]}))await navigator.share({title:currentImage.model.title,text:caption,files:[file]});else downloadImage();
    }catch(e){if(e.name!=='AbortError')$('guide-card-status').textContent='未能分享，可尝试保存图片后发送';}
  }
  globalThis.handleShareImageResult=(id,ok,message)=>{if(!pending.has(id))return;const seq=pending.get(id);pending.delete(id);if(seq===generation){$('guide-card-save').disabled=false;$('guide-card-share').disabled=false;$('guide-card-status').textContent=message;}if(ok)app.toast(message);};
  document.addEventListener('click',e=>{if(e.target.closest('[data-guide-card]'))openCard('star');if(e.target.closest('[data-plan-code]'))openCode();if(e.target.closest('[data-import-code]')){$('plan-import-text').value='';$('plan-import-preview').classList.add('hidden');$('plan-import-status').textContent='';incoming=null;$('plan-import-dialog').showModal();}});
  $('mutation-share-card').addEventListener('click',()=>openCard('part'));
  $('plan-code-copy').addEventListener('click',async()=>{try{await copy(currentCode);$('plan-code-status').textContent='方案码已复制';}catch{$('plan-code-status').textContent='复制失败，可长按方案码手动复制';}});
  $('guide-card-save').addEventListener('click',()=>imageAction(true));$('guide-card-share').addEventListener('click',()=>imageAction(false));$('guide-card-code').addEventListener('click',async()=>{try{await copy(currentCode);app.toast('方案码已复制');}catch{app.toast('复制失败，请重试');}});
  $('plan-import-text').addEventListener('input',()=>{incoming=null;$('plan-import-preview').classList.add('hidden');$('plan-import-status').textContent='';});
  $('plan-import-read').addEventListener('click',()=>{
    try{incoming=validConfig(ShareCodec.decode($('plan-import-text').value,data));$('plan-import-budget').value=incoming.budget;$('plan-import-capacity').value=incoming.capacity;
      const talents=new Map(data.talents.map(t=>[t.id,t])),stars=new Map(data.stars.map(s=>[s.id,s]));
      $('plan-import-summary').innerHTML=`<p><strong>${esc(labels[incoming.strategy])}</strong>${incoming.strategy==='crit-target'?' · 暴击至少＋'+incoming.critTarget:''}</p><p class="hint">天赋：${incoming.selected.map(id=>{const t=talents.get(id),s=stars.get(t.starId);return esc(s.weapon+' · '+s.name+' · '+({3:'绿',4:'紫',5:'红'}[t.quality])+'色');}).join('；')||'未指定'}</p><p class="hint">元素：${data.elements.flatMap(e=>e.options).filter(o=>incoming.elements.includes(o.key)).map(o=>esc(o.name)).concat((incoming.elementRules||[]).map(r=>esc(createElementRules(data).label(r)))).concat(createElementRules(data).summarizeStars(incoming.elementStars||[]).map(r=>esc(createElementRules(data).starLabel(r)))).join('、')||'未选'}</p>`;
      $('plan-import-preview').classList.remove('hidden');$('plan-import-status').textContent='';
    }catch(e){incoming=null;$('plan-import-status').textContent=e.message;}
  });
  $('plan-import-confirm').addEventListener('click',()=>{if(!incoming)return;try{const config=validConfig({...incoming,budget:$('plan-import-budget').value,capacity:$('plan-import-capacity').value});app.importSharedPlan(config);$('plan-import-dialog').close();app.toast('已另存方案，正在计算');}catch(e){$('plan-import-status').textContent=e.message;}});
  for(const id of ['guide-card-dialog','plan-code-dialog','plan-import-dialog'])$(id).addEventListener('close',()=>{if(id==='guide-card-dialog')generation++;});
  globalThis.ShareUI={back(){for(const id of ['guide-card-dialog','plan-code-dialog','plan-import-dialog'])if($(id).open){$(id).close();return true;}return false;}};
})();
