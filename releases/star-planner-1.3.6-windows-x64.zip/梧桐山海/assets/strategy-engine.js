/* 多规则求解：按共享入口分解组件；虚战使用资源计分并对取整作精确校正。 */
(function(root){
  'use strict';
  if(typeof module!=='undefined'&&module.exports)require('./auto-power.js');
  if(typeof module!=='undefined'&&module.exports)require('./crit-target.js');
  if(typeof module!=='undefined'&&module.exports)require('./element-goals.js');
  function createStrategyEngine(data, createBase, optimizer) {
    const base=createBase(data), byId=new Map(data.nodes.map(n=>[n.id,n]));
    const gateBits=new Map(data.gates.map((id,i)=>[id,1<<i]));
    const groups=new Map();for(const n of data.nodes){if(!groups.has(n.starId))groups.set(n.starId,[]);groups.get(n.starId).push(n);}
    const parameters=data.power?.parameters||{};
    function nativeTotal(levels){const totals=new Map();for(const [id,lv]of levels){const n=byId.get(id);totals.set(n.attrId,(totals.get(n.attrId)||0)+n.values[lv-1]);}return [...totals].reduce((sum,[id,v])=>sum+base.resourceScore(parameters[id],v),0);}
    function solve(request,progress=()=>{}) {
      const strategy=request.strategy||'crit';
      if(request.elementRules?.length||request.elementStars?.length)return createElementGoalEngine(data,createBase,optimizer).solve(request,progress);
      if(strategy==='crit')return base.solve(request,progress);
      if(strategy==='crit-target')return createCritTargetEngine(data,createBase,optimizer).solve(request,progress);
      if(!['power','attack-pen'].includes(strategy))throw new Error('优先规则无效');
      if(strategy==='power'&&data.talentPower)return createAutoPowerEngine(data,createBase,optimizer,createStrategyEngine).solve(request,progress);
      const started=Date.now(),prep=base.prepare(request);
      if(request.budget<prep.minimumCost)return {status:'insufficient',minimumCost:prep.minimumCost,deficit:prep.minimumCost-request.budget,fees:prep.fees,budget:request.budget};
      const power=strategy==='power',scale=100;
      const maxAttr=id=>data.nodes.filter(n=>n.attrId===id).reduce((s,n)=>s+Math.max(...n.values),0);
      const critWeight=maxAttr(data.objective.crit)+1,attackWeight=(maxAttr(2016)+1)*critWeight;
      const coefficients=new Map();
      for(const n of data.nodes){
        let coefficient=0;
        if(power){const p=parameters[n.attrId];if(p?.length){coefficient=p.length===1?p[0]*scale:p[0]*scale/p[1];if(!Number.isSafeInteger(coefficient)||coefficient<0)throw new Error('资源参数暂不支持精确虚战求解');}}
        else coefficient=n.attrId===data.objective.attack?attackWeight:n.attrId===2016?critWeight:n.attrId===data.objective.crit?1:0;
        coefficients.set(n.attrId,coefficient);
      }
      const rawMaximum=data.nodes.reduce((s,n)=>s+Math.max(...n.values)*coefficients.get(n.attrId),0);
      if(!Number.isSafeInteger(rawMaximum))throw new Error('规则得分超出精确整数范围');
      const totalCost=data.nodes.reduce((s,n)=>s+n.costs.reduce((a,b)=>a+b,0),0),limit=Math.min(request.budget,totalCost);
      const cache=new Map();let best=null,visited=0;
      const scoreLevels=levels=>power?nativeTotal(levels):[...levels].reduce((s,[id,lv])=>s+byId.get(id).values[lv-1]*coefficients.get(byId.get(id).attrId),0);
      const mergeParts=options=>{const levels=new Map();for(const option of options)for(const part of option.parts)part.nodes.forEach((n,i)=>{if(part.levels[i])levels.set(n.id,part.levels[i]);});return levels;};
      function accept(options,cost){const levels=mergeParts(options),value=scoreLevels(levels);if(!best||value>best.value||(value===best.value&&cost<best.cost))best={levels,value,cost};}

      // 相同成本只保留可能影响最终取整的近优候选；同得分和余数组合可安全合并。
      function optionsFor(nodes,mask){
        const ownIds=new Set(nodes.map(n=>n.id));let relevant=0;
        for(const n of nodes){relevant|=gateBits.get(n.id)||0;for(const p of n.pre)if(!ownIds.has(p)){if(!gateBits.has(p))throw new Error('存在未建模的跨星宿前置');relevant|=gateBits.get(p);}}
        const key=nodes[0].starId+':'+(mask&relevant);if(cache.has(key))return cache.get(key);
        const ordered=[],added=new Set();while(ordered.length<nodes.length){const ready=nodes.filter(n=>!added.has(n.id)&&n.pre.every(p=>!ownIds.has(p)||added.has(p))).sort((a,b)=>a.id-b.id);if(!ready.length)throw new Error('星宿前置存在循环');for(const n of ready){ordered.push(n);added.add(n.id);}}
        const fractional=[...new Set(nodes.filter(n=>power&&n.values.some(v=>(v*coefficients.get(n.attrId))%scale!==0)).map(n=>n.attrId))].sort((a,b)=>a-b);
        const slack=power?fractional.length*scale:0,buckets=new Map(),chosen=new Array(ordered.length).fill(0),values=new Map(),levels=new Map();
        const costs=ordered.map(n=>[0,...n.costs.map((_,i)=>n.costs.slice(0,i+1).reduce((a,b)=>a+b,0))]);
        function emit(cost,raw){
          let bucket=buckets.get(cost);if(!bucket){bucket={max:raw,items:new Map()};buckets.set(cost,bucket);}
          if(raw<bucket.max-slack)return;
          if(raw>bucket.max){bucket.max=raw;for(const [k,v]of bucket.items)if(v.raw<raw-slack)bucket.items.delete(k);}
          const residual=fractional.map(id=>((values.get(id)||0)*coefficients.get(id))%scale).join(',');const signature=raw+':'+residual;
          if(!bucket.items.has(signature))bucket.items.set(signature,{cost,raw,attrs:[...values].filter(([,v])=>v),parts:[{nodes:ordered,levels:chosen.slice()}]});
        }
        function walk(i,cost,raw){
          if(cost>limit)return;if(i===ordered.length){emit(cost,raw);return;}
          const n=ordered[i],required=Math.max(prep.required.get(n.id)||0,(gateBits.get(n.id)&mask)?1:0);
          const allowed=n.pre.every(p=>ownIds.has(p)?!!levels.get(p):(mask&gateBits.get(p))!==0);
          const blocked=(gateBits.has(n.id)&&!(mask&gateBits.get(n.id)))||!allowed;
          const max=blocked?0:coefficients.get(n.attrId)?n.values.length:Math.max(required,1);
          if(required>max)return;
          for(let lv=required;lv<=max;lv++){
            chosen[i]=lv;levels.set(n.id,lv);const value=lv?n.values[lv-1]:0,old=values.get(n.attrId)||0;values.set(n.attrId,old+value);
            walk(i+1,cost+costs[i][lv],raw+value*coefficients.get(n.attrId));values.set(n.attrId,old);
          }
          chosen[i]=0;levels.delete(n.id);
        }
        walk(0,0,0);const result=[...buckets.values()].flatMap(b=>[...b.items.values()]).sort((a,b)=>a.cost-b.cost||b.raw-a.raw);cache.set(key,result);return result;
      }
      function collapse(options){const bestByCost=new Map();for(const o of options){const current=bestByCost.get(o.cost);if(!current||o.raw>current.raw)bestByCost.set(o.cost,o);}return [...bestByCost.values()].sort((a,b)=>a.cost-b.cost);}
      function buildGroups(mask){
        const all=new Map([...groups].map(([id,nodes])=>[id,optionsFor(nodes,mask)]));if([...all.values()].some(o=>!o.length))return null;
        // 每个元素仅出现在对应两个星宿，先对其合计取整后独立闭合，避免扩大外层余数维度。
        if(power)for(const element of data.elements||[]){
          const ids=element.starIds;if(ids.length!==2)throw new Error('元素星宿结构异常');
          const attrs=new Set(data.nodes.filter(n=>ids.includes(n.starId)).map(n=>n.attrId));
          if(data.nodes.some(n=>!ids.includes(n.starId)&&attrs.has(n.attrId)))throw new Error('元素属性存在未建模的跨星宿计分');
          const left=all.get(ids[0]),right=all.get(ids[1]),merged=[];
          if(!left||!right)continue;
          for(const a of left)for(const b of right){const cost=a.cost+b.cost;if(cost>limit)continue;const totals=new Map(a.attrs);for(const [id,v]of b.attrs)totals.set(id,(totals.get(id)||0)+v);const value=[...totals].reduce((s,[id,v])=>s+base.resourceScore(parameters[id],v),0);merged.push({cost,raw:value*scale,attrs:[],parts:[...a.parts,...b.parts]});}
          all.delete(ids[1]);all.set(ids[0],collapse(merged));
        }
        return [...all.values()];
      }
      const jobs=[];
      for(let mask=0;mask<(1<<data.gates.length);mask++){
        const options=buildGroups(mask);if(!options)continue;
        const upper=options.map(collapse),suffix=new Array(options.length+1);suffix[options.length]=new Float64Array(limit+1);suffix[options.length].fill(-1);suffix[options.length][0]=0;
        for(let i=options.length-1;i>=0;i--){const next=new Float64Array(limit+1);next.fill(-1);for(const o of upper[i])for(let c=o.cost;c<=limit;c++)if(suffix[i+1][c-o.cost]>=0)next[c]=Math.max(next[c],o.raw+suffix[i+1][c-o.cost]);suffix[i]=next;}
        let rawBest=-1,costBest=-1;for(let c=0;c<=limit;c++)if(suffix[0][c]>rawBest){rawBest=suffix[0][c];costBest=c;}
        if(costBest<0)continue;
        const candidate=[];let remaining=costBest;
        for(let i=0;i<options.length;i++){const o=upper[i].find(o=>o.cost<=remaining&&suffix[i+1][remaining-o.cost]>=0&&o.raw+suffix[i+1][remaining-o.cost]===suffix[i][remaining]);if(!o)throw new Error('优先规则回溯失败');candidate.push(o);remaining-=o.cost;}
        accept(candidate,costBest);
        if(power)for(let c=0;c<=limit;c++){const bound=suffix[0][c];if(bound>=0)jobs.push({options,suffix,cost:c,bound:Math.floor(bound/scale)});}
        progress(Math.round((mask+1)*60/(1<<data.gates.length)));
      }
      if(!best)throw new Error('当前规则下没有可行方案');
      if(power){
        jobs.sort((a,b)=>b.bound-a.bound||a.cost-b.cost);
        const fractionalIds=[...new Set(data.nodes.filter(n=>!(data.elements||[]).some(e=>e.starIds.includes(n.starId))&&n.values.some(v=>(v*coefficients.get(n.attrId))%scale!==0)).map(n=>n.attrId))].sort((a,b)=>a-b);
        for(let ji=0;ji<jobs.length;ji++){
          const job=jobs[ji];if(job.bound<best.value||(job.bound===best.value&&job.cost>=best.cost))continue;
          const chosen=[],attributes=new Map(),memo=new Map();
          function search(i,remaining,raw){
            visited++;const suffix=job.suffix[i][remaining];if(suffix<0)return;const bound=Math.floor((raw+suffix)/scale);
            if(bound<best.value||(bound===best.value&&job.cost>=best.cost))return;
            if(i===job.options.length){if(!remaining)accept(chosen,job.cost);return;}
            const signature=i+':'+remaining+':'+fractionalIds.map(id=>((attributes.get(id)||0)*coefficients.get(id))%scale).join(',');
            if((memo.get(signature)??-1)>=raw)return;memo.set(signature,raw);
            const ordered=job.options[i].filter(o=>o.cost<=remaining&&job.suffix[i+1][remaining-o.cost]>=0).sort((a,b)=>(b.raw+job.suffix[i+1][remaining-b.cost])-(a.raw+job.suffix[i+1][remaining-a.cost]));
            for(const o of ordered){chosen.push(o);for(const [id,v]of o.attrs)attributes.set(id,(attributes.get(id)||0)+v);search(i+1,remaining-o.cost,raw+o.raw);for(const [id,v]of o.attrs)attributes.set(id,attributes.get(id)-v);chosen.pop();}
          }
          search(0,job.cost,0);progress(60+Math.round((ji+1)*40/jobs.length));
        }
      }
      base.validate(best.levels,request.budget,prep);
      const description=power?'虚战优先：资源计分最高，同分少耗点':'攻击优先，其次穿透、暴击，同收益少耗点';
      const result=base.describe(best,request,prep,Date.now()-started,{evaluate:scoreLevels,description});result.searchStates=visited;progress(100);return result;
    }
    return {solve};
  }
  if(typeof module!=='undefined'&&module.exports)module.exports={createStrategyEngine};
  root.createStrategyEngine=createStrategyEngine;
})(globalThis);
