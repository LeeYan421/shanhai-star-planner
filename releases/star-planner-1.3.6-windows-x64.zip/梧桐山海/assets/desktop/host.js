/* 桌面端保留既有页面契约，所有原生能力均由明确的COM接口提供。 */
(() => {
  'use strict';
  const host=chrome.webview.hostObjects.sync.planner;
  globalThis.DesktopHost=true;
  globalThis.AndroidPlanner={
    copyText:text=>host.CopyText(String(text)),shareText:text=>host.ShareText(String(text)),
    getDiagnosticLogs:()=>host.GetDiagnosticLogs(),
    showFloatingGuide:raw=>host.ShowFloatingGuide(raw),hideFloatingGuide:()=>host.HideFloatingGuide(),
    getGuideProgress:key=>host.GetGuideProgress(key),saveGuideProgress:(key,raw)=>{if(!host.SaveGuideProgress(key,raw))return false;try{localStorage.setItem('star-guide-progress-'+key,JSON.stringify({plan:key,ids:JSON.parse(raw)}));}catch{throw new Error('进度已保存在本机，但备份同步失败，请释放空间后重试');}return true;},
    getFloatingGuide:()=>host.GetFloatingGuide(),showMutationLookup:()=>host.ShowMutationLookup(),
    showFloatingClock:()=>host.ShowFloatingClock(),hideFloatingClock:()=>host.HideFloatingClock(),getClockState:()=>host.GetClockState(),saveClockSettings:raw=>host.SaveClockSettings(raw),
    communityRequest:(...args)=>host.CommunityRequest(...args),exportBackup:raw=>host.ExportBackup(raw),shareGuideImage:(...args)=>host.ShareGuideImage(...args),
    joinQQGroup:()=>host.JoinQQGroup(),openQQInvitePage:()=>host.OpenQQInvitePage(),checkForUpdates:()=>host.CheckForUpdates(),windowAction:action=>host.WindowAction(action)
  };
  globalThis.__windowsErrors=[];
  addEventListener('error',event=>__windowsErrors.push(String(event.message)));
  addEventListener('unhandledrejection',event=>__windowsErrors.push(String(event.reason?.message||'promise error')));
  document.addEventListener('DOMContentLoaded',()=>{
    const link=document.createElement('link');link.rel='stylesheet';link.href='/desktop/desktop.css';document.head.append(link);
    const version=document.querySelector('.version-row span');if(version)version.textContent='1.3.6 · Windows x64';
    document.querySelectorAll('.help-item p').forEach(p=>{if(p.textContent.startsWith('安卓安装版可开启悬浮窗'))p.textContent='悬浮窗保持置顶，可拖动、调整大小和最小化。加点进度与主窗口同步；修改需求会关闭旧指导。游戏建议使用窗口或无边框模式。';});
    document.addEventListener('click',event=>{if(event.target.closest('#clock-open'))setTimeout(()=>{const status=document.getElementById('clock-status');if(status)status.textContent='拖动移动，滚轮或双指缩放，长按关闭。';},0);});
  });
})();
