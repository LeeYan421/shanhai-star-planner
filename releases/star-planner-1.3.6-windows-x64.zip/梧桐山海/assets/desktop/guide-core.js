/* 星宿分组沿用原节点顺序，完成/撤销始终按前置关系更新节点ID。 */
(function(root){
  'use strict';
  function groups(plan){const map=new Map();for(const node of plan.steps){const key=node.starId||node.title;if(!map.has(key))map.set(key,{key,title:node.title,location:node.location,nodes:[],cost:0,cumulative:0});const group=map.get(key);group.nodes.push(node);group.cost+=node.cost;group.cumulative=node.cumulative;}return [...map.values()].map(group=>({...group,rows:plan.groups.find(g=>g.title===group.title)?.rows||group.nodes.slice().sort((a,b)=>a.row-b.row)}));}
  function restore(plan,ids){const requested=new Set(Array.isArray(ids)?ids:[]),checked=new Set();for(const node of plan.steps)if(requested.has(node.id)&&node.preIds.every(id=>checked.has(id)))checked.add(node.id);return checked;}
  function canComplete(group,checked){const possible=new Set(checked);for(const node of group.nodes){if(node.preIds.some(id=>!possible.has(id)))return false;possible.add(node.id);}return true;}
  function toggle(plan,checked,index){const group=groups(plan)[index];if(!group)throw new Error('星宿不存在');const next=new Set(checked);if(group.nodes.every(n=>next.has(n.id))){for(const node of group.nodes)next.delete(node.id);let changed;do{changed=false;for(const node of plan.steps)if(next.has(node.id)&&node.preIds.some(id=>!next.has(id))){next.delete(node.id);changed=true;}}while(changed);}else{if(!canComplete(group,next))throw new Error('请先完成前置星宿');for(const node of group.nodes)next.add(node.id);}return next;}
  const api={groups,restore,canComplete,toggle};if(typeof module!=='undefined'&&module.exports)module.exports=api;root.DesktopGuideCore=api;
})(globalThis);
