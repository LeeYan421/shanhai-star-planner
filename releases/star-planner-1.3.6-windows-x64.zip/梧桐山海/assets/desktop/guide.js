(() => {
  'use strict';
  const $=id=>document.getElementById(id),core=DesktopGuideCore,esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let plan,groups=[],checked=new Set(),cursor=0,mode='overview';
  const complete=g=>g.nodes.every(n=>checked.has(n.id));
  function layout(){if(mode!=='overview'||cursor<0)return;const grid=$('rows'),rows=groups[cursor].rows,count=Math.max(1,Math.floor(grid.clientHeight/26)),columns=Math.min(Math.ceil(rows.length/count),Math.max(1,Math.floor(grid.clientWidth/150))),per=Math.ceil(rows.length/columns);grid.style.gridTemplateRows=`repeat(${per},26px)`;grid.style.gridTemplateColumns=`repeat(${columns},minmax(0,1fr))`;grid.style.overflowY=per*26>grid.clientHeight?'auto':'hidden';}
  function render(){
    const group=groups[cursor];$('position').textContent=groups.filter(complete).length+'/'+groups.length+'步';$('title').textContent=group?group.title:'加点已完成';$('location').textContent=group?.location||'';$('order').textContent=group?'点亮顺序：'+group.nodes.map(n=>n.row).join(' → ')+'行':'';
    $('rows').hidden=mode!=='overview'||!group;$('content').hidden=mode==='overview'&&!!group;
    if(group){$('rows').innerHTML=group.rows.map(row=>`<div class="row ${!row.level?'skipped':checked.has(row.id)?'checked':''}"><span>${row.row} ${esc(row.attribute)}</span><strong>${row.level?'Lv'+row.level+(checked.has(row.id)?' ✓':''):'不点'}</strong></div>`).join('');$('status').textContent='本宿'+group.cost+'点 · 累计'+group.cumulative+'/'+plan.spent+'点';}
    else{$('status').textContent='可返回主窗口核对并装备天赋。';$('content').textContent=(plan.talents||[]).join('\n\n')||'所有星宿已完成。';}
    if(mode==='details'&&group)$('content').textContent=[plan.name,plan.goal,...group.nodes.flatMap(n=>['第'+n.row+'行 · '+n.attribute+' → Lv'+n.level,'+'+n.value+' · '+n.cost+'点',n.levelText,''])].filter(Boolean).join('\n');
    if(mode==='list')$('content').innerHTML=groups.map((g,i)=>`<button class="star" data-jump="${i}">${i+1}. ${esc(g.title)} · ${g.cost}点${complete(g)?' ✓':''}</button>`).join('');
    $('details').textContent=mode==='details'?'总览':'明细';$('list').textContent=mode==='list'?'总览':'清单';$('done').textContent=!group?'关闭':complete(group)?'撤销本宿':'完成本宿';$('done').disabled=!!group&&!core.canComplete(group,checked);if(group&&!core.canComplete(group,checked))$('status').textContent='请先完成前置星宿';requestAnimationFrame(layout);
  }
  globalThis.refreshGuide=()=>{const raw=AndroidPlanner.getFloatingGuide();if(!raw||raw==='null')return;plan=JSON.parse(raw);groups=core.groups(plan);let saved=plan.checked||[];try{saved=JSON.parse(AndroidPlanner.getGuideProgress(plan.key)||JSON.stringify(saved));}catch{}checked=core.restore(plan,saved);cursor=groups.findIndex(g=>!complete(g));render();};
  $('previous').onclick=()=>{cursor=cursor<0?groups.length-1:Math.max(0,cursor-1);mode='overview';render();};$('next').onclick=()=>{cursor=Math.min(groups.length-1,Math.max(0,cursor)+1);mode='overview';render();};
  $('details').onclick=()=>{mode=mode==='details'?'overview':'details';render();};$('list').onclick=()=>{mode=mode==='list'?'overview':'list';render();};$('content').onclick=e=>{const b=e.target.closest('[data-jump]');if(b){cursor=Number(b.dataset.jump);mode='overview';render();}};
  $('done').onclick=()=>{if(cursor<0){AndroidPlanner.windowAction('close');return;}try{const next=core.toggle(plan,checked,cursor);if(!AndroidPlanner.saveGuideProgress(plan.key,JSON.stringify([...next])))throw new Error('进度未能保存');checked=next;cursor=groups.findIndex(g=>!complete(g));mode='overview';render();}catch(error){$('status').textContent=error.message;}};
  new ResizeObserver(layout).observe($('rows'));globalThis.DesktopGuide={jump(index){cursor=index;mode='overview';render();},snapshot:()=>({cursor,checked:[...checked],groups:groups.length,rows:groups[cursor]?.rows.length||0})};refreshGuide();
})();
