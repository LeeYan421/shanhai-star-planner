/* 变异速查仅检索配置候选；空穿透保留为空，不参与数值或档位推断。 */
(function(root){
  'use strict';
  const visibleCategories=new Set([0,1,4]);
  function isVisibleMutationWord(word){return word.categories.some(category=>visibleCategories.has(category));}
  // 连续相同效果合并显示等级区间，不省略任意累计等级的效果。
  function groupMutationLevels(levels){
    const groups=[];
    for(const level of levels){const last=groups[groups.length-1];if(last&&last.to+1===level.level&&last.description===level.description)last.to=level.level;else groups.push({from:level.level,to:level.level,description:level.description});}
    return groups;
  }
  function createMutationIndex(data){
    const battle=new Map(data.battle.map(item=>[item.id,item]));
    const special=new Map(data.special.map(item=>[item.id,item]));
    const specialWords=new Map(data.special.flatMap(item=>(item.words||[]).map(word=>[word.id,word])));
    const text=row=>[row.name,row.fullName,data.parts[row.part],data.positions[row.sourcePos],...row.battle.map(id=>battle.get(id).name),...(row.special||[]).map(id=>special.get(id).name),...Object.keys(row.attributes)].join(' ').toLocaleLowerCase();
    const searchable=new Map(data.rows.map(row=>[row.id,text(row)]));
    function search({query='',part='',trait='',age='',sort='attack',word='',specialId=''}={}){
      const tokens=query.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
      return data.rows.filter(row=>(part===''||row.part===Number(part))&&(trait===''||row.battle.includes(Number(trait)))&&(specialId===''||(row.special||[]).includes(Number(specialId)))&&(age===''||row.age===Number(age))&&tokens.every(token=>searchable.get(row.id).includes(token))&&(word===''||Object.values(row.options).some(opt=>[...opt.pools,...opt.special].some(id=>data.pools[id].words.includes(Number(word)))))).sort((a,b)=>{
        const primary=sort==='pierce'?'防御穿透':'攻击',secondary=sort==='pierce'?'攻击':'防御穿透';
        return (b.attributes[primary]??-1)-(a.attributes[primary]??-1)||(b.attributes[secondary]??-1)-(a.attributes[secondary]??-1)||a.name.localeCompare(b.name,'zh-CN')||a.sourcePos-b.sourcePos||a.id-b.id;
      });
    }
    // 同一来源的候选按四个元素池求并集，保留每项原始效果，不合计四元素。
    function poolWords(row,category){
      const ids=new Set();
      for(const option of Object.values(row.options)){
        const pools=category===4?option.special:[option.pools[category]];
        for(const id of pools)for(const word of data.pools[id].words)ids.add(word);
      }
      return [...ids].sort((a,b)=>(data.words[b].quality-data.words[a].quality)||a-b);
    }
    function variants(row,familyId){
      const available=new Set(poolWords(row,1));
      return (battle.get(Number(familyId))?.variants||[]).filter(v=>available.has(v.id));
    }
    // 按具体部位的特殊词条池限制可出的特性等级和品质。
    function specialOptions(row,specialId){
      const available=new Set(poolWords(row,4));
      return (special.get(Number(specialId))?.words||[]).filter(word=>available.has(word.id)).sort((a,b)=>b.level-a.level||b.quality-a.quality);
    }
    return {search,poolWords,variants,specialOptions,battle,special,specialWords};
  }
  if(typeof module==='object'&&module.exports)module.exports={createMutationIndex,isVisibleMutationWord,groupMutationLevels};
  else Object.assign(root,{createMutationIndex,isVisibleMutationWord,groupMutationLevels});
})(globalThis);
