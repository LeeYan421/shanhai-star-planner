/* 元素上限只计算本元素两盘，公共前置始终归入大荒总预算。 */
(function(root){
  'use strict';
  function createElementRules(data){
    const elements=data.elements||[];
    const stars=elements.flatMap(e=>(e.starIds||[]).map(id=>({id,element:e,...(data.stars||[]).find(s=>s.id===id),nodes:(data.nodes||[]).filter(n=>n.starId===id).sort((a,b)=>(a.row||a.id)-(b.row||b.id))})));
    function normalizeStars(raw=[],full=[],custom=[]){
      if(!Array.isArray(raw)||raw.length>stars.length)throw new Error('元素星宿设置无效');
      const seen=new Set();
      return raw.map(item=>{
        const star=stars.find(s=>s.id===item?.starId);
        if(!star||seen.has(star.id)||!Array.isArray(item.levels)||item.levels.length!==star.nodes.length||item.levels.some((lv,i)=>!Number.isInteger(lv)||lv<0||lv>star.nodes[i].values.length))throw new Error('元素星宿等级无效');
        if(star.element.options.some(o=>full.includes(o.key))||custom.some(r=>r.key===star.element.key))throw new Error(star.element.name+'不能同时使用逐行设置和旧合计目标');
        seen.add(star.id);const levels=item.levels.slice(),index=new Map(star.nodes.map((n,i)=>[n.id,i]));
        // 手动等级固定；仅补齐本星宿内必需的前置，公共前置由总求解器统一闭合。
        let changed=true;while(changed){changed=false;star.nodes.forEach((n,i)=>{if(levels[i])for(const id of n.pre)if(index.has(id)&&levels[index.get(id)]===0){levels[index.get(id)]=1;changed=true;}});}
        return {starId:star.id,levels};
      }).sort((a,b)=>stars.findIndex(s=>s.id===a.starId)-stars.findIndex(s=>s.id===b.starId));
    }
    function summarizeStars(raw){return raw.map(item=>{const star=stars.find(s=>s.id===item.starId);return {starId:star.id,name:star.name,element:star.element.name,location:star.location,spent:star.nodes.reduce((sum,n,i)=>sum+n.costs.slice(0,item.levels[i]).reduce((a,b)=>a+b,0),0),rows:star.nodes.map((n,i)=>({id:n.id,row:n.row||i+1,attribute:n.attribute,level:item.levels[i],value:item.levels[i]?n.values[item.levels[i]-1]:0}))};});}
    function starLabel(item){return item.element+' · '+item.name+'：'+item.rows.map(r=>r.level).join('/')+'级（自上而下）';}
    function normalize(raw=[],full=[]){
      if(!Array.isArray(raw)||raw.length>elements.length)throw new Error('元素自定义目标无效');
      const seen=new Set();
      return raw.map(rule=>{
        const e=elements.find(e=>e.key===rule?.key);
        if(!e||seen.has(e.key)||!['points','attack'].includes(rule.mode))throw new Error('元素自定义目标无效');
        seen.add(e.key);
        if(!/^\d{1,7}$/.test(String(rule.value))||Number(rule.value)>1000000)throw new Error(e.name+'请输入0至1000000的整数');
        if(e.options.some(o=>full.includes(o.key)))throw new Error(e.name+'不能同时点满属性与自定义目标');
        const value=Number(rule.value),attack=e.options.find(o=>o.label==='攻击');
        if(!attack)throw new Error('元素攻击数据缺失');
        const maximum=data.nodes.filter(n=>e.starIds.includes(n.starId)&&n.attrId===attack.attrId).reduce((s,n)=>s+Math.max(...n.values),0);
        if(rule.mode==='attack'&&value>maximum)throw new Error(e.name+'攻击最多提供+'+maximum);
        return {key:e.key,mode:rule.mode,value};
      }).sort((a,b)=>elements.findIndex(e=>e.key===a.key)-elements.findIndex(e=>e.key===b.key));
    }
    function label(rule){const e=elements.find(e=>e.key===rule.key);return e.name+(rule.mode==='points'?'≤'+rule.value+'点（先攻击后穿透）':'攻击至少+'+rule.value);}
    function summarize(raw,levels){
      const get=id=>levels instanceof Map?levels.get(id):levels[id];
      return raw.map(rule=>{
        const e=elements.find(e=>e.key===rule.key),nodes=data.nodes.filter(n=>e.starIds.includes(n.starId));
        const total=label=>{const attr=e.options.find(o=>o.label===label)?.attrId;return nodes.reduce((s,n)=>s+(n.attrId===attr&&get(n.id)?n.values[get(n.id)-1]:0),0);};
        return {...rule,name:e.name,spent:nodes.reduce((s,n)=>s+n.costs.slice(0,get(n.id)||0).reduce((a,b)=>a+b,0),0),attack:total('攻击'),penetration:total('防御穿透')};
      });
    }
    function resultLabel(rule){return label(rule)+' · 实投'+rule.spent+'点 · 攻击+'+rule.attack+' · 穿透+'+rule.penetration;}
    return {normalize,label,summarize,resultLabel,stars,normalizeStars,summarizeStars,starLabel};
  }
  if(typeof module!=='undefined'&&module.exports)module.exports={createElementRules};
  root.createElementRules=createElementRules;
})(globalThis);
