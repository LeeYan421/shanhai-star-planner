/* 样式预览和偏好只保存在本机；只有用户主动点击才申请悬浮权限。 */
(() => {
  'use strict';
  const $=id=>document.getElementById(id),key='wutong-clock-ui-v1';
  const presets={clear:{textColor:'#FFFFFF',backgroundColor:'#122037',outlineColor:'#1A2A40',outline:true,backgroundOpacity:0},night:{textColor:'#E7EDF6',backgroundColor:'#122037',outlineColor:'#1A2A40',outline:false,backgroundOpacity:100},pill:{textColor:'#2C4C74',backgroundColor:'#F3F7FC',outlineColor:'#1A2A40',outline:false,backgroundOpacity:100}};
  const defaults={style:'clear',seconds:true,hour24:true,scale:100,opacity:90,...presets.clear};
  let settings={...defaults},timer=null;
  const native=()=>typeof globalThis.AndroidPlanner?.getClockState==='function';
  function normalize(raw){
    const style=raw?.style==='dial'?'clear':raw?.style;
    if(!raw||!Object.prototype.hasOwnProperty.call(presets,style)||typeof raw.seconds!=='boolean'||typeof raw.hour24!=='boolean'||!Number.isFinite(raw.scale)||raw.scale<=0||!Number.isInteger(raw.opacity)||raw.opacity<50||raw.opacity>100)throw new Error('时钟设置无效');
    const appearance={...presets[style]};for(const key of Object.keys(appearance))if(raw[key]!==undefined)appearance[key]=raw[key];
    for(const key of ['textColor','backgroundColor','outlineColor']){if(typeof appearance[key]!=='string'||!/^#[0-9a-f]{6}$/i.test(appearance[key]))throw new Error('时钟颜色无效');appearance[key]=appearance[key].toUpperCase();}
    if(typeof appearance.outline!=='boolean'||!Number.isInteger(appearance.backgroundOpacity)||appearance.backgroundOpacity<0||appearance.backgroundOpacity>100)throw new Error('时钟配色无效');
    return {style,seconds:raw.seconds,hour24:raw.hour24,scale:raw.scale,opacity:raw.opacity,...appearance};
  }
  function state(){try{return native()?JSON.parse(AndroidPlanner.getClockState()):{running:false};}catch{return {running:false};}}
  function time(date){const h=date.getHours(),hour=settings.hour24?h:h%12||12;return (settings.hour24?'':h<12?'上午 ':'下午 ')+[hour,date.getMinutes(),...(settings.seconds?[date.getSeconds()]:[])].map(v=>String(v).padStart(2,'0')).join(':');}
  function renderControls(){document.querySelectorAll('[data-clock-style]').forEach(b=>{b.setAttribute('aria-checked',String(b.dataset.clockStyle===settings.style));b.classList.toggle('selected',b.dataset.clockStyle===settings.style);});$('clock-seconds').checked=settings.seconds;$('clock-24h').checked=settings.hour24;$('clock-outline').checked=settings.outline;$('clock-outline-color').disabled=!settings.outline;for(const [id,key]of [['clock-text-color','textColor'],['clock-background-color','backgroundColor'],['clock-outline-color','outlineColor']])$(id).value=settings[key];for(const [id,key]of [['clock-scale','scale'],['clock-opacity','opacity'],['clock-background-opacity','backgroundOpacity']]){$(id).value=settings[key];$(id+'-value').textContent=id==='clock-scale'?'%':settings[key]+'%';}}
  function persist(style=settings.style,reset=false){
    const before={...settings};try{settings=normalize({...settings,style,seconds:$('clock-seconds').checked,hour24:$('clock-24h').checked,scale:Number($('clock-scale').value),opacity:Number($('clock-opacity').value),textColor:$('clock-text-color').value,backgroundColor:$('clock-background-color').value,outlineColor:$('clock-outline-color').value,outline:$('clock-outline').checked,backgroundOpacity:Number($('clock-background-opacity').value),...(reset?presets[style]:{})});if(native()&&AndroidPlanner.saveClockSettings(JSON.stringify(settings))!==true)throw new Error('时钟设置未能保存');try{localStorage.setItem(key,JSON.stringify(settings));}catch(e){if(!native())throw e;}renderControls();$('clock-status').textContent='';draw();return true;}catch(error){globalThis.Diagnostics?.record('clock',error);settings=before;renderControls();$('clock-status').textContent='设置未能保存，请重试';return false;}
  }
  function draw(){const text=time(new Date());document.querySelectorAll('.clock-sample').forEach(sample=>{const node=sample.querySelector('.clock-preview-time'),appearance=sample.dataset.sample===settings.style?settings:presets[sample.dataset.sample],color=parseInt(appearance.backgroundColor.slice(1),16);node.textContent=text;node.classList.toggle('clock-preview-12',!settings.hour24);node.style.opacity=settings.opacity/100;node.style.color=appearance.textColor;node.style.backgroundColor=`rgba(${color>>16},${color>>8&255},${color&255},${appearance.backgroundOpacity/100})`;node.style.textShadow=appearance.outline?[`1px 1px 1px`,`-1px -1px 1px`,`1px -1px 1px`,`-1px 1px 1px`].map(offset=>offset+' '+appearance.outlineColor).join(','):'none';});$('clock-live-time').textContent=text;refreshStatus();}
  function refreshStatus(){const running=!!state().running;$('clock-running').textContent=running?'已开启':'未开启';$('clock-open').textContent=running?'重新显示时钟':'开启悬浮时钟';$('clock-stop').disabled=!running;}
  function refresh(){if(native())try{settings=normalize(state().config);renderControls();}catch{}tick();}
  function tick(){clearTimeout(timer);if(document.body.dataset.page!=='clock'||document.hidden)return;draw();timer=setTimeout(tick,1000-Date.now()%1000);}
  function open(){try{const saved=native()?state().config:JSON.parse(localStorage.getItem(key)||'null');settings=normalize(saved||defaults);}catch{settings={...defaults};}renderControls();tick();}
  // 选择预设只替换配色，时间格式、大小和位置继续保留。
  document.querySelectorAll('[data-clock-style]').forEach(b=>b.addEventListener('click',()=>persist(b.dataset.clockStyle,true)));
  document.querySelector('.clock-style-grid').addEventListener('keydown',event=>{if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key))return;const options=[...document.querySelectorAll('[data-clock-style]')],index=options.indexOf(document.activeElement);if(index<0)return;event.preventDefault();const next=options[(index+(['ArrowLeft','ArrowUp'].includes(event.key)?-1:1)+options.length)%options.length];next.focus();persist(next.dataset.clockStyle,true);});
  for(const id of ['clock-seconds','clock-24h','clock-scale','clock-opacity','clock-text-color','clock-outline-color','clock-outline','clock-background-opacity'])$(id).addEventListener('change',()=>persist());
  $('clock-background-color').addEventListener('change',()=>{if(Number($('clock-background-opacity').value)===0)$('clock-background-opacity').value=100;persist();});
  $('clock-reset-colors').addEventListener('click',()=>persist(settings.style,true));
  for(const id of ['clock-opacity','clock-background-opacity'])$(id).addEventListener('input',()=>$(id+'-value').textContent=$(id).value+'%');
  $('clock-open').addEventListener('click',()=>{if(!native()){$('clock-status').textContent='请使用安卓安装版开启悬浮时钟。';return;}if(!persist())return;AndroidPlanner.showFloatingClock();$('clock-status').textContent='按系统提示授权后，可切回游戏查看。';});
  $('clock-stop').addEventListener('click',()=>{if(native())AndroidPlanner.hideFloatingClock();$('clock-status').textContent='已请求关闭时钟';setTimeout(refreshStatus,150);});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)clearTimeout(timer);else if(document.body.dataset.page==='clock')tick();});
  globalThis.ClockUI={open,refresh,leave(){clearTimeout(timer);}};
})();
