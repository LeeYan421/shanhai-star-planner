/* 在线反馈按本机随机身份隔离；草稿留在本机，收到服务端确认后才清除。 */
(() => {
  'use strict';
  const $=id=>document.getElementById(id),app=PlannerApp,base='https://wutong.leeyan.site',identityKey='wutong-community-identity-v1',draftKey='wutong-community-drafts-v1';
  const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const statuses={review:'待评估',planned:'计划中',doing:'处理中／开发中',done:'已完成',declined:'暂不采纳／已关闭'};
  let tab='feedback',composingIdea=false,page=0,total=0,minePage=0,currentTicket=null,images=[],sending=false,loadingImages=false,drafts={},viewSequence=0,requestNumber=0,queryTimer;
  const pending=new Map();
  const logButton=document.createElement('button');logButton.type='button';logButton.className='text-button';logButton.dataset.submitDiagnostics='';logButton.textContent='提交日志';const logHeading=document.createElement('div');logHeading.className='section-heading';const formTitle=$('community-form-title');formTitle.replaceWith(logHeading);logHeading.append(formTitle,logButton);
  const recovery=document.createElement('details');recovery.id='community-identity';recovery.className='help-item hidden';
  recovery.innerHTML='<summary>换机恢复反馈记录</summary><p class="hint">恢复码可读取你的私有反馈，请妥善保管。星宿备份不包含此恢复码。</p><button id="community-copy-identity" class="text-button">复制我的恢复码</button><label for="community-recovery-code" class="sr-only">反馈恢复码</label><input id="community-recovery-code" type="password" autocomplete="off" placeholder="粘贴WT1-开头的恢复码"><button id="community-restore-identity" class="text-button">恢复记录</button>';
  $('community-view').append(recovery);
  function identity(){let key=localStorage.getItem(identityKey);if(!/^[a-f0-9]{64}$/.test(key||'')){key=[...crypto.getRandomValues(new Uint8Array(32))].map(n=>n.toString(16).padStart(2,'0')).join('');localStorage.setItem(identityKey,key);}return key;}
  function notice(message){$('community-status').textContent=message;}
  async function api(path,method='GET',body,tokenOverride){
    const token=tokenOverride||identity(),raw=body===undefined?'':JSON.stringify(body);
    if(typeof globalThis.AndroidPlanner?.communityRequest==='function')return new Promise((resolve,reject)=>{
      const id=String(++requestNumber),timer=setTimeout(()=>{pending.delete(id);reject(new Error('连接超时，草稿已保留，可重试'));},30000);
      pending.set(id,{resolve,reject,timer});try{AndroidPlanner.communityRequest(id,method,path,token,raw);}catch{clearTimeout(timer);pending.delete(id);reject(new Error('连接失败，请重试'));}
    });
    const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),25000);
    try{const response=await fetch(base+path,{method,headers:{Authorization:'Bearer '+token,...(raw?{'Content-Type':'application/json'}:{})},body:raw||undefined,signal:controller.signal,cache:'no-store'});const value=await response.json();if(!response.ok)throw new Error(value.error||'请求失败');return value;}catch(e){if(e instanceof TypeError||e.name==='AbortError')throw new Error('连接失败，草稿已保留，可稍后重试');throw e;}finally{clearTimeout(timeout);}
  }
  globalThis.handleCommunityResponse=(id,status,raw)=>{const task=pending.get(id);if(!task)return;pending.delete(id);clearTimeout(task.timer);try{const value=JSON.parse(raw);if(status<200||status>=300)throw new Error(value.error||'连接失败，请重试');task.resolve(value);}catch(e){task.reject(e);}};
  function kind(){return composingIdea?'idea':'feedback';}
  try{const stored=JSON.parse(localStorage.getItem(draftKey)||'{}');if(stored&&typeof stored==='object'&&!Array.isArray(stored))drafts=stored;}catch{notice('已忽略损坏的反馈草稿');}
  function readForm(){return {title:$('community-subject').value,body:$('community-body').value,contact:$('community-contact').value,category:$('community-category').value,images};}
  function saveDraft(){try{const old=drafts[kind()]||{};drafts[kind()]={...old,...readForm()};localStorage.setItem(draftKey,JSON.stringify(drafts));return true;}catch{notice('草稿未能保存，请勿关闭当前页面');return false;}}
  function restoreForm(){const draft=drafts[kind()]||{};for(const [id,key]of [['community-subject','title'],['community-body','body'],['community-contact','contact'],['community-category','category']])$(id).value=typeof draft[key]==='string'?draft[key]:(key==='category'?'other':'');images=Array.isArray(draft.images)?draft.images.filter(v=>typeof v==='string'&&/^data:image\/(jpeg|png|webp);base64,/.test(v)).slice(0,3):[];renderImages();}
  function renderImages(){$('community-attachments').innerHTML=images.map((src,i)=>`<div><img src="${esc(src)}" alt="待提交截图${i+1}"><button type="button" data-remove-image="${i}" aria-label="删除截图${i+1}">删除</button></div>`).join('');}
  function renderTabs(){
    document.querySelectorAll('[data-community-tab]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.communityTab===tab)));
    const form=tab==='feedback'||tab==='ideas'&&composingIdea;
    $('community-compose').classList.toggle('hidden',!form);$('community-board').classList.toggle('hidden',tab!=='ideas'||composingIdea);$('community-mine').classList.toggle('hidden',tab!=='mine');
    recovery.classList.toggle('hidden',tab!=='mine');
    $('community-form-title').textContent=composingIdea?'提出新需求':'提交反馈';$('community-submit').textContent=composingIdea?'提交需求':'提交反馈';
    $('community-privacy').textContent=composingIdea?'需求审核后公开标题与说明；截图和联系方式仅你与开发者可见。':'仅提交你填写的内容和主动选择的截图，不附带设备信息。';
    logButton.classList.toggle('hidden',composingIdea);
    $('community-subject').placeholder=composingIdea?'希望增加什么功能？':'简要描述问题';
  }
  async function switchTab(next,compose=false){if(sending||loadingImages){notice('请等待当前操作完成');return;}if(tab==='feedback'||composingIdea)saveDraft();tab=next;composingIdea=compose;viewSequence++;notice('');renderTabs();if(next==='feedback'||compose)restoreForm();else await load();}
  async function open(){renderTabs();if(tab==='feedback'||composingIdea)restoreForm();else await load();}
  async function load(){
    const seq=++viewSequence;notice('正在载入…');
    try{
      if(tab==='mine'){
        const result=await api('/api/mine?page='+minePage);if(seq!==viewSequence)return;
        $('community-mine').innerHTML=result.items.length?result.items.map(t=>`<article class="community-ticket"><h2>${esc(t.title)}</h2><div class="personal-toolbar"><span class="community-badge">${esc(statuses[t.status]||t.status)}</span><span class="muted">${t.kind==='idea'?'需求':'反馈'} · ${new Date(t.created_at).toLocaleDateString('zh-CN')}</span><button class="text-button" data-open-ticket="${esc(t.id)}">查看回复</button></div></article>`).join(''):'<p class="personal-empty">暂无提交记录。提交后可在这里查看回复和进度。</p>';
        if(result.total>20)$('community-mine').insertAdjacentHTML('beforeend',`<div class="personal-toolbar"><button class="text-button" data-mine-page="${minePage-1}" ${minePage===0?'disabled':''}>上一页</button><span class="muted">${minePage+1} / ${Math.ceil(result.total/20)}</span><button class="text-button" data-mine-page="${minePage+1}" ${(minePage+1)*20>=result.total?'disabled':''}>下一页</button></div>`);
      }else if(tab==='ideas'&&!composingIdea){
        const params=new URLSearchParams({page:String(page),q:$('idea-query').value,sort:$('idea-sort').value,status:$('idea-state').value}),result=await api('/api/ideas?'+params);if(seq!==viewSequence)return;total=result.total;
        $('community-ideas').innerHTML=result.items.length?result.items.map(t=>`<article class="community-ticket"><h2>${esc(t.title)}</h2><p>${esc(t.body)}</p><div class="personal-toolbar"><span class="community-badge">${esc(statuses[t.status]||t.status)}</span><button class="secondary-button community-vote" data-vote="${esc(t.id)}" aria-pressed="${!!t.voted}">${t.voted?'已支持':'支持'} · ${t.votes}</button></div></article>`).join(''):'<p class="personal-empty">没有找到需求，可以提交你的想法。</p>';
        $('idea-page').textContent=(page+1)+' / '+Math.max(1,Math.ceil(total/20));$('idea-prev').disabled=page===0;$('idea-next').disabled=(page+1)*20>=total;
      }
      if(seq===viewSequence)notice('');
    }catch(e){if(seq===viewSequence)notice(e.message+'，可点击刷新');}
  }
  document.addEventListener('click',e=>{const entry=e.target.closest('[data-community]');if(entry){$('about').close();app.route('community',true);switchTab(entry.dataset.community);}});
  document.querySelectorAll('[data-community-tab]').forEach(b=>b.addEventListener('click',()=>switchTab(b.dataset.communityTab)));
  $('idea-new').addEventListener('click',()=>switchTab('ideas',true));$('community-refresh').addEventListener('click',()=>{if(tab==='feedback'||composingIdea)notice('草稿保存在本机，提交后可在“我的记录”查看。');else load();});
  $('community-form').addEventListener('input',e=>{if(e.target.type!=='file')saveDraft();});
  $('community-attachments').addEventListener('click',e=>{const button=e.target.closest('[data-remove-image]');if(!button||sending)return;images.splice(Number(button.dataset.removeImage),1);renderImages();saveDraft();});
  // 仅压缩用户主动选择的截图，不读取相册或游戏目录。
  async function screenshot(file){
    if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>15000000)throw new Error('请选择15MB以内的PNG、JPG或WebP图片');
    const image=await createImageBitmap(file);try{if(image.width*image.height>40000000)throw new Error('图片尺寸过大');const canvas=document.createElement('canvas'),scale=Math.min(1,1280/Math.max(image.width,image.height));canvas.width=Math.max(1,Math.round(image.width*scale));canvas.height=Math.max(1,Math.round(image.height*scale));const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(image,0,0,canvas.width,canvas.height);for(const quality of [.8,.6,.4]){const raw=canvas.toDataURL('image/jpeg',quality);if(raw.length<=327000)return raw;}throw new Error('图片压缩后仍过大，请裁剪后再选');}finally{image.close();}
  }
  $('community-images').addEventListener('change',async()=>{
    const files=[...$('community-images').files];$('community-images').value='';if(sending||loadingImages)return;if(images.length+files.length>3){notice('最多上传3张截图');return;}loadingImages=true;$('community-submit').disabled=true;notice('正在处理截图…');
    try{const added=await Promise.all(files.map(screenshot));images.push(...added);renderImages();saveDraft();notice('');}catch(e){notice(e.message);}finally{loadingImages=false;$('community-submit').disabled=false;}
  });
  function lockForm(locked){for(const el of $('community-form').elements)el.disabled=locked;document.querySelectorAll('[data-remove-image]').forEach(el=>el.disabled=locked);}
  $('community-form').addEventListener('submit',async e=>{
    e.preventDefault();if(sending||loadingImages||!$('community-form').reportValidity())return;if(!saveDraft())return;
    const currentKind=kind(),form=readForm(),signature=JSON.stringify(form),old=drafts[currentKind];
    const id=old.signature===signature&&old.id?old.id:crypto.randomUUID();drafts[currentKind]={...old,id,signature};try{localStorage.setItem(draftKey,JSON.stringify(drafts));}catch{notice('草稿未能保存，请释放存储空间后重试');return;}
    sending=true;lockForm(true);notice('正在提交…');
    try{
      await api('/api/tickets','POST',{id,kind:currentKind,...form});delete drafts[currentKind];try{localStorage.setItem(draftKey,JSON.stringify(drafts));}catch{}
      images=[];$('community-form').reset();renderImages();sending=false;lockForm(false);await switchTab('mine');notice('已提交，可在这里查看回复与处理进度');
    }catch(error){notice(error.message);}finally{sending=false;lockForm(false);}
  });
  for(const id of ['idea-sort','idea-state'])$(id).addEventListener('change',()=>{page=0;load();});
  $('idea-query').addEventListener('input',()=>{clearTimeout(queryTimer);queryTimer=setTimeout(()=>{page=0;load();},350);});
  $('idea-prev').addEventListener('click',()=>{if(page>0){page--;load();}});$('idea-next').addEventListener('click',()=>{if((page+1)*20<total){page++;load();}});
  $('community-ideas').addEventListener('click',async e=>{const button=e.target.closest('[data-vote]');if(!button||button.disabled)return;button.disabled=true;const method=button.getAttribute('aria-pressed')==='true'?'DELETE':'PUT';try{const result=await api('/api/ideas/'+button.dataset.vote+'/vote',method);button.setAttribute('aria-pressed',String(!!result.voted));button.textContent=(result.voted?'已支持':'支持')+' · '+result.votes;}catch(error){notice(error.message);}finally{button.disabled=false;}});
  async function openTicket(id){
    $('community-detail-status').textContent='正在载入…';$('community-detail-title').textContent='反馈详情';$('community-detail-body').replaceChildren();$('community-reply-form').classList.add('hidden');currentTicket=null;if(!$('community-detail').open)$('community-detail').showModal();
    try{const t=await api('/api/tickets/'+id);if(!$('community-detail').open)return;currentTicket=t;$('community-detail-title').textContent=t.title;$('community-detail-body').innerHTML=`<span class="community-badge">${esc(statuses[t.status]||t.status)}</span><p>${esc(t.kind==='feedback'&&t.body.startsWith(DiagnosticCore.marker)?'应用日志已提交，开发者可查看诊断记录。':t.body)}</p>${t.images.map(src=>`<img src="${esc(src)}" alt="已提交截图">`).join('')}${t.messages.map(m=>`<div class="reply-message"><strong>${m.role==='admin'?'开发者':'我的补充'} · ${new Date(m.created_at).toLocaleDateString('zh-CN')}</strong><br>${esc(m.body)}</div>`).join('')||'<p class="hint">暂未回复。</p>'}`;$('community-detail-status').textContent='';$('community-reply-form').classList.remove('hidden');$('community-reply').value='';}catch(e){$('community-detail-status').textContent=e.message;}
  }
  $('community-mine').addEventListener('click',e=>{const button=e.target.closest('[data-open-ticket]');if(button)openTicket(button.dataset.openTicket);const paging=e.target.closest('[data-mine-page]');if(paging){minePage=Number(paging.dataset.minePage);load();}});
  $('community-copy-identity').addEventListener('click',async()=>{try{const code='WT1-'+identity();if(typeof globalThis.AndroidPlanner?.copyText==='function'){if(!AndroidPlanner.copyText(code))throw new Error();}else await navigator.clipboard.writeText(code);notice('恢复码已复制，请勿公开分享');}catch{notice('复制失败，请重试');}});
  $('community-restore-identity').addEventListener('click',async()=>{const code=$('community-recovery-code').value.trim();if(!/^WT1-[a-f0-9]{64}$/.test(code)){notice('恢复码格式不正确');return;}const button=$('community-restore-identity');button.disabled=true;try{const result=await api('/api/mine','GET',undefined,code.slice(4));if(!result.items.length)throw new Error('这个恢复码没有反馈记录，原身份保留');localStorage.setItem(identityKey,code.slice(4));minePage=0;await load();$('community-recovery-code').value='';notice('反馈身份已恢复');}catch(e){notice(e.message);}finally{button.disabled=false;}});
  let replyId='',replySignature='';
  $('community-reply-form').addEventListener('submit',async e=>{e.preventDefault();if(!currentTicket||!$('community-reply').value.trim())return;const id=currentTicket.id,content=$('community-reply').value,signature=id+content;if(signature!==replySignature){replySignature=signature;replyId=crypto.randomUUID();}$('community-reply-send').disabled=true;try{await api('/api/tickets/'+id+'/messages','POST',{id:replyId,body:content});await openTicket(id);}catch(error){$('community-detail-status').textContent=error.message;}finally{$('community-reply-send').disabled=false;}});
  globalThis.CommunityUI={open,async submitDiagnostic(id,body){body=DiagnosticCore.sanitizeReport(body);return api('/api/tickets','POST',{id,kind:'feedback',title:'应用异常日志',body,category:'bug',contact:'',images:[]});},back(){if($('community-detail').open){$('community-detail').close();return true;}if(document.body.dataset.page==='community'&&composingIdea){switchTab('ideas');return true;}return false;}};
})();
