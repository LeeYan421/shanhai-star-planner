/* 主方案与方案对比使用同一求解入口，保持目标、前置和取整口径一致。 */
globalThis.createPlannerWorkerSource=function(vendorSource=''){
  return vendorSource+'; const createElementRules = '+createElementRules.toString()+'; const createElementGoalEngine = '+createElementGoalEngine.toString()+'; const createPlannerEngine = '+createPlannerEngine.toString()+'; const createAutoPowerEngine = '+createAutoPowerEngine.toString()+'; const createCritTargetEngine = '+createCritTargetEngine.toString()+'; const loadOfflineOptimizer = '+loadOfflineOptimizer.toString()+'; const createStrategyEngine = '+createStrategyEngine.toString()+'; onmessage = async e => { try { let optimizer; if(["power","crit-target"].includes(e.data.request.strategy)||e.data.request.elementRules?.length||e.data.request.elementStars?.length){ try { optimizer=await loadOfflineOptimizer(Module,e.data.wasmBytes); } catch { throw new Error("本机联合计算组件未能加载，请更新Android系统WebView后重试"); } } const engine=createStrategyEngine(e.data.data,createPlannerEngine,optimizer); const result=engine.solve(e.data.request,value=>postMessage({progress:value})); postMessage({result}); } catch(error) { postMessage({error:error.message,errorName:error.name,errorStack:typeof error.stack==="string"?error.stack.slice(0,4000):""}); } };';
};
globalThis.solveOfflinePlan=function(data,config,onProgress){
  let worker,cancelled=false,rejectTask;
  const promise=new Promise(async(resolve,reject)=>{
    rejectTask=reject;
    try{
      const request={budget:Number(config.budget),capacity:Number(config.capacity),strategy:config.strategy,talentIds:config.selected,elementKeys:config.elements,elementRules:config.elementRules,elementStars:config.elementStars};
      if(config.strategy==='crit-target'){if(!/^\d+$/.test(String(config.critTarget)))throw new Error('请先填写暴击目标');request.critTarget=Number(config.critTarget);}
      if(!/^\d+$/.test(String(config.budget)))throw new Error('请先填写方案点数');
      createPlannerEngine(data).prepare(request);
      let vendor='',wasmBytes;
      if(['power','crit-target'].includes(config.strategy)||config.elementRules?.length||config.elementStars?.length){
        const r=await Promise.all(['highs.js','highs.wasm'].map(file=>fetch('vendor/'+file)));if(r.some(v=>!v.ok))throw new Error('本机计算组件未能加载');
        [vendor,wasmBytes]=await Promise.all([r[0].text(),r[1].arrayBuffer()]);
      }
      if(cancelled)return;
      const url=URL.createObjectURL(new Blob([createPlannerWorkerSource(vendor)],{type:'text/javascript'}));
      try{worker=new Worker(url);}finally{URL.revokeObjectURL(url);}
      worker.onmessage=e=>{if(cancelled)return;if(e.data.progress!==undefined){onProgress?.(e.data.progress);return;}worker.terminate();if(e.data.error){globalThis.Diagnostics?.record('planner',{name:e.data.errorName,message:e.data.error,stack:e.data.errorStack});reject(new Error(e.data.error));}else resolve(e.data.result);};
      worker.onerror=e=>{globalThis.Diagnostics?.record('planner',e.error||{message:e.message,stack:(e.filename||'')+':'+e.lineno+':'+e.colno});worker.terminate();reject(new Error('计算未完成，请重试'));};
      worker.postMessage({data,request,wasmBytes},wasmBytes?[wasmBytes]:[]);
    }catch(error){if(!cancelled)reject(error);}
  });
  return {promise,cancel(){cancelled=true;worker?.terminate();rejectTask?.(new Error('已取消对比'));}};
};
