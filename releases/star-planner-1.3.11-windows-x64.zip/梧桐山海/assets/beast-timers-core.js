/* 倒计时使用绝对到期时间，页面切换和后台停留不累计计时误差。 */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.BeastTimersCore=api;})(globalThis,()=>{
  'use strict';
  const MAX_DURATION=30*24*3600000;
  const DAY=24*3600000;
  function startTime(value,now=Date.now()){if(!Number.isSafeInteger(value)||value<=0||value>now||value<now-DAY)throw Error('请选择过去24小时内的击杀／采集时间');return value;}
  function details(raw){
    const note=raw.note??'',images=raw.images??[];
    if(typeof note!=='string'||[...note].length>500)throw Error('备注最多500字');
    if(!Array.isArray(images)||images.length>3||images.some(id=>typeof id!=='string'||!/^[a-f0-9-]{36}$/.test(id))||new Set(images).size!==images.length)throw Error('最多添加3张本地图片');
    return {note,images:[...images]};
  }
  // 豆数按游戏大档位区分，三百年、八千年等具体年限仍保留原文。
  function yearMark(beast){
    if(beast.kind||beast.legacy)return null;
    if(beast.year==='超级神兽')return {kind:'mythic',beans:0};
    const year=beast.nativeYear;if(!Number.isInteger(year)||year<50)return null;
    return year<100?{kind:'young',beans:0}:{kind:'beads',beans:year<1000?1:year<10000?2:year<30000?3:year<50000?4:5};
  }
  // 起点仅在新建或重新计时时限制24小时，已保存记录不随时间推移失效。
  function start(values,byId,now=Date.now()){
    const startedAt=startTime(values.startedAt??now,now),row={...values,...details(values),startedAt,dueAt:startedAt+values.durationMs,status:'running'};
    if(values.latestDurationMs)row.latestDueAt=startedAt+values.latestDurationMs;
    return validate(row,byId);
  }
  const legacyCustomIcons=['icons/resource-platform.png','icons/resource-portal.png','icons/resource-net.png','icons/resource-meteor.png','icons/custom-mineral.png','icons/custom-fruit.png','icons/custom-herb.png','icons/custom-tree.png','icons/custom-fish.png','icons/custom-gold.png','icons/custom-totem.png','icons/custom-spirit.png'];
  function duration(hours,minutes){const h=Number(hours),m=Number(minutes);if(!Number.isInteger(h)||!Number.isInteger(m)||h<0||m<0||m>59||h*3600000+m*60000<60000||h*3600000+m*60000>MAX_DURATION)throw Error('时长需为1分钟至30天');return h*3600000+m*60000;}
  function remaining(timer,now=Date.now()){return Math.max(0,(['window','waiting_end'].includes(timer.status)?timer.latestDueAt:timer.dueAt)-now);}
  function advance(timer,now=Date.now()){
    if(timer.status==='running'&&now>=timer.dueAt)return {...timer,status:timer.latestDueAt>timer.dueAt&&now<timer.latestDueAt?'window':'due'};
    if(['window','waiting_end'].includes(timer.status)&&now>=timer.latestDueAt)return {...timer,status:'due'};
    return timer;
  }
  function progress(timer,now=Date.now()){const length=['window','waiting_end'].includes(timer.status)?timer.latestDueAt-timer.dueAt:timer.durationMs;return Math.max(0,Math.min(1,1-remaining(timer,now)/length));}
  function display(ms){const seconds=Math.ceil(Math.max(0,ms)/1000),h=Math.floor(seconds/3600),m=Math.floor(seconds%3600/60),s=seconds%60;return [h,m,s].map(value=>String(value).padStart(2,'0')).join(':');}
  function filter(data,year,query){const terms=String(query||'').trim().split(/\s+/).filter(Boolean);return [...data.beasts,...(data.resources||[]),...(data.customResources||[])].filter(beast=>(!year||(beast.filterYear??beast.year)===year||beast.year===year)&&terms.every(term=>(beast.year+' '+beast.name+' '+(beast.nativeName||'')+' '+(beast.searchAliases||[]).join(' ')).includes(term)));}
  function validate(timer,byId){if(!timer||!/^[a-zA-Z0-9-]{1,64}$/.test(timer.id)||!byId.has(timer.beastId)||!Number.isInteger(timer.durationMs)||timer.durationMs<1000||timer.durationMs>MAX_DURATION||!Number.isSafeInteger(timer.dueAt)||timer.dueAt<=0||!['running','window','waiting_end','due','done'].includes(timer.status))throw Error('计时记录无效');if(timer.latestDueAt&&(!Number.isSafeInteger(timer.latestDueAt)||timer.latestDueAt<=timer.dueAt||!Number.isInteger(timer.latestDurationMs)||timer.latestDurationMs<=timer.durationMs||timer.latestDurationMs>MAX_DURATION))throw Error('区间计时无效');if(['window','waiting_end'].includes(timer.status)&&!timer.latestDueAt)throw Error('区间计时无效');if(timer.startedAt!==undefined&&(!Number.isSafeInteger(timer.startedAt)||timer.startedAt<=0||timer.dueAt!==timer.startedAt+timer.durationMs||timer.latestDueAt&&timer.latestDueAt!==timer.startedAt+timer.latestDurationMs))throw Error('计时起点无效');details(timer);return {...timer};}
  // 自定义资源使用独立编号段；图标只允许本机内置项，删除后编号不回收。
  function customResource(raw,icons){
    const name=typeof raw?.name==='string'?raw.name.trim():'';
    if(!Number.isInteger(raw?.id)||raw.id<=20000000||raw.id>2147483647||!name||[...name].length>24||/[\x00-\x1f\x7f\u2028\u2029]/.test(name)||!icons.includes(raw.icon)||!Number.isInteger(raw.defaultMinutes)||raw.defaultMinutes<1||raw.defaultMinutes>43200)throw Error('请填写1～24字名称、内置图标和有效时长');
    return {id:raw.id,kind:'custom',name,year:'自定义',filterYear:'custom',icon:raw.icon,defaultMinutes:raw.defaultMinutes};
  }
  function customState(raw,icons){
    if(!raw||!Number.isInteger(raw.nextId)||raw.nextId<20000000||raw.nextId>2147483647||!Array.isArray(raw.resources)||raw.resources.length>50)throw Error('自定义资源数据无效');
    // 旧验收包曾复用固定资源图标，只迁移图标，编号及计时引用保持不变。
    const resources=raw.resources.map(row=>customResource(legacyCustomIcons.includes(row?.icon)?{...row,icon:'icons/custom-island.png'}:row,icons));if(new Set(resources.map(row=>row.id)).size!==resources.length||resources.some(row=>row.id>raw.nextId))throw Error('自定义资源数据无效');return {nextId:raw.nextId,resources};
  }
  function saveCustom(raw,draft,icons){
    const state=customState(raw,icons),id=draft.id||state.nextId+1;if(draft.id&&!state.resources.some(row=>row.id===id))throw Error('自定义资源不存在');
    const row=customResource({...draft,id},icons),resources=state.resources.filter(item=>item.id!==id);resources.push(row);if(resources.length>50)throw Error('最多保存50项自定义资源');return {nextId:Math.max(state.nextId,id),resources};
  }
  function deleteCustom(raw,id,icons){const state=customState(raw,icons);if(!state.resources.some(row=>row.id===id))throw Error('自定义资源不存在');return {...state,resources:state.resources.filter(row=>row.id!==id)};}
  return {MAX_DURATION,DAY,startTime,details,yearMark,start,duration,remaining,advance,progress,display,filter,validate,customResource,customState,saveCustom,deleteCustom};
});
