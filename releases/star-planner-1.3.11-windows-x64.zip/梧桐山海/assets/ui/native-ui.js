/* 原生更新任务只传递文字、进度和操作编号，所有应用内弹窗由MDUI渲染。 */
(() => {
  'use strict';
  const dialogs=new Map();
  function action(id,value){globalThis.AndroidPlanner?.nativeUiAction?.(id,value);}
  globalThis.NativeUI={
    open(id,options){
      if(typeof id!=='string'||dialogs.has(id))return;
      const dialog=document.createElement('mdui-dialog');dialog.dataset.nativeDialog=id;dialog.headline=String(options.title||'');
      const message=document.createElement('p');message.className='native-message';message.textContent=String(options.message||'');dialog.append(message);
      let progress;if(options.progress){progress=document.createElement('mdui-linear-progress');progress.max=100;if(Number.isFinite(options.value))progress.value=options.value;dialog.append(progress);}
      const state={dialog,message,progress,programmatic:false,cancelable:options.cancelable!==false};dialogs.set(id,state);
      dialog.addEventListener('cancel',event=>{if(!state.cancelable)event.preventDefault();});
      for(const item of (options.actions||[]).slice(0,3)){const button=document.createElement('mdui-button');button.slot='action';button.variant=item.id==='positive'?'filled':'text';button.textContent=String(item.label||'');button.addEventListener('click',()=>{state.programmatic=true;dialog.open=false;action(id,item.id);});dialog.append(button);}
      dialog.addEventListener('closed',()=>{dialogs.delete(id);dialog.remove();if(!state.programmatic)action(id,'cancel');});
      document.body.append(dialog);dialog.open=true;
    },
    update(id,value,message){const state=dialogs.get(id);if(!state)return;if(Number.isFinite(value)&&state.progress)state.progress.value=Math.max(0,Math.min(100,value));state.message.textContent=String(message||'');},
    close(id){const state=dialogs.get(id);if(state){state.programmatic=true;Promise.resolve(state.dialog.updateComplete).then(()=>{state.dialog.open=false;});}},
    back(){const state=[...dialogs.values()].reverse().find(state=>state.dialog.open);if(!state)return false;if(state.cancelable)state.dialog.open=false;return true;}
  };
})();
