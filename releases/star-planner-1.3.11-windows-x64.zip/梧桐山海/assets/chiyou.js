/* 四神兵图鉴按需读取本机资料，查询与搭配不修改星宿方案。 */
(() => {
  'use strict';
  const $=id=>document.getElementById(id),esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const size=24,state={index:null,atlas:null,loading:false,tab:'atlas',lookup:'souls',page:0,goal:'combat',buildWeapon:1,buildQuality:5,history:[]};let queryTimer;
  const quality=q=>`<span class="mutation-quality" data-quality="${q}">${esc(state.atlas.data.qualities[q])}</span>`;
  const slotName=id=>state.atlas.data.slotTypes.find(t=>t.id===id).name;
  const soulRow=s=>`<mdui-card class="chiyou-row" data-chiyou-soul="${s.id}" clickable role="button" tabindex="0" variant="filled"><span><strong>${esc(s.name)}</strong><small>${esc(s.description).replace(/\n/g,' · ')}</small></span><span class="chiyou-row-side">${s.pets.length}种宠物 <b>›</b></span></mdui-card>`;
  const petRow=p=>`<mdui-card class="chiyou-row" data-chiyou-pet="${esc(p.name)}" clickable role="button" tabindex="0" variant="filled"><span><strong>${esc(p.name)}</strong><small>${p.souls.map(s=>esc(s.name)).join('、')}</small></span><span class="chiyou-row-side">${p.souls.length}种兵魂 <b>›</b></span></mdui-card>`;
  const summary=v=>v.bestWords.map(id=>state.atlas.wordText(id)).join('；');
  const familyRow=f=>`<mdui-card class="chiyou-row gw-catalog-row" data-gw-family="${f.id}" data-gw-variant="${f.variants[0].id}" clickable role="button" tabindex="0" variant="filled"><span><strong>${esc(f.variants[0].name)}</strong><small>${f.weapons.map(i=>esc(state.atlas.weapons.get(i).name)).join('／')} · ${f.slots.map(slotName).join('／')}</small><p>${esc(summary(f.variants.slice().sort((a,b)=>b.maxPower-a.maxPower)[0]))}</p><span class="gw-quality-list">${[...new Set(f.variants.map(v=>v.quality))].sort().map(quality).join('')}</span></span><span class="chiyou-row-side">›</span></mdui-card>`;
  const numberRow=v=>`<mdui-card class="chiyou-row gw-catalog-row" data-gw-family="${v.group}" data-gw-variant="${v.id}" clickable role="button" tabindex="0" variant="filled"><span><strong>${esc(v.name)} ${quality(v.quality)}</strong><small>${v.weapons.map(i=>esc(state.atlas.weapons.get(i).name)).join('／')} · ${v.slots.map(slotName).join('／')}</small><p>${esc(summary(v))}</p></span><span class="gw-score">${v.maxPower}<small>词条战力参考 ›</small></span></mdui-card>`;
  function render(){
    if(!state.atlas)return;const build=state.tab==='builds',lookup=state.tab==='lookup';
    $('chiyou-results').classList.toggle('chiyou-grid',!build);
    $('chiyou-tabs').value=state.tab;$('gw-filters').classList.toggle('hidden',build||lookup);$('gw-build-controls').classList.toggle('hidden',!build);$('gw-lookup-tabs').classList.toggle('hidden',!lookup);$('chiyou-search').classList.toggle('hidden',build);$('chiyou-clear').classList.toggle('hidden',build);$('chiyou-help').classList.toggle('hidden',build);
    $('gw-lookup-tabs').value=state.lookup;document.querySelectorAll('[data-chiyou-tab]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.chiyouTab===state.tab||b.dataset.chiyouTab===state.lookup)));
    if(build){renderBuild();$('chiyou-pager').classList.add('hidden');return;}
    const query=$('chiyou-query').value;
    let rows,rowHtml;
    if(lookup){rows=state.lookup==='souls'?state.index.searchSouls(query):state.index.searchPets(query);rowHtml=state.lookup==='souls'?soulRow:petRow;$('chiyou-query').placeholder=state.lookup==='souls'?'搜索可凝炼兵魂、效果或宠物':'搜索宠物或可凝炼兵魂';}
    else{const families=state.atlas.query({weapon:$('gw-weapon').value,slot:$('gw-slot').value,quality:$('gw-quality').value,query});rows=state.tab==='numbers'?families.flatMap(f=>f.variants):families;rowHtml=state.tab==='numbers'?numberRow:familyRow;$('chiyou-query').placeholder='搜索兵魂名称、属性或触发条件';}
    $('chiyou-query').label=lookup?'搜索可凝炼兵魂或宠物':'搜索兵魂、属性或触发条件';
    const pages=Math.max(1,Math.ceil(rows.length/size));state.page=Math.min(state.page,pages-1);$('chiyou-total').textContent=rows.length+(lookup?(state.lookup==='souls'?'种可凝炼兵魂':'种宠物'):state.tab==='numbers'?'条兵魂品质记录':'组兵魂');
    $('chiyou-results').innerHTML=rows.slice(state.page*size,(state.page+1)*size).map(rowHtml).join('')||'<p class="chiyou-empty">没有匹配结果，试试其他名称或筛选条件。</p>';
    $('chiyou-pager').classList.toggle('hidden',pages<=1);$('chiyou-page').textContent=state.page+1+' / '+pages;$('chiyou-prev').disabled=state.page===0;$('chiyou-next').disabled=state.page===pages-1;
  }
  function renderBuild(){
    $('gw-goal').value=state.goal;document.querySelectorAll('[data-gw-goal]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.gwGoal===state.goal)));
    let result;try{result=state.atlas.recommend({weapon:$('gw-build-weapon').value,grade:$('gw-grade').value,quality:$('gw-build-quality').value,goal:state.goal});}catch(error){$('chiyou-total').textContent='';$('chiyou-results').innerHTML=`<p class="chiyou-empty">${esc(error.message)}</p>`;return;}
    $('chiyou-total').textContent=`${result.filled} / ${result.rows.length}个已解锁槽位 · ${result.locked}个未解锁`;
    $('chiyou-results').innerHTML=`<mdui-card class="gw-build-summary" variant="filled"><strong>${esc(result.weapon.name)} · ${result.goal==='power'?'虚战搭配':'实战搭配'}</strong>${result.goal==='power'?`<div class="gw-total-score">${result.power.toLocaleString('zh-CN')}<small>最高词条战力参考</small></div>`:''}<p>${esc(result.note)}</p><small>属性词条保留紫色及以上最高值，蓝色伤害加成也保留；其他效果保留；参考值不计入已省略的低品质属性。实战效果取决于账号、敌人和触发条件。</small></mdui-card>${state.atlas.data.slotTypes.map(type=>{const rows=result.rows.filter(r=>r.slot.type===type.id);return rows.length?`<h3 class="gw-slot-heading">${esc(type.name)} · ${rows.length}槽</h3>${rows.map(r=>r.variant?`<mdui-card class="chiyou-row gw-catalog-row" data-gw-family="${r.family.id}" data-gw-variant="${r.variant.id}" clickable role="button" tabindex="0" variant="filled"><span><strong>${esc(r.variant.name)} ${quality(r.variant.quality)}</strong><small>${r.slot.grade}级解锁${r.fallback?' · 可用兵魂补位':''}</small><p>${esc(summary(r.variant))}</p></span><span class="chiyou-row-side">${result.goal==='power'?r.variant.maxPower+' ':''}›</span></mdui-card>`:`<p class="chiyou-empty">${r.slot.grade}级槽：所选品质范围没有可用兵魂。</p>`).join('')}`:'';}).join('')}`;
  }
  async function open(){
    if(state.atlas){render();return;}if(state.loading)return;state.loading=true;$('chiyou-message').textContent='正在读取兵魂资料…';$('chiyou-retry').classList.add('hidden');
    try{const data=await Promise.all(['chiyou-data.json','god-weapon-data.json'].map(async path=>{const response=await fetch(path);if(!response.ok)throw new Error('兵魂资料未能读取');return response.json();}));const index=createChiyouIndex(data[0]),atlas=createGodWeaponIndex(data[1]);state.index=index;state.atlas=atlas;$('chiyou-content').classList.remove('hidden');$('chiyou-message').textContent='';render();}
    catch(error){globalThis.Diagnostics?.record('chiyou',error,'DATA_LOAD');$('chiyou-message').textContent='资料载入失败，请重试';$('chiyou-retry').classList.remove('hidden');}finally{state.loading=false;}
  }
  function renderFamily(item){
    const family=state.atlas.families.get(item.id),variant=family.variants.find(v=>v.id===item.variant)||family.variants[0];item.variant=variant.id;$('chiyou-detail-title').textContent=variant.name;
    const source=[...state.index.souls.values()].find(s=>s.name===variant.name);
    const chooser=`<p class="hint">${family.weapons.map(i=>esc(state.atlas.weapons.get(i).name)).join('／')} · ${family.slots.map(slotName).join('／')} · 神兵${variant.grade[0]}～${variant.grade[1]}级</p><mdui-select id="gw-detail-variant" label="兵魂品质" value="${variant.id}" variant="filled">${family.variants.map(v=>`<mdui-menu-item value="${v.id}">${esc(state.atlas.data.qualities[v.quality])} · ${esc(v.name)}</mdui-menu-item>`).join('')}</mdui-select>`;
    const content=`<p class="chiyou-description">${esc(variant.description)}</p><p class="gw-detail-score">词条战力参考 <strong>${variant.maxPower}</strong> · ${variant.rolls.reduce((n,r)=>n+r.count,0)}条效果${variant.omittedLowQualityAttributes?' · 低品质属性未列入':''}</p>${variant.rolls.map(roll=>roll.buckets.map((bucket,i)=>`<section class="gw-word-section"><h3>词条${i+1} · 候选效果</h3>${bucket.map(id=>{const w=state.atlas.words.get(id);return `<div class="gw-word"><div>${quality(w.quality)}<span class="muted">战力参考 ${state.atlas.wordPower(id)}</span></div><p>${esc(state.atlas.wordText(id))}</p></div>`;}).join('')}</section>`).join('')).join('')}<p class="hint">兵魂品质与属性词条品质分别查看。属性只列紫、橙、红各自最高值，蓝色伤害加成也保留最高值；其他效果保留。每个词条位置从对应候选中取一项；参考值不代表人物面板或实际伤害。</p>${source?`<mdui-button data-chiyou-soul="${source.id}" variant="tonal">查看凝炼核心宠物</mdui-button>`:''}`;
    const selector=$('gw-detail-variant');
    if(selector&&selector.dataset.family===String(family.id))$('gw-detail-content').innerHTML=content;
    else{$('chiyou-detail-body').innerHTML=chooser+'<div id="gw-detail-content">'+content+'</div>';$('gw-detail-variant').dataset.family=String(family.id);}
  }
  function renderDetail(){
    const item=state.history.at(-1);if(!item)return;$('chiyou-detail-back').classList.toggle('hidden',state.history.length<2);
    if(item.kind==='family'){renderFamily(item);return;}
    if(item.kind==='soul'){
      const soul=state.index.souls.get(item.id),family=[...state.atlas.families.values()].find(f=>f.names.includes(soul.name));$('chiyou-detail-title').textContent=soul.name;
      $('chiyou-detail-body').innerHTML=`<p class="chiyou-description">${esc(soul.description)}</p><div class="chiyou-qualities">${state.index.qualities.map((q,i)=>`<span class="mutation-quality" data-quality="${i}">${esc(q)}</span>`).join('')}</div>${family?`<mdui-button data-gw-family="${family.id}" variant="tonal">查看品质数值</mdui-button>`:''}<div class="subheading"><h3>可作核心的宠物</h3><span class="muted">${soul.pets.length}种</span></div><label class="sr-only" for="chiyou-source-query">筛选核心宠物</label><mdui-text-field id="chiyou-source-query" class="chiyou-source-query" type="search" placeholder="搜索这些宠物" value="${esc(item.query||'')}" variant="filled"></mdui-text-field><div id="chiyou-source-results"></div><mdui-button id="chiyou-source-more" class="text-button hidden" variant="text">加载更多</mdui-button><p class="hint">同名宠物只列一次。支援宠物不会被当作核心来源，开始凝炼前请通过宠物魂力页确认结果。</p>`;renderSources();
    }else{const pet=state.index.pets.get(item.name);$('chiyou-detail-title').textContent=pet.name;$('chiyou-detail-body').innerHTML=`<p class="hint">对应${pet.souls.length}种兵魂${pet.souls.length>1?'，同名记录已合并，请以宠物魂力页核对':''}。</p>${pet.souls.map(soulRow).join('')}`;}
  }
  function renderSources(){const item=state.history.at(-1),rows=state.index.sources(item.id,item.query),limit=(item.page+1)*size;$('chiyou-source-results').innerHTML=rows.slice(0,limit).map(petRow).join('')||'<p class="chiyou-empty">没有匹配的核心宠物。</p>';$('chiyou-source-more').classList.toggle('hidden',rows.length<=limit);}
  function show(item){state.history.push({...item,query:'',page:0});renderDetail();if(!$('chiyou-detail').open)$('chiyou-detail').showModal();$('chiyou-detail').scrollTop=0;}
  function close(){state.history=[];$('chiyou-detail').close();}
  function back(){if(!$('chiyou-detail').open)return false;if(state.history.length>1){state.history.pop();renderDetail();}else close();return true;}
  $('chiyou-retry').addEventListener('click',open);$('chiyou-query').addEventListener('input',()=>{state.page=0;clearTimeout(queryTimer);queryTimer=setTimeout(render,180);});
  $('chiyou-clear').addEventListener('click',()=>{clearTimeout(queryTimer);$('chiyou-query').value='';state.page=0;render();});
  document.querySelectorAll('#chiyou-tabs [data-chiyou-tab]').forEach(b=>b.addEventListener('click',()=>{clearTimeout(queryTimer);state.tab=b.dataset.chiyouTab;state.page=0;render();}));
  // 分段选择在组件完成切换后同步，隐藏时也保留各组的独立选中状态。
  $('gw-lookup-tabs').addEventListener('change',event=>{if(event.target!==$('gw-lookup-tabs'))return;const value=event.target.value;if(!['souls','pets'].includes(value)){const group=event.target;Promise.resolve(group.updateComplete).then(()=>{if(!group.value)group.value=state.lookup;});return;}if(value===state.lookup)return;clearTimeout(queryTimer);state.lookup=value;state.page=0;if(state.tab==='lookup')render();});
  for(const id of ['gw-weapon','gw-slot','gw-quality','gw-build-weapon','gw-build-quality'])$(id).addEventListener('change',event=>{if(event.target!==$(id))return;const key=id==='gw-build-weapon'?'buildWeapon':id==='gw-build-quality'?'buildQuality':null;if(key){if(event.target.value===''){event.target.value=String(state[key]);return;}state[key]=Number(event.target.value);}state.page=0;render();});
  $('gw-grade').addEventListener('input',()=>{if(state.atlas)renderBuild();});
  $('gw-goal').addEventListener('change',event=>{if(event.target!==$('gw-goal'))return;const value=event.target.value;if(!['combat','power'].includes(value)){const group=event.target;Promise.resolve(group.updateComplete).then(()=>{if(!group.value)group.value=state.goal;});return;}if(value===state.goal)return;state.goal=value;if(state.tab==='builds')render();});
  $('chiyou-prev').addEventListener('click',()=>{state.page--;render();$('chiyou-results').scrollIntoView({block:'start'});});$('chiyou-next').addEventListener('click',()=>{state.page++;render();$('chiyou-results').scrollIntoView({block:'start'});});
  document.addEventListener('click',event=>{if(!state.atlas)return;const family=event.target.closest('[data-gw-family]'),soul=event.target.closest('[data-chiyou-soul]'),pet=event.target.closest('[data-chiyou-pet]');if(family)show({kind:'family',id:Number(family.dataset.gwFamily),variant:Number(family.dataset.gwVariant)});else if(soul)show({kind:'soul',id:Number(soul.dataset.chiyouSoul)});else if(pet)show({kind:'pet',name:pet.dataset.chiyouPet});});
  document.addEventListener('keydown',event=>{if(!['Enter',' '].includes(event.key)||!event.target.matches('[data-gw-family],[data-chiyou-soul],[data-chiyou-pet]'))return;event.preventDefault();event.target.click();});
  $('chiyou-detail-close').addEventListener('click',close);$('chiyou-detail-back').addEventListener('click',back);$('chiyou-detail').addEventListener('cancel',event=>{if(state.history.length>1){event.preventDefault();back();}else close();return true;});
  $('chiyou-detail-body').addEventListener('input',event=>{if(event.target.id!=='chiyou-source-query')return;const item=state.history.at(-1);item.query=event.target.value;item.page=0;renderSources();});
  $('chiyou-detail-body').addEventListener('change',event=>{if(event.target.id!=='gw-detail-variant')return;const item=state.history.at(-1),variant=Number(event.target.value);if(item?.kind!=='family'||item.variant===variant)return;if(!state.atlas.families.get(item.id).variants.some(v=>v.id===variant)){event.target.value=String(item.variant);return;}item.variant=variant;renderDetail();});
  $('chiyou-detail-body').addEventListener('click',event=>{if(event.target.closest('#chiyou-source-more')){state.history.at(-1).page++;renderSources();}});
  globalThis.ChiyouTool={open,back,leave(){clearTimeout(queryTimer);if($('chiyou-detail').open)close();}};
})();
