/* 图片独立保存在本机IndexedDB，计时桥接只传随机编号，不传图片或文件路径。 */
(()=>{
  'use strict';
  let database;
  function open(){
    if(!database)database=new Promise((resolve,reject)=>{
      const request=indexedDB.open('wutong-beast-images-v1',1);
      request.onupgradeneeded=()=>request.result.createObjectStore('images',{keyPath:'id'});
      request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(Error('本机图片存储不可用'));
    }).catch(error=>{database=undefined;throw error;});
    return database;
  }
  async function read(ids){
    if(!ids.length)return [];
    const db=await open();return Promise.all(ids.map(id=>new Promise((resolve,reject)=>{const request=db.transaction('images').objectStore('images').get(id);request.onsuccess=()=>resolve(request.result||{id,missing:true});request.onerror=()=>reject(Error('本机图片读取失败'));})));
  }
  async function write(rows){
    if(!rows.length)return;
    const db=await open();return new Promise((resolve,reject)=>{
      const transaction=db.transaction('images','readwrite'),store=transaction.objectStore('images');
      for(const row of rows)store.put(row);
      transaction.oncomplete=()=>resolve();transaction.onabort=transaction.onerror=()=>reject(Error('图片未能保存，请检查本机存储空间'));
    });
  }
  async function remove(ids){
    if(!ids.length)return;
    const db=await open();return new Promise((resolve,reject)=>{const transaction=db.transaction('images','readwrite');for(const id of ids)transaction.objectStore('images').delete(id);transaction.oncomplete=()=>resolve();transaction.onabort=transaction.onerror=()=>reject(Error('本机图片清理失败'));});
  }
  async function prepare(file){
    if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>15000000)throw Error('请选择15MB以内的PNG、JPG或WebP图片');
    let image;try{image=await createImageBitmap(file);}catch{throw Error('图片无法读取，请重新选择');}
    try{
      if(image.width*image.height>40000000)throw Error('图片尺寸过大，请裁剪后再选');
      const canvas=document.createElement('canvas'),scale=Math.min(1,1280/Math.max(image.width,image.height));canvas.width=Math.max(1,Math.round(image.width*scale));canvas.height=Math.max(1,Math.round(image.height*scale));const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(image,0,0,canvas.width,canvas.height);
      for(const quality of [.8,.6,.4]){const dataUrl=canvas.toDataURL('image/jpeg',quality);if(dataUrl.length<=327000)return {id:crypto.randomUUID(),dataUrl};}
      throw Error('图片压缩后仍过大，请裁剪后再选');
    }finally{image.close();}
  }
  globalThis.BeastTimerImages={read,write,remove,prepare};
})();
