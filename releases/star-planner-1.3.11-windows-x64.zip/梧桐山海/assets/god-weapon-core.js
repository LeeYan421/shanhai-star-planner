/* 图鉴按效果组归并；兵魂品质、词条品质和曲线档位独立保留。 */
(function(root){
  'use strict';
  const normalize=value=>String(value||'').normalize('NFKC').toLocaleLowerCase().replace(/[《》·・\s，,。；;：:]/g,'');
  const combat={
    1:{groups:{1:[12,142,141],2:[119,131,121,120,7],3:[153,158,159],4:[134,136,138]},note:'围绕朔风输出选词时，可先看纵横能否稳定打出暴击，以触发生风和破隙；凌风则等最后一击结束后生效。巽风舞适合目标半血以上的阶段，逐刚风对应半血以下的阶段。'},
    3:{groups:{1:[61,65,62],2:[68,29,35],3:[42,44,47],4:[146,147,149]},note:'搭配烈金与骑宠输出时，先保证能给骑宠喂食，让哺养效果发挥作用；潮鸣·涨还要求主人生命高于80%。振金用于烈金阵眼，天火用于流火阵眼；若主要培养青木或朔风，可改用雕木或穿燧。'},
    2:{groups:{1:[208,206,209],2:[236,233,228],3:[238,247,249],4:[259,260,256]},note:'兼顾青木输出与队伍续战时，可用盛木延长离开生灭领域后的锁定，用恒锲保护蓄力，以木犀强化领域中的友军。莽苍破的条件是生命高于80%，御苍山则要在未满血时回复生命；吟木歌把青木转为混沌是否划算，还需结合敌人判断。'},
    4:{groups:{1:[304,306,309],2:[314,318,329],3:[338,339,341],4:[344,346,350]},note:'祝融火想维持输出，可分别用燎原、熠耀和焚生补充攻击、穿透及元素穿透的继承，再用炎护帮助恢复能量。辉焕要配合指令·炎枪，焚枝要配合指令·冲击，施放顺序应随冷却安排。'}
  };
  function createGodWeaponIndex(data){
    const fail=()=>{throw new Error('神兵兵魂资料不完整');};
    if(data?.schema!==1||data.weapons?.length!==4||data.qualities?.length!==6||data.slotTypes?.length!==4||!data.variants?.length||!data.words?.length)fail();
    const words=new Map(),variants=new Map(),families=new Map(),weapons=new Map();
    for(const w of data.words){
      if(!Number.isSafeInteger(w.id)||words.has(w.id)||w.quality<0||w.quality>5||!w.values?.length||w.values.some(v=>typeof v!=='string'||!v)||w.values.length!==w.power?.length||w.power.some(v=>!Number.isFinite(v)||v<0)||!Number.isInteger(w.bestLevel)||w.bestLevel<1||w.bestLevel>w.values.length)fail();
      if(w.power[w.bestLevel-1]!==Math.max(...w.power))fail();words.set(w.id,w);
    }
    const wordPower=id=>{const w=words.get(id);return w.power[w.bestLevel-1];};
    const wordText=id=>{const w=words.get(id);return w.values[w.bestLevel-1];};
    for(const w of data.weapons){if(weapons.has(w.id)||!w.name||!w.slots?.length||!Number.isInteger(w.maxGrade)||w.maxGrade<1||w.slots.some(s=>s.type<1||s.type>4||s.grade<1||s.grade>w.maxGrade))fail();weapons.set(w.id,w);}
    for(const v of data.variants){
      if(variants.has(v.id)||!v.name||!v.group||v.quality<0||v.quality>5||!v.words?.length||v.words.some(i=>!words.has(i))||!v.weapons?.length||v.weapons.some(i=>!weapons.has(i))||v.slots?.length!==1||v.slots[0]<1||v.slots[0]>4||v.grade?.length!==2||v.grade[0]>v.grade[1]||!v.rolls?.length)fail();
      let power=0;const candidates=new Set();
      for(const roll of v.rolls){
        if(!Number.isInteger(roll.count)||roll.count!==roll.buckets?.length)fail();
        for(const bucket of roll.buckets){if(!bucket.length||bucket.some(i=>!words.has(i)||candidates.has(i)))fail();bucket.forEach(i=>candidates.add(i));power+=Math.max(...bucket.map(wordPower));}
      }
      if(power!==v.maxPower||candidates.size!==v.words.length||v.words.some(i=>!candidates.has(i))||v.bestWords?.length!==v.rolls.reduce((n,r)=>n+r.count,0)||v.bestWords.some(i=>!candidates.has(i))||v.bestWords.reduce((n,i)=>n+wordPower(i),0)!==power)fail();
      v.search=normalize(v.name+' '+v.description+' '+v.words.map(i=>words.get(i).values.join(' ')).join(' '));variants.set(v.id,v);
      if(!families.has(v.group))families.set(v.group,{id:v.group,variants:[]});
      const family=families.get(v.group);if(family.variants.some(x=>x.slots[0]!==v.slots[0]||String(x.weapons)!==String(v.weapons)))fail();family.variants.push(v);
    }
    for(const f of families.values()){
      f.variants.sort((a,b)=>b.quality-a.quality||b.maxPower-a.maxPower||a.id-b.id);f.name=f.variants[0].name;f.names=[...new Set(f.variants.map(v=>v.name))];f.slots=f.variants[0].slots;f.weapons=f.variants[0].weapons;
    }
    const matches=(f,query)=>String(query||'').trim().split(/\s+/).filter(Boolean).every(q=>f.search.includes(normalize(q)));
    function query(options={}){
      const weapon=Number(options.weapon)||0,slot=Number(options.slot)||0,quality=options.quality==null?-1:Number(options.quality);
      return [...families.values()].filter(f=>(!weapon||f.weapons.includes(weapon))&&(!slot||f.slots.includes(slot))).map(f=>({...f,variants:f.variants.filter(v=>(quality<0||v.quality===quality)&&matches(v,options.query))})).filter(f=>f.variants.length);
    }
    function recommend(options={}){
      const weapon=weapons.get(Number(options.weapon)),grade=Number(options.grade),quality=Number(options.quality),goal=options.goal||'combat';
      if(!weapon||!Number.isInteger(grade)||grade<1||grade>weapon.maxGrade||!Number.isInteger(quality)||quality<0||quality>5||!['combat','power'].includes(goal))throw new Error('请选择有效的神兵、等级和品质');
      const selected=new Set(),rows=[];
      for(const slot of weapon.slots.filter(s=>s.grade<=grade)){
        const eligible=[...families.values()].filter(f=>f.weapons.includes(weapon.id)&&f.slots.includes(slot.type)&&!selected.has(f.id)).map(f=>({family:f,variant:f.variants.filter(v=>v.quality<=quality&&v.grade[0]<=grade&&v.grade[1]>=grade).sort((a,b)=>b.maxPower-a.maxPower||b.quality-a.quality||a.id-b.id)[0]})).filter(r=>r.variant);
        const priorities=combat[weapon.id].groups[slot.type];
        const rank=f=>{const i=priorities.indexOf(f.id);return i<0?1000:i;};
        eligible.sort((a,b)=>(goal==='combat'?rank(a.family)-rank(b.family):0)||b.variant.maxPower-a.variant.maxPower||a.family.id-b.family.id);
        const row=eligible[0];if(row){selected.add(row.family.id);rows.push({...row,slot,fallback:goal==='combat'&&!priorities.includes(row.family.id)});}else rows.push({slot,variant:null,family:null});
      }
      return {weapon,grade,quality,goal,rows,power:rows.reduce((sum,r)=>sum+(r.variant?.maxPower||0),0),filled:rows.filter(r=>r.variant).length,locked:weapon.slots.length-rows.length,note:goal==='combat'?combat[weapon.id].note:'在已解锁的槽位和所选品质范围内，从不同效果组中组合出最高参考计分。结果按候选词条的最高档计算，需要在游戏中取得对应词条；神兵本体、其他神兵的转化和账号面板不计入。'};
    }
    return {data,words,variants,families,weapons,wordText,wordPower,query,recommend};
  }
  if(typeof module!=='undefined'&&module.exports)module.exports={createGodWeaponIndex};root.createGodWeaponIndex=createGodWeaponIndex;
})(globalThis);
