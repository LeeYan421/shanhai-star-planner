/* 原生目录只提供已关联的年份；计时时长由用户选择，区间的两个节点分别提醒。 */
(()=>{
  'use strict';
  const $=id=>document.getElementById(id),core=BeastTimersCore,store='wutong-beast-timers-preview-v1',favoriteKey='wutong-beast-favorites-v1',customKey='wutong-custom-resources-v1';
  let data,byId,records=[],favorites=new Set(),selected,editing,pendingReplacement,limit=60,visible=false,tab='千年',interval,lastRecords='',timeMode='single',customEditing=0,customIcon='',lastCustom='',draftImages=[],imageBusy=false,saving=false,draftVersion=0;
  const native=()=>typeof globalThis.AndroidPlanner?.getBeastTimerState==='function',esc=text=>String(text).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const canonicalId=id=>byId?.get(Number(id))?.aliasOf||Number(id);
  const rank={due:0,window:1,waiting_end:2,running:3,done:4};
  const sorted=()=>[...records].sort((a,b)=>rank[a.status]-rank[b.status]||core.remaining(a)-core.remaining(b)||a.dueAt-b.dueAt);
  const icons=()=>data.customIcons.map(row=>row.icon),customState=()=>core.customState(JSON.parse(localStorage.getItem(customKey)||'{"nextId":20000000,"resources":[]}'),icons());
  function applyCustom(rows){const raw=JSON.stringify(rows);if(raw===lastCustom)return;data.customResources=rows.map(row=>core.customResource(row,icons()));byId=new Map([...(data.legacyBeasts||[]),...data.beasts,...data.resources,...data.customResources].map(row=>[row.id,row]));lastCustom=raw;}
  function load(){const state=native()?JSON.parse(AndroidPlanner.getBeastTimerState()):{records:JSON.parse(localStorage.getItem(store)||'[]'),customResources:customState().resources};if(state.error)throw Error(state.error);applyCustom(state.customResources||[]);records=state.records.map(row=>core.validate(row,byId));return state;}
  function command(action,values){
    const removedImages=['delete','custom-delete'].includes(action)?records.flatMap(row=>row.images||[]):[];
    if(native()){const result=JSON.parse(AndroidPlanner.beastTimerCommand(JSON.stringify({action,...values})));if(!result.ok)throw Error(result.message||'计时设置失败');if(result.customResources)applyCustom(result.customResources);records=result.records;}
    else if(action==='custom-save'||action==='custom-delete'){
      const before=localStorage.getItem(customKey),beforeTimers=localStorage.getItem(store),state=customState(),next=action==='custom-save'?core.saveCustom(state,values.resource,icons()):core.deleteCustom(state,values.resourceId,icons()),nextRecords=action==='custom-delete'?records.filter(row=>row.beastId!==values.resourceId):records;
      try{localStorage.setItem(customKey,JSON.stringify(next));localStorage.setItem(store,JSON.stringify(nextRecords));}catch(error){try{if(before===null)localStorage.removeItem(customKey);else localStorage.setItem(customKey,before);if(beforeTimers===null)localStorage.removeItem(store);else localStorage.setItem(store,beforeTimers);}catch{}throw error;}
      applyCustom(next.resources);records=nextRecords;
    }
    else {
      let next=records.filter(row=>row.id!==values.id);
      if(action==='start'){if(next.length>=100)throw Error('最多保留100个计时');next.push(core.start(values,byId));}
      else if(action==='ack')next=records.map(row=>row.id===values.id&&(!values.expectedStatus||values.expectedStatus===row.status)?{...row,status:row.status==='window'?'waiting_end':row.status==='due'?'done':row.status}:row);
      localStorage.setItem(store,JSON.stringify(next));records=next;
    }
    if(removedImages.length)cleanImages(removedImages);
  }
  function caption(timer){if(timer.status==='done')return '已确认';if(timer.status==='due')return timer.latestDueAt?'区间计时结束':'计时到点';if(['window','waiting_end'].includes(timer.status))return '区间进行中';return timer.latestDueAt?'距最早提醒':'倒计时';}
  function timerDetails(timer){return `${timer.note?`<span class="beast-timer-note">${esc(timer.note)}</span>`:''}${timer.images?.length?`<small class="beast-image-count">图片 ${timer.images.length}张</small>`:''}`;}
  function yearBadge(beast){
    const mark=core.yearMark(beast);if(!mark)return '';
    // 侧面兽首、卷焰鬃毛与下方豆点组成单张原创SVG，整体放在名称前。
    const beans=Array.from({length:mark.beans},(_,index)=>{const offset=index-(mark.beans-1)/2,x=32+offset*9.5,y=66-Math.abs(offset)*2;return `<path class="beast-mark-bean" d="m${x} ${y-4} 4 4-4 4-4-4Z"/>`;}).join('');
    return `<span class="beast-year-mark" role="img" data-beans="${mark.beans}" aria-label="${esc(beast.year)}${mark.beans?'，'+mark.beans+'豆':''}"><svg viewBox="0 0 64 74" aria-hidden="true"><path class="beast-mark-frame" d="M32 3 61 32 32 61 3 32Z"/><path class="beast-mark-inset" d="M32 8 56 32 32 56 8 32Z"/><path class="beast-mark-face" d="m13 28 6-7 5-2-1-7 8 4c2-5 6-8 11-9l-2 9c6 0 10-3 14-6 1 7-2 12-9 16l13-3c-1 7-6 11-13 12l12 3c-5 6-11 8-18 5l6 9c-7 1-12-1-16-6l-2 8-5-9-5 2-6-6 4-4-7-2 2-6Z"/><path class="beast-mark-highlight" d="m28 19 5 1c3-5 6-7 9-8m-8 14c6-1 11-3 15-7"/><path class="beast-mark-line" d="m21 23-3 6-7 3m5 5 7-2 3 3-4 6m9-11c6-4 12-1 18-5m-18 11c4 3 9 5 14 4m-17-2 2 7"/><path class="beast-mark-eye" d="m18 28 7-2-4 5Z"/><path class="beast-mark-fang" d="m14 39 4 1-3 4Z"/>${mark.kind==='mythic'?'<path class="beast-mark-crown" d="m28 6 1-5 4 3 4-3 2 5Z"/>':''}${beans}</svg></span>`;
  }
  function star(beast){const id=canonicalId(beast.id);return beast.legacy?'':`<mdui-button-icon class="beast-star ${favorites.has(id)?'is-favorite':''}" data-favorite="${id}" aria-label="${favorites.has(id)?'取消常用':'加入常用'} ${esc(beast.name)}"><svg viewBox="0 0 24 24"><path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9Z"/></svg></mdui-button-icon>`;}
  function tile(beast,timer){const pending=timer&&timer.status!=='done',state=timer?.status||'',year=beast.legacy?'旧目录记录 · 请重新选择':beast.year;return `<mdui-card class="beast-tile ${timer?'is-timed':''} ${state==='due'?'is-due':''}" variant="filled" clickable data-beast="${beast.id}" ${timer?`data-timer="${timer.id}"`:''} aria-label="${esc(year+'·'+beast.name)}">${star(beast)}${timer?`<mdui-button-icon class="beast-cancel" data-cancel-timer="${timer.id}" aria-label="删除 ${esc(beast.name)} 计时"><svg viewBox="0 0 24 24"><path d="m6 6 12 12M18 6 6 18"/></svg></mdui-button-icon>`:''}<img src="${beast.icon}" alt="" width="52" height="52" loading="lazy"><span class="beast-name">${yearBadge(beast)}<strong>${esc(beast.name)}</strong></span><small>${esc(year)}</small>${beast.kind==='custom'?`<small>默认 ${Math.floor(beast.defaultMinutes/60)}小时${beast.defaultMinutes%60?beast.defaultMinutes%60+'分钟':''}</small>`:''}${beast.refreshHint?`<small>参考 ${esc(beast.refreshHint)}</small>`:''}${timer?`<span class="beast-timer-caption">${caption(timer)}</span>${pending?`<b data-countdown="${timer.id}">${core.display(core.remaining(timer))}</b><mdui-linear-progress data-beast-progress="${timer.id}" value="${core.progress(timer)}"></mdui-linear-progress>`:''}${['due','window'].includes(state)?`<mdui-button class="beast-ack" variant="text" data-ack="${timer.id}" data-ack-stage="${state}">知道了</mdui-button>`:''}`:''}${timer?timerDetails(timer):''}${beast.kind==='custom'?`<mdui-button class="custom-resource-edit" variant="text" data-edit-custom="${beast.id}">编辑</mdui-button>`:''}</mdui-card>`;}
  function render(){
    if(!data)return;
    // 刷新参考随年份切换，不改写已经选择的计时时长。
    const hint=data.refreshHints?.[tab]||'';$('beast-refresh-tip').textContent=hint?tab+'刷新参考：'+hint:'';$('beast-refresh-tip').hidden=!hint;
    const query=$('beast-query').value,ordered=sorted();let cards;
    if(tab==='timers')cards=ordered.filter(row=>{const beast=byId.get(row.beastId);return !query||beast.name.includes(query);}).map(row=>({beast:byId.get(row.beastId),timer:row}));
    else {const rows=core.filter(data,data.years.includes(tab)||['resources','custom'].includes(tab)?tab:'',query).filter(beast=>tab!=='favorites'||favorites.has(beast.id));cards=rows.map(beast=>({beast,timer:ordered.find(row=>canonicalId(row.beastId)===beast.id)}));}
    $('beast-active-count').textContent=String(records.filter(row=>row.status!=='done').length);$('beast-count').textContent=tab==='timers'?cards.length+'个计时':cards.length+(data.years.includes(tab)?'只':'项');
    $('beast-picker').innerHTML=cards.slice(0,limit).map(row=>tile(row.beast,row.timer)).join('');$('beast-more').hidden=limit>=cards.length;
    $('beast-empty-pick').hidden=!!cards.length;$('beast-empty-pick').textContent=tab==='favorites'?'点星标，把常用巨兽放在这里。':tab==='timers'?'还没有计时，点巨兽头像开始。':'没有匹配的资源或巨兽';lastRecords=JSON.stringify(records);
  }
  // 只滚动页签条，保留页面与计时列表的阅读位置。
  async function revealTab(){
    const tabs=$('beast-tabs');await tabs.updateComplete;if(!visible)return;
    const container=tabs.shadowRoot?.querySelector('[part=container]'),active=[...tabs.querySelectorAll('mdui-tab')].find(item=>item.value===tab);if(!container||!active)return;
    const bounds=container.getBoundingClientRect(),item=active.getBoundingClientRect();
    if(item.left<bounds.left)container.scrollLeft+=item.left-bounds.left;
    else if(item.right>bounds.right)container.scrollLeft+=item.right-bounds.right;
  }
  function setTab(value){tab=value;limit=60;$('beast-tabs').value=tab;render();revealTab();}
  addEventListener('resize',()=>{if(visible)revealTab();});
  function refresh(){if(!data)return;try{const state=load();if(JSON.stringify(records)!==lastRecords)render();$('beast-permissions').hidden=!native()||!!globalThis.DesktopHost;for(const [key,id]of [['exact','beast-permission-alarm'],['notifications','beast-permission-notification'],['overlay','beast-permission-overlay']])$(id).hidden=!!state[key];$('beast-permissions').classList.toggle('all-ready',!!state.exact&&!!state.notifications&&!!state.overlay);$('beast-platform-hint').textContent=globalThis.DesktopHost?'保持软件运行，到点弹窗提醒。':native()?'切回游戏后仍会提醒。':'网页预览需保持页面运行。';}catch(error){globalThis.Diagnostics?.record('beasts',error,'DATA_RESTORE');$('beast-status').textContent=error.message;}}
  function mode(){const group=$('beast-time-mode');timeMode=group.value||timeMode;group.value=timeMode;group.querySelectorAll('mdui-segmented-button').forEach(button=>button.setAttribute('aria-pressed',String(button.value===timeMode)));const range=timeMode==='range';$('beast-range-fields').hidden=!range;$('beast-hours').label=range?'最早 · 小时':'小时';$('beast-minutes').label=range?'最早 · 分钟':'分钟';}
  function putTime(prefix,minutes){$(prefix+'hours').value=String(Math.floor(minutes/60));$(prefix+'minutes').value=String(minutes%60);}
  function localTime(time){const date=new Date(time),pad=value=>String(value).padStart(2,'0');return date.getFullYear()+'-'+pad(date.getMonth()+1)+'-'+pad(date.getDate())+'T'+pad(date.getHours())+':'+pad(date.getMinutes());}
  function timeBounds(){const now=Date.now(),field=$('beast-started-at');field.min=localTime(Math.ceil((now-core.DAY)/60000)*60000);field.max=localTime(Math.floor(now/60000)*60000);}
  function originMode(){const group=$('beast-origin-mode'),value=group.value||'now';group.value=value;group.querySelectorAll('mdui-segmented-button').forEach(button=>button.setAttribute('aria-pressed',String(button.value===value)));timeBounds();$('beast-started-field').hidden=value!=='custom';}
  function imageState(){
    $('beast-image-previews').innerHTML=draftImages.map((image,index)=>`<div class="beast-image-item">${image.missing?'<span>图片已不可用</span>':`<button class="beast-image-preview" data-view-image="${index}" aria-label="查看附件${index+1}"><img src="${esc(image.dataUrl)}" alt="附件${index+1}"></button>`}<mdui-button variant="text" data-remove-beast-image="${index}" aria-label="移除附件${index+1}">移除</mdui-button></div>`).join('');
    $('beast-add-images').disabled=imageBusy||saving||draftImages.length>=3;$('beast-start').disabled=$('beast-new-copy').disabled=imageBusy||saving;
    $('beast-note').disabled=saving;$('beast-origin-mode').disabled=saving;$('beast-images').disabled=imageBusy||saving;
  }
  function viewImage(index){const image=draftImages[index];if(!image||image.missing)return;$('beast-image-full').src=image.dataUrl;$('beast-image-dialog').showModal();}
  // 删除时只清理由当前记录不再引用的图片，另记一只共享的附件继续保留。
  async function cleanImages(ids){const used=new Set(records.flatMap(row=>row.images||[]));try{await BeastTimerImages.remove(ids.filter(id=>!used.has(id)));}catch(error){globalThis.Diagnostics?.record('beasts',error,'TIMER_IMAGE');PlannerApp.toast('部分本机图片清理失败');}}
  function pick(beastId,timerId){
    const beast=byId.get(canonicalId(beastId));if(!beast)return;
    if(beast.legacy){pendingReplacement=timerId;setTab('all');$('beast-query').value=beast.name;render();PlannerApp.toast('请选择核对后的巨兽和年份');return;}
    selected=beast;editing=timerId||pendingReplacement||null;pendingReplacement=null;const old=records.find(row=>row.id===editing),minutes=old?Math.ceil(old.durationMs/60000):(beast.defaultMinutes||360),latest=old?.latestDurationMs?Math.ceil(old.latestDurationMs/60000):Math.min(43200,minutes+60);
    const version=++draftVersion;draftImages=[];imageBusy=!!old?.images?.length;$('beast-note').value=old?.note||'';$('beast-duration-year').innerHTML=yearBadge(beast);$('beast-origin-mode').value='now';$('beast-started-at').value=localTime(Date.now());originMode();const previous=old&&(old.startedAt||old.dueAt-old.durationMs);$('beast-previous-start').textContent=previous?'上次起点：'+localTime(previous).replace('T',' '):'';$('beast-previous-start').hidden=!previous;imageState();
    if(imageBusy)BeastTimerImages.read(old.images).then(images=>{if(version===draftVersion)draftImages=images;}).catch(error=>{globalThis.Diagnostics?.record('beasts',error,'TIMER_IMAGE');if(version===draftVersion){draftImages=old.images.map(id=>({id,missing:true}));$('beast-duration-error').textContent=error.message;}}).finally(()=>{if(version===draftVersion){imageBusy=false;imageState();}});
    $('beast-duration-title').textContent=beast.year+'·'+beast.name;const hint=beast.refreshHint||data.refreshHints?.[beast.filterYear]||'';$('beast-selected-refresh').textContent=hint?'刷新参考：'+hint:'';$('beast-selected-refresh').hidden=!hint;$('beast-duration-avatar').src=beast.icon;$('beast-time-mode').value=old?.latestDueAt?'range':'single';putTime('beast-',minutes);putTime('beast-latest-',latest);$('beast-duration-preset').value=data.durationPresets.includes(minutes)?String(minutes):'0';$('beast-duration-error').textContent='';$('beast-new-copy').hidden=!editing;$('beast-start').textContent=editing?'重新计时':'开始计时';mode();$('beast-duration-dialog').showModal();
  }
  async function start(copy){
    if(imageBusy||saving)return;let added=[];const version=draftVersion;
    try{
      const durationMs=core.duration($('beast-hours').value,$('beast-minutes').value),values={id:!copy&&editing||crypto.randomUUID(),beastId:selected.id,durationMs,...core.details({note:$('beast-note').value,images:draftImages.map(row=>row.id)})};
      if($('beast-origin-mode').value==='custom')values.startedAt=core.startTime(new Date($('beast-started-at').value).getTime());
      if($('beast-time-mode').value==='range'){values.latestDurationMs=core.duration($('beast-latest-hours').value,$('beast-latest-minutes').value);if(values.latestDurationMs<=durationMs)throw Error('最晚时长需大于最早时长');}
      saving=true;imageState();const before=records.find(row=>row.id===values.id)?.images||[],fresh=draftImages.filter(row=>row.fresh);await BeastTimerImages.write(fresh.map(({id,dataUrl})=>({id,dataUrl})));added=fresh.map(row=>row.id);
      if(version!==draftVersion){await cleanImages(added);return;}
      command('start',values);draftImages.forEach(row=>delete row.fresh);$('beast-duration-dialog').close();$('beast-query').value='';setTab('timers');PlannerApp.toast('已开始计时');await cleanImages(before);
    }catch(error){globalThis.Diagnostics?.record('beasts',error,'TIMER_COMMAND');if(added.length)await cleanImages(added);$('beast-duration-error').textContent=error.message;}
    finally{saving=false;imageState();}
  }
  function tick(){
    if(!data)return;if($('beast-duration-dialog').open)timeBounds();if(native()){if(visible)refresh();}else {let changed=false;records=records.map(row=>{const next=core.advance(row);if(next!==row)changed=true;return next;});if(changed){localStorage.setItem(store,JSON.stringify(records));if(navigator.vibrate)navigator.vibrate([350,150,350]);$('beast-due-message').textContent=records.filter(row=>['window','due'].includes(row.status)).map(row=>byId.get(row.beastId).name+' · '+caption(row)).join('、');$('beast-due-dialog').showModal();render();}}
    if(visible)for(const row of records){const label=document.querySelector(`[data-countdown="${row.id}"]`),bar=document.querySelector(`[data-beast-progress="${row.id}"]`);if(label)label.textContent=core.display(core.remaining(row));if(bar)bar.value=core.progress(row);}
  }
  $('beast-query').addEventListener('input',()=>{limit=60;render();});$('beast-more').onclick=()=>{limit+=60;render();};$('beast-tabs').addEventListener('change',()=>setTab($('beast-tabs').value));
  $('beast-picker').onclick=event=>{try{const own=event.target.closest('[data-edit-custom]'),favorite=event.target.closest('[data-favorite]'),cancel=event.target.closest('[data-cancel-timer]'),ack=event.target.closest('[data-ack]'),card=event.target.closest('[data-beast]');if(own){editCustom(Number(own.dataset.editCustom));}else if(favorite){const id=Number(favorite.dataset.favorite),next=new Set(favorites);if(next.has(id))next.delete(id);else next.add(id);localStorage.setItem(favoriteKey,JSON.stringify([...next]));favorites=next;render();}else if(cancel){command('delete',{id:cancel.dataset.cancelTimer});render();}else if(ack){command('ack',{id:ack.dataset.ack,expectedStatus:ack.dataset.ackStage});render();}else if(card)pick(card.dataset.beast,card.dataset.timer);}catch(error){globalThis.Diagnostics?.record('beasts',error,'TIMER_COMMAND');PlannerApp.toast(error.message);}};
  $('beast-time-mode').addEventListener('change',mode);$('beast-duration-preset').addEventListener('change',()=>{const minutes=Number($('beast-duration-preset').value);if(minutes>0){putTime('beast-',minutes);if($('beast-time-mode').value==='range')putTime('beast-latest-',Math.min(43200,minutes+60));}});
  for(const id of ['beast-hours','beast-minutes','beast-latest-hours','beast-latest-minutes'])$(id).addEventListener('input',()=>{$('beast-duration-preset').value='0';$('beast-duration-error').textContent='';});
  $('beast-start').onclick=()=>start(false);$('beast-new-copy').onclick=()=>start(true);
  $('beast-origin-mode').addEventListener('change',originMode);$('beast-add-images').onclick=()=>$('beast-images').click();
  $('beast-images').onchange=async()=>{
    const files=Array.from($('beast-images').files||[]),version=draftVersion;$('beast-images').value='';if(!files.length||imageBusy||saving)return;
    try{if(draftImages.length+files.length>3)throw Error('最多添加3张本地图片');imageBusy=true;imageState();const images=[];for(const file of files)images.push({...await BeastTimerImages.prepare(file),fresh:true});if(version===draftVersion){draftImages.push(...images);$('beast-duration-error').textContent='';}}
    catch(error){globalThis.Diagnostics?.record('beasts',error,'TIMER_IMAGE');if(version===draftVersion)$('beast-duration-error').textContent=error.message;}finally{if(version===draftVersion){imageBusy=false;imageState();}}
  };
  $('beast-image-previews').onclick=event=>{if(saving||imageBusy)return;const remove=event.target.closest('[data-remove-beast-image]'),view=event.target.closest('[data-view-image]');if(remove){draftImages.splice(Number(remove.dataset.removeBeastImage),1);imageState();}else if(view)viewImage(Number(view.dataset.viewImage));};
  $('beast-image-close').onclick=()=>$('beast-image-dialog').close();$('beast-image-dialog').addEventListener('closed',()=>{$('beast-image-full').removeAttribute('src');});
  $('beast-duration-dialog').addEventListener('close',()=>{draftVersion++;draftImages=[];imageBusy=false;});
  document.querySelectorAll('[data-beast-close]').forEach(button=>button.onclick=()=>button.closest('mdui-dialog').close());$('beast-due-ack').onclick=()=>{try{for(const row of [...records])if(['window','due'].includes(row.status))command('ack',{id:row.id,expectedStatus:row.status});$('beast-due-dialog').close();render();}catch(error){globalThis.Diagnostics?.record('beasts',error,'TIMER_COMMAND');PlannerApp.toast(error.message);}};
  document.querySelectorAll('[data-beast-permission]').forEach(button=>button.onclick=()=>AndroidPlanner.openBeastPermission(button.dataset.beastPermission));
  function editCustom(id=0){
    const row=data.customResources.find(item=>item.id===id);customEditing=row?.id||0;customIcon=row?.icon||data.customIcons[0].icon;$('custom-resource-title').textContent=row?'编辑资源':'新增资源';$('custom-resource-name').value=row?.name||'';$('custom-resource-icon-options').innerHTML=data.customIcons.map(item=>`<mdui-button-icon class="custom-resource-icon-option" data-custom-icon="${item.icon}" variant="${item.icon===customIcon?'tonal':'standard'}" aria-label="${esc(item.name)}" aria-pressed="${item.icon===customIcon}"><img src="${item.icon}" alt="" width="40" height="40"/></mdui-button-icon>`).join('');$('custom-resource-preview').src=customIcon;$('custom-resource-icon-picker').open=false;const minutes=row?.defaultMinutes||240;$('custom-resource-hours').value=String(Math.floor(minutes/60));$('custom-resource-minutes').value=String(minutes%60);$('custom-resource-delete').hidden=!row;$('custom-resource-error').textContent='';$('custom-resource-dialog').showModal();
  }
  $('custom-resource-new').onclick=()=>{if(data)editCustom();};
  // 图标选择只更新编辑草稿；点保存后才写入资源和已有计时关联。
  $('custom-resource-icon-options').onclick=event=>{const button=event.target.closest('[data-custom-icon]');if(!button)return;customIcon=button.dataset.customIcon;$('custom-resource-preview').src=customIcon;for(const option of $('custom-resource-icon-options').children){const chosen=option.dataset.customIcon===customIcon;option.variant=chosen?'tonal':'standard';option.setAttribute('aria-pressed',String(chosen));}$('custom-resource-icon-picker').open=false;};
  $('custom-resource-dialog').addEventListener('close',()=>{$('custom-resource-icon-picker').open=false;});
  document.querySelectorAll('[data-custom-close]').forEach(button=>button.onclick=()=>button.closest('mdui-dialog').close());
  $('custom-resource-save').onclick=()=>{try{
    const resource={id:customEditing,name:$('custom-resource-name').value,icon:customIcon,defaultMinutes:core.duration($('custom-resource-hours').value,$('custom-resource-minutes').value)/60000};resource.name=core.customResource({...resource,id:customEditing||20000001},icons()).name;command('custom-save',{resource});$('custom-resource-dialog').close();$('beast-query').value='';setTab('custom');PlannerApp.toast('资源已保存');
  }catch(error){globalThis.Diagnostics?.record('beasts',error,'TIMER_COMMAND');$('custom-resource-error').textContent=error.message;}};
  $('custom-resource-delete').onclick=()=>{$('custom-resource-dialog').close();$('custom-resource-delete-error').textContent='';$('custom-resource-delete-dialog').showModal();};
  $('custom-resource-delete-cancel').onclick=()=>{$('custom-resource-delete-dialog').close();$('custom-resource-dialog').showModal();};
  $('custom-resource-delete-confirm').onclick=()=>{try{command('custom-delete',{resourceId:customEditing});favorites.delete(customEditing);try{localStorage.setItem(favoriteKey,JSON.stringify([...favorites]));}catch{}$('custom-resource-delete-dialog').close();setTab('custom');PlannerApp.toast('资源已删除');}catch(error){globalThis.Diagnostics?.record('beasts',error,'TIMER_COMMAND');$('custom-resource-delete-error').textContent=error.message;}};
  globalThis.BeastTimersUI={async open(){visible=true;$('beast-status').textContent='';try{if(!data){const response=await fetch('beast-timers-data.json');if(!response.ok)throw Error('巨兽目录载入失败');data=await response.json();byId=new Map([...(data.legacyBeasts||[]),...data.beasts,...(data.resources||[])].map(row=>[row.id,row]));load();try{favorites=new Set(JSON.parse(localStorage.getItem(favoriteKey)||'[]').map(canonicalId).filter(id=>byId.has(id)&&!byId.get(id).legacy));}catch(error){globalThis.Diagnostics?.record('beasts',error,'DATA_RESTORE');favorites=new Set();}$('beast-tabs').innerHTML='<mdui-tab value="favorites">常用</mdui-tab><mdui-tab value="timers">计时 <span id="beast-active-count">0</span></mdui-tab><mdui-tab value="all">全部</mdui-tab><mdui-tab value="resources">资源</mdui-tab><mdui-tab value="custom">自定义</mdui-tab>'+data.years.map(year=>`<mdui-tab value="${esc(year)}">${esc(year)}</mdui-tab>`).join('');}refresh();setTab(records.some(row=>row.status!=='done')?'timers':data.years.includes(tab)||['favorites','all','timers','resources','custom'].includes(tab)?tab:data.years[0]);(interval||(interval=setInterval(tick,1000)));}catch(error){globalThis.Diagnostics?.record('beasts',error,'DATA_RESTORE');$('beast-status').textContent=error.message;}},refresh,leave(){visible=false;pendingReplacement=null;if(native()){clearInterval(interval);interval=undefined;}},snapshot:()=>({records,loaded:!!data,favorites:[...favorites],tab})};
})();
