/* 诊断只保留白名单字段，不保存异常原文、地址、凭证或用户配置。 */
(function(root){
  'use strict';
  const marker='[WT-DIAGNOSTICS/1]\n',key='wutong-diagnostic-errors-v1';
  const modules=['app','planner','equipment','chiyou','mutation','clock','guide','lookup','update','backup','community','talents','beasts','share'];
  const kinds=['Error','ReferenceError','TypeError','RangeError','SyntaxError','AbortError','IOException','JSONException','SecurityException','IllegalArgumentException','IllegalStateException','NullPointerException','IndexOutOfBoundsException','ArithmeticException','UnsupportedOperationException','RuntimeException','OutOfMemoryError','NativeError'];
  const codes=['REF_BYID','REF_MODULE','JS_REFERENCE','JS_TYPE','JS_RANGE','JS_SYNTAX','WASM_LOAD','SOLVER_INCOMPLETE','STORAGE_FAILED','NETWORK_FAILED','UNKNOWN_ERROR','CLOCK_OPEN','CLOCK_LAYOUT','GUIDE_OPEN','GUIDE_LAYOUT','LOOKUP_OPEN','LOOKUP_LAYOUT','UPDATE_CHECK','UPDATE_DOWNLOAD','BACKUP_EXPORT','FILE_PICKER','COMMUNITY_REQUEST','DATA_LOAD','DATA_SAVE','DATA_RESTORE','PLAN_SAVE','PLAN_IMPORT','PLAN_COMPARE','GUIDE_STATE','TIMER_COMMAND','TIMER_RESTORE','TIMER_NOTIFY','TIMER_IMAGE','SHARE_IMAGE','SHARE_CODE','COPY_TEXT','BACKUP_IMPORT','UPDATE_GATE_RESTORE','UPDATE_GATE_SAVE','UPDATE_INSTALL','PERMISSION_OPEN'];
  const files=['equipment','equipment-core','god-weapon-core','chiyou','chiyou-core','app','solver','strategy-engine','element-goals','element-rules','auto-power','crit-target','pvp-rules','planner-worker','webview-compat','mutation','mutation-core','clock','community','personal','personal-core','share-ui','share-codec','share-card','diagnostics','diagnostics-core','beast-timers','beast-timers-core','beast-timer-images','floating-lookup','talent-details','talent-insights','talent-levels-core','account-talents','talent-art','core','native-ui','select-fit','guide','guide-core','mdui.global','data','qrcode'];
  const nativeClasses=['MainActivity','FloatingClockService','FloatingGuideService','FloatingLookupService','CommunityClient','UpdateClient','UpdateDownloader','ClockSettings','GuideState','ShareImagePolicy','BeastTimers','BeastTimerReceiver','BeastReminderService','FloatingGuideStore'];
  // 仅保留白名单脚本的行列号，兼容带点的文件名和压缩脚本的长列号。
  function frame(value){if(typeof value!=='string')return '';const js=/^([\w.-]+)\.js:(\d{1,7}):(\d{1,7})$/.exec(value);if(js&&files.includes(js[1]))return value;if(/^worker:\d{1,7}:\d{1,7}$/.test(value))return value;const native=/^([\w]+)\.([\w$]{1,60}):(\d{1,7})$/.exec(value);return native&&nativeClasses.includes(native[1])?value:'';}
  function normalize(value){if(!value||!modules.includes(value.module)||!kinds.includes(value.kind)||!codes.includes(value.code))return null;return {module:value.module,kind:value.kind,code:value.code,frames:(Array.isArray(value.frames)?value.frames:[]).map(frame).filter(Boolean).slice(0,5),count:Number.isInteger(value.count)&&value.count>0?Math.min(value.count,999):1,...(Number.isSafeInteger(value.at)&&value.at>0&&value.at<=8640000000000000?{at:value.at}:{})};}
  // 全局异常优先按业务脚本归类，共用组件异常再取当前页面。
  function moduleFor(error,page){
    const routes={config:'planner',result:'planner',compare:'planner',collection:'mutation',talents:'talents',beasts:'beasts',equipment:'equipment',chiyou:'chiyou',mutation:'mutation',clock:'clock',guide:'guide',community:'community'},scripts={'beast-timers':'beasts','beast-timers-core':'beasts','beast-timer-images':'beasts','account-talents':'talents','talent-levels-core':'talents','share-ui':'share','share-codec':'share','share-card':'share',personal:'backup','planner-worker':'planner',solver:'planner','strategy-engine':'planner'};
    for(const match of String(error?.stack||'').matchAll(/([\w-]+)\.js:\d+:\d+/g)){const name=match[1];if(scripts[name])return scripts[name];if(name!=='app'&&modules.includes(name))return name;}
    return routes[page]||'app';
  }
  function classify(message,kind){if(/\bbyId is not defined\b/.test(message))return 'REF_BYID';if(/\bModule is not defined\b/.test(message))return 'REF_MODULE';if(kind==='ReferenceError')return 'JS_REFERENCE';if(kind==='TypeError')return 'JS_TYPE';if(kind==='RangeError')return 'JS_RANGE';if(kind==='SyntaxError')return 'JS_SYNTAX';if(/WASM|WebAssembly|计算组件/i.test(message))return 'WASM_LOAD';if(/求解.*未|未生成最优/.test(message))return 'SOLVER_INCOMPLETE';if(/Quota|存储|未能保存/i.test(message))return 'STORAGE_FAILED';if(/Network|fetch|连接|超时/i.test(message))return 'NETWORK_FAILED';return 'UNKNOWN_ERROR';}
  function fromError(module,error){
    const kind=kinds.includes(error?.name)?error.name:'Error',message=typeof error?.message==='string'?error.message:'',stack=typeof error?.stack==='string'?error.stack:'',frames=[];
    for(const line of stack.slice(0,6000).split('\n')){const js=/([\w.-]+\.js):(\d+):(\d+)/.exec(line),worker=/blob:[^\s)]+:(\d+):(\d+)/.exec(line);const found=js?frame(js[1]+':'+js[2]+':'+js[3]):worker?frame('worker:'+worker[1]+':'+worker[2]):'';if(found)frames.push(found);}
    return normalize({module,kind,code:classify(message,kind),frames,count:1});
  }
  function createStore(storage){
    let memory=[],unsaved=false;
    function read(){if(!unsaved)try{const raw=JSON.parse(storage.getItem(key)||'[]');memory=(Array.isArray(raw)?raw:[]).map(normalize).filter(Boolean).slice(-20);}catch{}return memory.map(x=>({...x,frames:x.frames.slice()}));}
    function record(module,error,code){if(error?.name==='AbortError')return;const entry=fromError(module,error);if(!entry)return;if(codes.includes(code))entry.code=code;const rows=read(),last=rows.at(-1),signature=value=>JSON.stringify({...value,count:1,at:0});entry.at=Date.now();if(last&&signature(last)===signature(entry)){last.count=Math.min(999,last.count+1);last.at=entry.at;}else rows.push(entry);memory=rows.slice(-20);try{storage.setItem(key,JSON.stringify(memory));unsaved=false;}catch{unsaved=true;}}
    return {read,record};
  }
  function report(metadata,entries){
    const value={schema:1,appVersion:typeof metadata?.appVersion==='string'&&/^\d+\.\d+\.\d+[\w.+-]{0,24}$/.test(metadata.appVersion)?metadata.appVersion:'unknown',versionCode:Number.isSafeInteger(metadata?.versionCode)&&metadata.versionCode>0?metadata.versionCode:0,dataId:typeof metadata?.dataId==='string'&&/^[a-f0-9]{16}$/.test(metadata.dataId)?metadata.dataId:'',errors:(Array.isArray(entries)?entries:[]).map(normalize).filter(Boolean).sort((a,b)=>(a.at||0)-(b.at||0)).slice(-20)};
    let body=marker+JSON.stringify(value,null,2);while(body.length>3800&&value.errors.length){value.errors.shift();body=marker+JSON.stringify(value,null,2);}return body;
  }
  function sanitizeReport(raw){if(typeof raw!=='string'||!raw.startsWith(marker)||raw.length>4000)throw new Error('日志格式无效');const value=JSON.parse(raw.slice(marker.length));if(value.schema!==1)throw new Error('日志格式无效');return report(value,value.errors);}
  const api={marker,key,createStore,fromError,moduleFor,normalize,report,sanitizeReport};if(typeof module!=='undefined'&&module.exports)module.exports=api;root.DiagnosticCore=api;
})(globalThis);
