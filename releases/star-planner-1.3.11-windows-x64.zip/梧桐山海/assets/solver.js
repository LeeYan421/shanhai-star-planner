/* 星宿精确优化：枚举组件内收益节点，闭合全部前置，再对点数做动态规划。 */
(function (root) {
  'use strict';
  if(typeof module!=='undefined'&&module.exports)require('./element-rules.js');
  if(typeof module!=='undefined'&&module.exports)require('./talent-levels-core.js');

  function createPlannerEngine(data) {
    const talentLevelRules=createTalentLevelRules(data);
    const byId = new Map(data.nodes.map(n => [n.id, n]));
    const talentById = new Map(data.talents.map(t => [t.id, t]));
    const elementByKey = new Map((data.elements || []).flatMap(e => e.options).map(option => [option.key, option]));
    const starById = new Map(data.stars.map(s => [s.id, s]));
    const coreIds = new Set(data.core);
    const gateBit = new Map(data.gates.map((id, i) => [id, 1 << i]));
    const critId = data.objective.crit, attackId = data.objective.attack;
    const isObjective = n => n.attrId === critId || n.attrId === attackId;
    const weight = data.nodes.filter(n => n.attrId === attackId).reduce((v, n) => v + Math.max(...n.values), 0) + 1;
    const components = new Map();
    const optionCache = new Map();
    for (const n of data.nodes) {
      if (!components.has(n.starId)) components.set(n.starId, []);
      components.get(n.starId).push(n);
      if (n.values.length !== n.costs.length || !n.values.length || n.costs.some(c => !Number.isInteger(c) || c <= 0)) throw new Error('星宿数值或耗点数据不完整');
      if (n.pre.some(id => !byId.has(id))) throw new Error('星宿前置引用缺失');
      if (isObjective(n) && n.values.some(v => !Number.isSafeInteger(v) || v < 0)) throw new Error('目标属性数据不支持精确整数计算');
    }
    for (const list of components.values()) list.sort((a, b) => a.id - b.id);
    if (data.gates.length > 8) throw new Error('星系前置结构超出当前求解范围');

    function score(n, level) {
      if (!level) return 0;
      return n.attrId === critId ? n.values[level - 1] * weight : n.attrId === attackId ? n.values[level - 1] : 0;
    }
    function nodeCost(n, level) { let sum = 0; for (let i = 0; i < level; i++) sum += n.costs[i]; return sum; }
    // 与原生GetAtbFightScore保持一致：单参数直接乘，其余按分子／分母向下取整。
    function resourceScore(parameters, value) {
      if (!parameters || !parameters.length) return 0;
      const numerator = value * parameters[0];
      if (!Number.isSafeInteger(numerator)) throw new Error('战力计算超出可处理范围');
      return parameters.length === 1 ? numerator : Math.floor(numerator / parameters[1]);
    }
    function closure(required) {
      const levels = new Map(required), visiting = new Set();
      function visit(id) {
        if (visiting.has(id)) throw new Error('星宿前置存在循环');
        const n = byId.get(id);
        if (!n) throw new Error('目标星宿不存在');
        visiting.add(id);
        for (const p of n.pre) {
          if (!levels.get(p)) { levels.set(p, 1); visit(p); }
        }
        visiting.delete(id);
      }
      for (const id of Array.from(levels.keys())) visit(id);
      return levels;
    }
    function costOf(levels) { let cost = 0; for (const [id, lv] of levels) cost += nodeCost(byId.get(id), lv); return cost; }

    // 无收益的节点只保留目标所需等级或前置的1级；额外升级不会改善本次目标。
    function enumerate(nodes, required, forcedGateMask = 0, isCore = false) {
      const key = (isCore ? 'core' : nodes[0].starId) + ':' + forcedGateMask + ':' + nodes.map(n => required.get(n.id) || 0).join(',');
      if (optionCache.has(key)) return optionCache.get(key);
      const index = new Map(nodes.map((n, i) => [n.id, i]));
      const base = nodes.map(n => Math.max(required.get(n.id) || 0, (gateBit.get(n.id) & forcedGateMask) ? 1 : 0));
      const objectives = nodes.map((n, i) => isObjective(n) ? i : -1).filter(i => i >= 0);
      const chosen = base.slice(), best = new Map();
      function evaluate() {
        const levels = chosen.slice();
        let mask = 0;
        function visit(i) {
          for (const p of nodes[i].pre) {
            if (!index.has(p)) {
              if (!gateBit.has(p)) throw new Error('组件存在未建模的外部前置');
              mask |= gateBit.get(p);
              continue;
            }
            const j = index.get(p);
            if (!levels[j]) { levels[j] = 1; visit(j); }
          }
        }
        for (let i = 0; i < nodes.length; i++) if (levels[i]) visit(i);
        let cost = 0, value = 0;
        for (let i = 0; i < nodes.length; i++) {
          cost += nodeCost(nodes[i], levels[i]); value += score(nodes[i], levels[i]);
          if (isCore && levels[i]) mask |= gateBit.get(nodes[i].id) || 0;
        }
        const stateKey = mask + ':' + cost, prev = best.get(stateKey);
        if (!prev || value > prev.value) best.set(stateKey, { cost, value, mask, levels, nodes });
      }
      function walk(k) {
        if (k === objectives.length) { evaluate(); return; }
        const i = objectives[k];
        for (let lv = base[i]; lv <= nodes[i].values.length; lv++) { chosen[i] = lv; walk(k + 1); }
        chosen[i] = base[i];
      }
      walk(0);
      const states = Array.from(best.values()).sort((a, b) => a.mask - b.mask || a.cost - b.cost || b.value - a.value);
      const frontier = []; let mask = -1, last = -1;
      for (const state of states) {
        if (mask !== state.mask) { mask = state.mask; last = -1; }
        if (state.value > last) { frontier.push(state); last = state.value; }
      }
      optionCache.set(key, frontier);
      return frontier;
    }

    function prepare(request) {
      const talentLevels=talentLevelRules.normalize(request.talentLevels);
      if (!Number.isSafeInteger(request.budget) || request.budget < 0 || request.budget > 1000000) throw new Error('星宿点请输入0至1000000之间的整数');
      if (!Number.isInteger(request.capacity) || request.capacity < 0 || request.capacity > data.maxCapacity) throw new Error('天赋容量请输入0至' + data.maxCapacity + '之间的整数');
      if (!Array.isArray(request.talentIds)) throw new Error('目标天赋列表无效');
      const targets = Array.from(new Set(request.talentIds)).map(id => {
        if (!talentById.has(id)) throw new Error('所选天赋不属于当前可用大荒天赋，请重新选择');
        return talentById.get(id);
      });
      const fees = targets.reduce((v, t) => v + t.cost, 0);
      if (fees > request.capacity) throw new Error('所选天赋需要' + fees + '费，超出当前容量' + request.capacity + '费');
      const conflictGroups = new Set(targets.map(t => t.conflictGroup));
      for (const c of data.conflicts) {
        if (conflictGroups.has(c.id) && c.exclusive_group.some(id => conflictGroups.has(id))) throw new Error('所选天赋存在互斥，请调整太阴天赋选择');
      }
      const required = new Map();
      for (const t of targets) {
        const nodes = components.get(t.starId);
        if (!nodes || !nodes.length) throw new Error('目标天赋缺少关联节点');
        for (const n of nodes) {
          if (t.requiredLevel > n.values.length) throw new Error('天赋要求超过节点等级上限');
          required.set(n.id, Math.max(required.get(n.id) || 0, t.requiredLevel));
        }
      }
      const elementKeys = request.elementKeys === undefined ? [] : request.elementKeys;
      if (!Array.isArray(elementKeys)) throw new Error('元素属性选择无效');
      const elementTargets = Array.from(new Set(elementKeys)).map(key => {
        if (!elementByKey.has(key)) throw new Error('所选元素属性无效，请重新选择');
        return elementByKey.get(key);
      });
      const elementNodes = new Set();
      for (const option of elementTargets) for (const id of option.nodeIds) {
        const node = byId.get(id);
        if (!node || node.attrId !== option.attrId) throw new Error('元素属性关联不完整');
        required.set(id, node.values.length); elementNodes.add(id);
      }
      const elementHelper=createElementRules(data),elementRules=elementHelper.normalize(request.elementRules,elementKeys);
      const elementStars=elementHelper.normalizeStars(request.elementStars,elementKeys,elementRules),exactLevels=new Map();
      for(const item of elementStars){const star=elementHelper.stars.find(s=>s.id===item.starId);star.nodes.forEach((n,i)=>{exactLevels.set(n.id,item.levels[i]);elementNodes.add(n.id);if(item.levels[i])required.set(n.id,Math.max(required.get(n.id)||0,item.levels[i]));});}
      for(const rule of elementRules){const e=data.elements.find(e=>e.key===rule.key);for(const n of data.nodes)if(e.starIds.includes(n.starId))elementNodes.add(n.id);}
      const minimum = closure(required);
      return { targets, talentLevels, elementTargets, elementNodes, elementRules, elementStars, exactLevels, fees, required, minimum, minimumCost: costOf(minimum) };
    }

    function solve(request, progress = () => {}) {
      const start = Date.now(), prep = prepare(request);
      if(prep.elementRules.length||prep.elementStars.length)throw new Error('自定义元素目标需要联合求解');
      if (request.budget < prep.minimumCost) return { status: 'insufficient', minimumCost: prep.minimumCost, deficit: prep.minimumCost - request.budget, fees: prep.fees, budget: request.budget };
      const coreNodes = data.nodes.filter(n => coreIds.has(n.id)).sort((a, b) => a.id - b.id);
      const coreBest = new Map();
      for (let mask = 0; mask < (1 << data.gates.length); mask++) {
        for (const opt of enumerate(coreNodes, prep.required, mask, true)) {
          const key = opt.mask + ':' + opt.cost, prev = coreBest.get(key);
          if (!prev || opt.value > prev.value) coreBest.set(key, opt);
        }
      }
      const coreOptions = Array.from(coreBest.values());
      const groups = Array.from(components.values()).filter(ns => !coreIds.has(ns[0].id) && (ns.some(isObjective) || ns.some(n => prep.required.has(n.id))));
      const groupOptions = groups.map(ns => enumerate(ns, prep.required));
      const usefulMax = Math.max(...coreOptions.map(o => o.cost), 0) + groupOptions.reduce((sum, opts) => sum + Math.max(...opts.map(o => o.cost), 0), 0);
      const limit = Math.min(request.budget, usefulMax);
      let winner = null;
      const masks = Array.from(new Set(coreOptions.map(o => o.mask))).sort((a, b) => a - b);
      for (let mi = 0; mi < masks.length; mi++) {
        const mask = masks[mi], core = coreOptions.filter(o => o.mask === mask && o.cost <= limit);
        if (!core.length) continue;
        let dp = new Float64Array(limit + 1); dp.fill(-1);
        const coreChoice = new Int32Array(limit + 1); coreChoice.fill(-1);
        for (let i = 0; i < core.length; i++) if (core[i].value > dp[core[i].cost]) { dp[core[i].cost] = core[i].value; coreChoice[core[i].cost] = i; }
        const stages = []; let viable = true;
        for (let gi = 0; gi < groups.length; gi++) {
          const opts = groupOptions[gi].filter(o => (mask & o.mask) === o.mask && o.cost <= limit);
          if (!opts.length) { viable = false; break; }
          if (opts.length === 1 && opts[0].cost === 0) continue;
          const next = new Float64Array(limit + 1); next.fill(-1);
          const choice = new Int32Array(limit + 1), previous = new Int32Array(limit + 1); choice.fill(-1);
          for (let spent = 0; spent <= limit; spent++) {
            if (dp[spent] < 0) continue;
            for (let oi = 0; oi < opts.length; oi++) {
              const opt = opts[oi], total = spent + opt.cost;
              if (total > limit) continue;
              const value = dp[spent] + opt.value;
              if (value > next[total]) { next[total] = value; choice[total] = oi; previous[total] = spent; }
            }
          }
          dp = next; stages.push({ opts, choice, previous });
        }
        if (!viable) continue;
        let bestCost = -1, bestValue = -1;
        for (let c = 0; c <= limit; c++) if (dp[c] > bestValue) { bestValue = dp[c]; bestCost = c; }
        if (bestCost < 0 || (winner && (bestValue < winner.value || (bestValue === winner.value && bestCost >= winner.cost)))) continue;
        const levels = new Map(); let c = bestCost;
        function merge(opt) { opt.nodes.forEach((n, i) => { if (opt.levels[i]) levels.set(n.id, opt.levels[i]); }); }
        for (let s = stages.length - 1; s >= 0; s--) {
          const stage = stages[s], oi = stage.choice[c];
          if (oi < 0) throw new Error('加点方案回溯失败');
          merge(stage.opts[oi]); c = stage.previous[c];
        }
        const ci = coreChoice[c]; if (ci < 0) throw new Error('基础星宿回溯失败'); merge(core[ci]);
        winner = { value: bestValue, cost: bestCost, levels };
        progress(Math.round((mi + 1) * 100 / masks.length));
      }
      if (!winner) throw new Error('当前约束下没有可行方案');
      validate(winner.levels, request.budget, prep);
      return describe(winner, request, prep, Date.now() - start);
    }

    function validate(levels, budget, prep) {
      if (costOf(levels) > budget) throw new Error('方案耗点超出预算');
      for (const [id, lv] of levels) {
        const n = byId.get(id);
        if (!Number.isInteger(lv) || lv < 1 || lv > n.values.length || n.pre.some(p => !levels.get(p))) throw new Error('方案存在无效等级或未点亮的前置');
      }
      for (const [id, lv] of prep.required) if ((levels.get(id) || 0) < lv) throw new Error('方案未满足目标天赋或元素属性');
      for(const rule of createElementRules(data).summarize(prep.elementRules||[],levels))if(rule.mode==='points'?rule.spent>rule.value:rule.attack<rule.value)throw new Error('方案未满足元素点数上限或攻击目标');
      for(const [id,level]of prep.exactLevels||[])if((levels.get(id)||0)!==level)throw new Error('方案未保留元素星宿的指定等级');
    }

    function describe(winner, request, prep, milliseconds, objective = null) {
      const levels = winner.levels, targets = new Set(prep.targets.map(t => t.id));
      const targetStars = new Set(prep.targets.map(t => t.starId));
      for (const id of prep.elementNodes) targetStars.add(byId.get(id).starId);
      const rowOf = n => n.row || components.get(n.starId).indexOf(n) + 1;
      const locate = n => {
        const star = starById.get(n.starId);
        return (star.weapon ? star.weapon + '（' + star.name + '）' : star.name) + '第' + rowOf(n) + '行·' + n.attribute;
      };
      const pending = new Set(levels.keys()), done = new Set(), steps = [], powerTotals = new Map(); let cumulative = 0;
      while (pending.size) {
        const ready = Array.from(pending).filter(id => byId.get(id).pre.every(p => done.has(p))).sort((a, b) => {
          const rank = id => coreIds.has(id) ? 0 : targetStars.has(byId.get(id).starId) ? 1 : 2;
          const an = byId.get(a), bn = byId.get(b);
          return rank(a) - rank(b) || an.starId - bn.starId || rowOf(an) - rowOf(bn) || a - b;
        });
        if (!ready.length) throw new Error('加点顺序存在循环或缺失前置');
        const id = ready[0], n = byId.get(id), level = levels.get(id), cost = nodeCost(n, level); cumulative += cost;
        const reason = prep.elementNodes.has(id) ? '元素属性目标' : prep.required.has(id) ? '目标天赋' : prep.minimum.has(id) ? '目标前置' : n.attrId === critId ? '暴击收益' : n.attrId === attackId ? '攻击收益' : '收益前置';
        const parameters = data.power?.parameters[n.attrId], baseValue = powerTotals.get(n.attrId) || 0;
        const levelGains = Array.from({ length: level }, (_, i) => {
          const value = n.values[i] - (i ? n.values[i - 1] : 0);
          const powerInputBefore = baseValue + (i ? n.values[i - 1] : 0), powerInputAfter = baseValue + n.values[i];
          const powerDelta = parameters?.length ? resourceScore(parameters, powerInputAfter) - resourceScore(parameters, powerInputBefore) : null;
          return { from: i, to: i + 1, value, cost: n.costs[i], powerDelta, powerInputBefore, powerInputAfter };
        });
        powerTotals.set(n.attrId, baseValue + n.values[level - 1]);
        steps.push({ id, name: n.name, row: rowOf(n), starId: n.starId, star: starById.get(n.starId).name, family: starById.get(n.starId).family, location: starById.get(n.starId).location || '', level, cost, cumulative, attribute: n.attribute, attrId: n.attrId, value: n.values[level - 1], levelGains, reason, pre: n.pre.map(p => locate(byId.get(p))) });
        pending.delete(id); done.add(id);
      }
      const summaries = [];
      for (const star of data.stars) {
        const own = steps.filter(s => s.starId === star.id); if (!own.length) continue;
        const nodes = components.get(star.id).slice().sort((a, b) => rowOf(a) - rowOf(b)).map(n => {
          const level = levels.get(n.id) || 0;
          return { id: n.id, row: rowOf(n), attribute: n.attribute, level, cost: nodeCost(n, level) };
        });
        summaries.push({ id: star.id, name: star.name, family: star.family, cost: own.reduce((v, s) => v + s.cost, 0), crit: own.filter(s => s.attrId === critId).reduce((v, s) => v + s.value, 0), attack: own.filter(s => s.attrId === attackId).reduce((v, s) => v + s.value, 0), nodes });
      }
      const unlocked = data.talents.filter(t => components.get(t.starId).every(n => (levels.get(n.id) || 0) >= t.requiredLevel)).map(t => ({ id: t.id, starId: t.starId, name: starById.get(t.starId).name, quality: t.quality, cost: t.cost, selected: targets.has(t.id), effects: t.effects, equippedLevel:talentLevelRules.level(t.id,prep.talentLevels) }));
      const crit = steps.filter(s => s.attrId === critId).reduce((v, s) => v + s.value, 0);
      const attack = steps.filter(s => s.attrId === attackId).reduce((v, s) => v + s.value, 0);
      const penetration = steps.filter(s => s.attrId === 2016).reduce((v, s) => v + s.value, 0);
      const powerReference = Array.from(powerTotals).reduce((sum, [id, value]) => sum + resourceScore(data.power?.parameters[id], value), 0);
      const elementBenefits = (data.elements || []).map(element => ({ name: element.name, values: element.options.map(option => ({ name: option.name, value: steps.filter(s => s.attrId === option.attrId && element.starIds.includes(s.starId)).reduce((sum, s) => sum + s.value, 0) })).filter(item => item.value > 0) })).filter(element => element.values.length > 0);
      if ((objective ? objective.evaluate(levels) : crit * weight + attack) !== winner.value || cumulative !== winner.cost) throw new Error('方案汇总与优化结果不一致');
      return { status: 'optimal', strategy: request.strategy || 'crit', talentLevels:prep.talentLevels, objective: objective ? objective.description : '暴击优先，其次攻击，同收益时少耗点', budget: request.budget, spent: cumulative, remaining: request.budget - cumulative, minimumCost: prep.minimumCost, crit, attack, penetration, powerReference, fees: prep.fees, capacity: request.capacity, steps, stars: summaries, unlocked, targetIds: Array.from(targets), elementTargets: prep.elementTargets.map(option => ({ key: option.key, name: option.name })), elementBenefits, ...(prep.elementStars.length?{elementStars:prep.elementStars,elementStarResults:createElementRules(data).summarizeStars(prep.elementStars)}:{}), ...(prep.elementRules.length?{elementRules:prep.elementRules,elementRuleResults:createElementRules(data).summarize(prep.elementRules,levels)}:{}), levels: Object.fromEntries(levels), milliseconds, sourceSha256: data.sourceSha256 };
    }
    return { solve, prepare, validate, describe, weight, resourceScore };
  }

  if (typeof module !== 'undefined' && module.exports) module.exports = { createPlannerEngine };
  root.createPlannerEngine = createPlannerEngine;
})(globalThis);
