/* 元素局部目标与大荒优先规则分阶段精确求解，不固定局部节点组合。 */
(function(root){
  'use strict';
  function createElementGoalEngine(data,createBase,optimizer){
    const base=createBase(data),rules=createElementRules(data),byId=new Map(data.nodes.map(n=>[n.id,n])),talentLevels=createTalentLevelRules(data);
    const variable=(id,level)=>'n'+id+'L'+level;
    const expression=terms=>terms.filter(([v])=>v!==0).map(([v,n])=>(v<0?' - ':' + ')+Math.abs(v)+' '+n).join('').replace(/^ \+ /,'')||'0 '+variable(data.nodes[0].id,1);
    function solve(request,progress=()=>{}){
      const started=Date.now(),prep=base.prepare(request),custom=prep.elementRules,strategy=request.strategy||'crit',power=strategy==='power';
      if(!['crit','crit-target','attack-pen','power','pvp'].includes(strategy))throw new Error('优先规则无效');
      const pvp=strategy==='pvp'?createPvpRules().normalize(request.pvp):null;
      const pvpObjectiveIds=pvp?pvp.attrIds.filter(id=>pvp.weights[id]>0).sort((a,b)=>pvp.weights[b]-pvp.weights[a]):[];
      if(pvp&&(!Array.isArray(data.pvpLifeNodeIds)||new Set(data.pvpLifeNodeIds).size!==data.pvpLifeNodeIds.length))throw new Error('PVP生命优选数据未能加载，请重新打开应用');
      if(!optimizer)throw new Error('本机元素计算组件尚未加载');
      const binary=[],integers=[],bounds=[],constraints=[],spend=[],attributes=new Map(),nodeTerms=new Map(),objective=[],bonuses=new Map();
      const slotLimit=data.talentPower?data.talentPower.baseSlots+data.talentPower.extraSlotRules.filter(r=>request.capacity>=r.cur_max).reduce((s,r)=>s+r.extra_config_limit,0):data.talents.length;
      if(power&&prep.targets.length>slotLimit)throw new Error('自选携带数量超过上限'+slotLimit+'项');
      function constraint(terms,sign,value){constraints.push(' c'+constraints.length+': '+expression(terms)+' '+sign+' '+value);}
      for(const n of data.nodes){
        const terms=[];nodeTerms.set(n.id,terms);
        n.values.forEach((value,i)=>{
          const name=variable(n.id,i+1),gain=value-(i?n.values[i-1]:0);
          if(!Number.isSafeInteger(gain)||!Number.isSafeInteger(n.costs[i]))throw new Error('节点数值超出精确计算范围');
          binary.push(name);spend.push([n.costs[i],name]);terms.push([gain,name]);
          if(!attributes.has(n.attrId))attributes.set(n.attrId,[]);attributes.get(n.attrId).push([gain,name]);
          if(i)constraint([[1,name],[-1,variable(n.id,i)]],'<=',0);
        });
        for(const id of n.pre)constraint([[1,variable(n.id,1)],[-1,variable(id,1)]],'<=',0);
        if(prep.required.has(n.id))constraint([[1,variable(n.id,prep.required.get(n.id))]],'=',1);
        if(prep.exactLevels.has(n.id)&&prep.exactLevels.get(n.id)<n.values.length)constraint([[1,variable(n.id,prep.exactLevels.get(n.id)+1)]],'=',0);
      }
      const attr=id=>attributes.get(id)||[];
      const local=[];
      for(const rule of custom){
        const e=data.elements.find(e=>e.key===rule.key),nodes=data.nodes.filter(n=>e.starIds.includes(n.starId));
        const terms=label=>nodes.filter(n=>n.attrId===e.options.find(o=>o.label===label)?.attrId).flatMap(n=>nodeTerms.get(n.id));
        const attack=terms('攻击'),penetration=terms('防御穿透');
        if(rule.mode==='attack')constraint(attack,'>=',rule.value);
        else{
          constraint(nodes.flatMap(n=>n.costs.map((cost,i)=>[cost,variable(n.id,i+1)])),'<=',rule.value);
          local.push({rule,attack,penetration});
        }
      }
      if(strategy==='crit-target'){
        const maximum=data.nodes.filter(n=>n.attrId===data.objective.crit).reduce((s,n)=>s+Math.max(...n.values),0);
        if(!Number.isSafeInteger(request.critTarget)||request.critTarget<0||request.critTarget>1000000)throw new Error('暴击目标请输入0至1000000之间的整数');
        if(request.critTarget>maximum)throw new Error('暴击目标超过全部星宿上限，最多可提供+'+maximum+'点暴击');
        constraint(attr(data.objective.crit),'>=',request.critTarget);
      }
      if(power){
        for(const [id,terms]of attributes){
          const p=data.power?.parameters[id];if(!p?.length)continue;
          const numerator=p[0],denominator=p.length===1?1:p[1],name='a'+id;
          if(!Number.isSafeInteger(numerator)||!Number.isSafeInteger(denominator)||numerator<0||denominator<=0)throw new Error('属性计分参数无效');
          integers.push(name);objective.push([1,name]);bounds.push(' 0 <= '+name+' <= '+base.resourceScore(p,terms.reduce((s,[v])=>s+Math.max(0,v),0)));
          constraint([[denominator,name],...terms.map(([v,n])=>[-numerator*v,n])],'<=',0);
        }
        if(data.talentPower){
          for(const t of data.talents){
            if(!Array.isArray(t.power)||t.power.length!==t.effects.length||!t.power.every(v=>Number.isSafeInteger(v)&&v>=0))throw new Error('天赋战力配置缺失');
            const name='t'+t.id,score=t.power[talentLevels.level(t.id,prep.talentLevels)-1],nodes=data.nodes.filter(n=>n.starId===t.starId);
            if(!nodes.length||nodes.some(n=>t.requiredLevel>n.values.length))throw new Error('天赋解锁等级异常');
            binary.push(name);bonuses.set(t.id,score);objective.push([score,name]);
            for(const n of nodes)constraint([[1,name],[-1,variable(n.id,t.requiredLevel)]],'<=',0);
          }
          for(const t of prep.targets)constraint([[1,'t'+t.id]],'=',1);
          constraint(data.talents.map(t=>[t.cost,'t'+t.id]),'<=',request.capacity);
          constraint(data.talents.map(t=>[1,'t'+t.id]),'<=',slotLimit);
          for(let i=0;i<data.talents.length;i++)for(let j=i+1;j<data.talents.length;j++){
            const a=data.talents[i],b=data.talents[j];
            if(data.conflicts.some(c=>(c.id===a.conflictGroup&&c.exclusive_group.includes(b.conflictGroup))||(c.id===b.conflictGroup&&c.exclusive_group.includes(a.conflictGroup))))constraint([[1,'t'+a.id],[1,'t'+b.id]],'<=',1);
          }
        }
      }
      const model=(direction,terms)=>[direction,' goal: '+expression(terms),'Subject To',...constraints,...(bounds.length?['Bounds',...bounds]:[]),...(integers.length?['Generals',integers.join(' ')]:[]),'Binaries',binary.join(' '),'End'].join('\n');
      const settings={output_flag:false,presolve:'on',mip_rel_gap:0,mip_abs_gap:0,mip_feasibility_tolerance:1e-8,time_limit:120};
      function optimize(direction,terms,allowInfeasible=false){
        const result=optimizer.solve(model(direction,terms),settings);
        if(allowInfeasible&&result.Status==='Infeasible')return null;
        if(result.Status!=='Optimal')throw new Error(result.Status==='Infeasible'?'元素目标与所选天赋无法同时满足，请调整配置':'元素联合计算尚未完成，未生成最优方案，可重试或取消');
        if(!Number.isFinite(result.ObjectiveValue)||Math.abs(result.ObjectiveValue-Math.round(result.ObjectiveValue))>0.00001)throw new Error('求解目标未通过整数校验');
        return result;
      }
      function maximize(terms){const best=Math.round(optimize('Maximize',terms).ObjectiveValue);constraint(terms,'=',best);return best;}
      // 元素盘互不重叠，局部最优值先固定；公共前置不占元素上限，仍参与下面的总耗点检查。
      for(const item of local){item.highestAttack=maximize(item.attack);item.highestPenetration=maximize(item.penetration);}
      progress(20);
      const minimumCost=Math.round(optimize('Minimize',spend).ObjectiveValue);
      if(request.budget<minimumCost)return {status:'insufficient',minimumCost,deficit:minimumCost-request.budget,fees:prep.fees,budget:request.budget,...(strategy==='crit-target'?{critTarget:request.critTarget}:{}),elementRules:custom};
      constraint(spend,'<=',request.budget);progress(40);
      let pvpResult,pvpFraction;
      if(pvp){
        // 生命优选受同一总预算限制，不强制七节点满级，也不预先锁死某个节点组合。
        const lifeNodes=(data.pvpLifeNodeIds||[]).map(id=>byId.get(id));
        if(lifeNodes.some(n=>!n||n.attrId!==2001))throw new Error('PVP高收益生命节点数据不完整');
        const life=lifeNodes.length?maximize(lifeNodes.flatMap(n=>nodeTerms.get(n.id))):0;
        // 每项分母都在同一预算、天赋及元素约束下单独最大化，保留完整前置成本。
        const maxima=pvp.attrIds.map(id=>Math.round(optimize('Maximize',attr(id)).ObjectiveValue));
        const reachable=pvp.attrIds.map((id,i)=>({id,maximum:maxima[i],weight:Math.round(pvp.weights[id]*100)})).filter(a=>a.maximum>0&&a.weight>0);
        const maximumWeight=Math.max(0,...reachable.map(a=>a.weight));
        let fraction=null;
        if(reachable.length){
          const anchor=constraints.length;
          // 权重扩大目标比例；用整数分数和交叉乘积精确比较，避免小数权重的浮点误判。
          const fractions=[[0,1]];
          for(const a of reachable){const denominator=a.maximum*a.weight;if(!Number.isSafeInteger(denominator))throw new Error('PVP权重超出精确计算范围');for(let value=1;value<=a.maximum;value++)fractions.push([value,denominator]);}
          const compare=(a,b)=>{const x=BigInt(a[0])*BigInt(b[1]),y=BigInt(b[0])*BigInt(a[1]);return x<y?-1:x>y?1:0;};
          const minimum=(f,a)=>Number((BigInt(f[0])*BigInt(a.maximum*a.weight)+BigInt(f[1])-1n)/BigInt(f[1]));
          fractions.sort(compare);const candidates=fractions.filter((f,i)=>!i||compare(f,fractions[i-1])!==0);
          let low=0,high=candidates.length;
          while(low+1<high){
            const mid=Math.floor((low+high)/2),f=candidates[mid];
            for(const a of reachable)constraint(attr(a.id),'>=',minimum(f,a));
            const feasible=optimize('Minimize',[[0,binary[0]]],true);constraints.splice(anchor);
            if(feasible)low=mid;else high=mid;
          }
          fraction=candidates[low];
          for(const a of reachable)constraint(attr(a.id),'>=',minimum(fraction,a));
        }
        pvpFraction=fraction;
        pvpResult={...pvp,balance:fraction?fraction[0]*maximumWeight/fraction[1]:null,attributes:pvp.attrIds.map((id,i)=>({attrId:id,name:createPvpRules().attributes.find(a=>a.id===id).name,weight:pvp.weights[id],maximum:maxima[i]})),life:{value:life,available:lifeNodes.length,nodes:[]}};
      }
      // 同均衡率先优化高权重属性，权重相同沿用界面顺序；零权重不参与择优。
      const objectives=pvp?pvpObjectiveIds.map(attr):power?[objective]:strategy==='crit-target'?[attr(data.objective.attack)]:strategy==='attack-pen'?[attr(data.objective.attack),attr(2016),attr(data.objective.crit)]:[attr(data.objective.crit),attr(data.objective.attack)];
      const best=objectives.map(maximize);progress(80);
      const solved=optimize('Minimize',spend);
      function integer(name){const value=solved.Columns[name]?.Primal,rounded=Math.round(value);if(!Number.isFinite(value)||Math.abs(value-rounded)>0.000001||(rounded!==0&&rounded!==1))throw new Error('节点或携带状态未通过整数校验');return rounded;}
      const levels=new Map();let spent=0;
      for(const n of data.nodes){let level=0;for(let i=0;i<n.values.length;i++)if(integer(variable(n.id,i+1))){if(level!==i)throw new Error('节点升级顺序无效');level++;spent+=n.costs[i];}if(level)levels.set(n.id,level);}
      const automatic=power&&!!data.talentPower,ids=automatic?data.talents.filter(t=>integer('t'+t.id)).map(t=>t.id):prep.targets.map(t=>t.id);
      if(automatic&&(ids.length>slotLimit||prep.targets.some(t=>!ids.includes(t.id))))throw new Error('携带天赋未通过复核');
      const finalRequest={...request,talentIds:ids},finalPrep=base.prepare(finalRequest);base.validate(levels,request.budget,finalPrep);
      const totals=rows=>{const result=new Map();for(const [id,lv]of rows){const n=byId.get(id);result.set(n.attrId,(result.get(n.attrId)||0)+n.values[lv-1]);}return result;};
      const total=totals(levels),nodeScore=rows=>[...totals(rows)].reduce((s,[id,v])=>s+base.resourceScore(data.power?.parameters[id],v),0),talentScore=automatic?ids.reduce((s,id)=>s+bonuses.get(id),0):0;
      const actual=pvp?pvpObjectiveIds.map(id=>total.get(id)||0):power?[nodeScore(levels)+talentScore]:strategy==='crit-target'?[total.get(data.objective.attack)||0]:strategy==='attack-pen'?[total.get(data.objective.attack)||0,total.get(2016)||0,total.get(data.objective.crit)||0]:[total.get(data.objective.crit)||0,total.get(data.objective.attack)||0];
      if(actual.some((v,i)=>v!==best[i])||spent!==Math.round(solved.ObjectiveValue)||strategy==='crit-target'&&(total.get(data.objective.crit)||0)<request.critTarget)throw new Error('元素联合方案复核不一致');
      const summaries=rules.summarize(custom,levels);
      for(const item of local){const s=summaries.find(s=>s.key===item.rule.key);if(s.attack!==item.highestAttack||s.penetration!==item.highestPenetration)throw new Error('元素局部最优值复核不一致');}
      const descriptions={crit:'暴击优先，其次攻击，同收益少耗点','attack-pen':'攻击最高，其次穿透、暴击，同收益少耗点','crit-target':'暴击至少+'+request.critTarget+'后攻击最高，同收益少耗点',power:'比较节点与账号所填等级天赋的合计分，得分相同时优先省点',pvp:'先在可用点数内选好生命节点，再按权重分配其余属性。均衡度相同先照顾高权重，收益相同先节省点数；配点结果不能直接代表伤害最优。'};
      const result=base.describe({levels,value:actual[0],cost:spent},finalRequest,finalPrep,Date.now()-started,{evaluate:power?rows=>nodeScore(rows)+talentScore:rows=>totals(rows).get(pvp?pvpObjectiveIds[0]:strategy==='crit'?data.objective.crit:data.objective.attack)||0,description:descriptions[strategy]});
      result.minimumCost=minimumCost;if(strategy==='crit-target')result.critTarget=request.critTarget;
      if(pvpResult){
        pvpResult.life.nodes=(data.pvpLifeNodeIds||[]).filter(id=>levels.has(id)).map(id=>{const n=byId.get(id),level=levels.get(id),star=data.stars.find(s=>s.id===n.starId);return {id,starId:n.starId,name:star.name,row:n.row,level,value:n.values[level-1],cost:n.costs.slice(0,level).reduce((s,c)=>s+c,0)};});
        if(pvpResult.life.nodes.reduce((s,n)=>s+n.value,0)!==pvpResult.life.value)throw new Error('PVP生命优选收益复核不一致');
        for(const a of pvpResult.attributes){a.value=total.get(a.attrId)||0;a.ratio=a.maximum?a.value/a.maximum:null;if(a.value>a.maximum||pvpFraction&&a.maximum&&a.weight>0&&BigInt(a.value)*BigInt(pvpFraction[1])<BigInt(pvpFraction[0])*BigInt(a.maximum*Math.round(a.weight*100)))throw new Error('PVP均衡方案复核不一致');}
        result.pvpResult=pvpResult;
      }
      if(automatic){result.nodePowerReference=result.powerReference;result.talentPowerReference=talentScore;result.powerReference+=talentScore;result.autoTalents=true;result.carryLimit=slotLimit;result.pinnedTalentIds=prep.targets.map(t=>t.id);for(const t of result.unlocked){t.power=bonuses.get(t.id);t.pinned=result.pinnedTalentIds.includes(t.id);}}
      progress(100);return result;
    }
    return {solve};
  }
  if(typeof module!=='undefined'&&module.exports)module.exports={createElementGoalEngine};
  root.createElementGoalEngine=createElementGoalEngine;
})(globalThis);
