/* 日志仅在用户点击时提交，失败沿用同一编号与内容，用户界面不展示诊断正文。 */
(() => {
  'use strict';
  const core=DiagnosticCore,store=core.createStore({getItem:key=>localStorage.getItem(key),setItem:(key,value)=>localStorage.setItem(key,value)}),pendingKey='wutong-diagnostic-pending-v1',sentKey='wutong-diagnostic-sent-v1';let sending=false,pendingMemory=null,sentMemory='';
  function record(module,error,code){try{store.record(module,error,code);}catch{}}
  function sentBody(){if(sentMemory)return sentMemory;try{return localStorage.getItem(sentKey)||'';}catch{return '';}}
  function pendingReport(){
    let pending=pendingMemory;
    if(!pending)try{const saved=JSON.parse(localStorage.getItem(pendingKey)||'null');if(saved&&/^[a-f0-9-]{36}$/.test(saved.id))pending={id:saved.id,body:core.sanitizeReport(saved.body)};}catch{}
    return pending&&pending.body!==sentBody()?pending:null;
  }
  function collect(){
    let native={};try{if(typeof globalThis.AndroidPlanner?.getDiagnosticLogs==='function')native=JSON.parse(AndroidPlanner.getDiagnosticLogs());}catch(error){record('app',error,'DATA_RESTORE');}
    const version=document.querySelector('.version-row span')?.textContent.match(/^\d+\.\d+\.\d+/)?.[0]||'unknown';
    return core.report({appVersion:native.versionName||version,versionCode:native.versionCode,dataId:globalThis.STAR_DATA?.sourceSha256?.slice(0,16)},[...(Array.isArray(native.events)?native.events:[]),...store.read()]);
  }
  // 打开入口只展示复现指引；确认时采集最新异常，失败重试仍保留原编号和正文。
  function open(){
    if(sending)return;const dialog=document.getElementById('diagnostic-dialog');
    const pending=!!pendingReport();
    document.getElementById('diagnostic-retry-hint').textContent=pending?'上次提交尚未确认，本次将重试上次日志。确认成功后，可再次提交新复现的异常。':'';
    document.getElementById('diagnostic-confirm').textContent=pending?'重试上次提交':'已复现，提交日志';dialog.showModal();
  }
  async function submit(){
    if(sending)return;sending=true;const buttons=[...document.querySelectorAll('[data-submit-diagnostics],#diagnostic-confirm')];buttons.forEach(b=>b.disabled=true);
    const status=document.getElementById('diagnostic-status'),notice=text=>{if(status)status.textContent=text;globalThis.PlannerApp?.toast(text);};
    try{
      let pending=pendingReport();
      if(!pending){const body=collect();if(sentBody()===body){notice('这份日志已提交，可在“我的记录”查看处理进度');return;}pending={id:crypto.randomUUID(),body};}
      // 存储不可写时仍可提交，并在当前会话复用同一份待确认日志。
      pendingMemory=pending;try{localStorage.setItem(pendingKey,JSON.stringify(pending));}catch{}
      notice('正在提交日志…');await CommunityUI.submitDiagnostic(pending.id,pending.body);
      sentMemory=pending.body;pendingMemory=null;try{localStorage.setItem(sentKey,pending.body);sentMemory='';}catch{}try{localStorage.removeItem(pendingKey);}catch{}notice('日志已提交，可在“我的记录”查看处理进度');
    }catch{notice('日志未确认提交成功，请检查网络后重试');}finally{sending=false;buttons.forEach(b=>b.disabled=false);}
  }
  globalThis.Diagnostics={record,submit:open,back(){const dialog=document.getElementById('diagnostic-dialog');if(!dialog?.open)return false;dialog.close();return true;}};
  window.addEventListener('error',event=>{
    // WebView未提供stack时，仍可从ErrorEvent取得脚本位置。
    const error=event.error;
    const value=error?.stack?error:{name:error?.name||'Error',message:error?.message||event.message,stack:(event.filename||'')+':'+event.lineno+':'+event.colno};
    record(core.moduleFor(value,document.body?.dataset.page),value);
  });
  window.addEventListener('unhandledrejection',event=>record(core.moduleFor(event.reason,document.body?.dataset.page),event.reason));
  document.addEventListener('click',event=>{
    if(event.target.closest('[data-submit-diagnostics]'))open();
    else if(event.target.closest('#diagnostic-confirm')){document.getElementById('diagnostic-dialog').close();submit();}
    else if(event.target.closest('#diagnostic-reproduce')){document.getElementById('diagnostic-dialog').close();document.getElementById('about')?.close();}
  });
})();
