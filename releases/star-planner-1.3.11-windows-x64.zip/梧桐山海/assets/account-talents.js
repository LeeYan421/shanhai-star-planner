/* 星系单击进入；等级直接写入本机账号配置，拖动只更新星盘图层。 */
(()=>{
  'use strict';
  const data=STAR_DATA,store=AccountTalentLevels,$=id=>document.getElementById(id),esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const talents=new Map(data.talents.map(t=>[t.id,t])),stars=data.stars.filter(s=>s.talentIds.some(id=>talents.has(id))),families=[...new Set(stars.map(s=>s.family))];
  const state={family:null,focusFamily:null,star:stars[0].id,talent:stars[0].talentIds.find(id=>talents.has(id)),zoom:1,x:0,y:0},pointers=new Map();
  const stage=$('account-star-stage'),nodeLayer=$('account-star-nodes'),lines=$('account-star-lines');
  let levels={},mapKey,items=[],drag=null,pinch=0,suppressClick=false,frame=0;
  const star=()=>stars.find(s=>s.id===state.star);
  const quality=t=>({3:'绿色',4:'紫色',5:'红色'})[t.quality]||'通用';
  function read(){try{levels=store.get();$('account-talent-status').textContent='';return true;}catch(error){globalThis.Diagnostics?.record('talents',error,'DATA_RESTORE');$('account-talent-status').textContent=error.message;return false;}}
  function transform(){
    stage.style.setProperty('--pan-x',state.x+'px');stage.style.setProperty('--pan-y',state.y+'px');stage.style.setProperty('--map-zoom',String(state.zoom));
    $('account-map-minus').disabled=state.zoom<=1;$('account-map-plus').disabled=state.zoom>=3;
  }
  function schedule(){if(!frame)frame=requestAnimationFrame(()=>{frame=0;transform();});}
  function syncView(){
    $('talents-view').classList.toggle('has-family',!!state.family);$('account-talent-panel').hidden=!state.family;
    $('account-page-title').textContent=state.family||'账号天赋';$('account-map-help').textContent=state.family?'选择星宿 · 直接修改等级':'选择星系';
  }
  function selectMarker(){
    nodeLayer.querySelectorAll('button').forEach(button=>{const selected=state.family?Number(button.dataset.accountStar)===state.star:button.dataset.accountFamily===state.focusFamily;button.classList.toggle('is-selected',selected);button.setAttribute('aria-pressed',String(selected));});
  }
  function buildMap(){
    const key=state.family||'all';if(mapKey===key){selectMarker();return;}mapKey=key;
    items=state.family?stars.filter(s=>s.family===state.family).map(s=>({id:s.id,x:s.x,y:s.y,title:s.name,star:s})):families.map(family=>{const s=stars.find(s=>s.family===family);return {id:family,x:s.familyX,y:s.familyY,title:family.replace(/之魂|之星/g,''),star:s};});
    nodeLayer.innerHTML=items.map(n=>'<button type="button" class="account-star-node '+(state.family?'':'is-family')+'" '+(state.family?'data-account-star="'+n.id+'"':'data-account-family="'+esc(n.id)+'"')+' aria-label="'+esc(n.title+(state.family?' '+n.star.weapon:''))+'"><span class="account-star-emblem">'+(state.family?AccountTalentArt.icon(n.star):AccountTalentArt.family(n.id))+'</span><strong>'+esc(n.title)+'</strong></button>').join('');
    selectMarker();
    if(!matchMedia('(prefers-reduced-motion: reduce)').matches)nodeLayer.animate([{opacity:.3},{opacity:1}],{duration:140,easing:'ease-out'});
  }
  function layoutMap(){
    const width=stage.clientWidth,height=stage.clientHeight;if(!width||!height||!items.length)return;
    let points,size;
    if(!state.family){
      const cellWidth=(width-32)/3,cellHeight=(height-94)/3;
      size=Math.max(24,Math.min(170,cellWidth*.66,cellHeight-30));
      points=items.map(n=>({x:16+(Math.max(0,Math.min(2,Math.round(n.x/30)+1))+.5)*cellWidth,y:56+(Math.max(0,Math.min(2,Math.round(n.y/30)+1))+.5)*cellHeight}));
      lines.innerHTML='';
    }else{
      const xs=items.map(n=>n.x),ys=items.map(n=>n.y),minX=Math.min(...xs),minY=Math.min(...ys),rangeX=Math.max(1,Math.max(...xs)-minX),rangeY=Math.max(1,Math.max(...ys)-minY);
      const maxSize=Math.min(112,Math.max(30,(height-96)/3-26)),padX=maxSize/2+16,top=64+maxSize/2,bottom=height-56-maxSize/2;
      const project=n=>({x:padX+(n.x-minX)/rangeX*Math.max(1,width-padX*2),y:top+(n.y-minY)/rangeY*Math.max(1,bottom-top)});
      points=items.map(project);
      let distance=Infinity;for(let i=0;i<points.length;i++)for(let j=i+1;j<points.length;j++)distance=Math.min(distance,Math.max(Math.abs(points[i].x-points[j].x),Math.abs(points[i].y-points[j].y)));
      let center=project({x:star().familyX,y:star().familyY});
      if(distance<58){
        // 低高度或窄窗口将拥挤星宿按原方位分行，保证图标与触控区分开。
        const columns=items.length<=4?2:3,rows=Math.ceil(items.length/columns),cw=(width-32)/columns,ch=(height-94)/rows,ordered=items.map((n,i)=>({...n,index:i})).sort((a,b)=>a.y-b.y);
        points=[];for(let row=0;row<rows;row++){const group=ordered.slice(row*columns,(row+1)*columns).sort((a,b)=>a.x-b.x);group.forEach((n,column)=>points[n.index]={x:16+(column+(columns-group.length)/2+.5)*cw,y:56+(row+.5)*ch});}
        size=Math.max(24,Math.min(maxSize,ch-30,cw-24));center={x:width/2,y:(height+18)/2};
      }else size=Math.max(26,Math.min(maxSize,distance-30));
      lines.innerHTML=points.map(p=>'<path d="M'+center.x+','+center.y+' L'+p.x+','+p.y+'"/>').join('');
    }
    lines.setAttribute('viewBox','0 0 '+width+' '+height);
    [...nodeLayer.children].forEach((node,i)=>{node.style.left=points[i].x+'px';node.style.top=points[i].y+'px';node.style.setProperty('--emblem-size',size+'px');node.style.width=Math.max(52,size+12)+'px';});
    transform();
  }
  function updateLevels(){
    $('account-talent-list').querySelectorAll('[data-account-talent]').forEach(row=>{
      const id=Number(row.dataset.accountTalent),level=store.rules.level(id,levels);
      row.querySelector('.account-talent-current').textContent='Lv.'+level;
      row.querySelectorAll('[data-account-level]').forEach(button=>{const selected=Number(button.dataset.accountLevel)===level;button.classList.toggle('is-selected',selected);button.setAttribute('aria-pressed',String(selected));});
    });
  }
  function renderPanel(){
    const selected=star();$('account-star-title').textContent=selected.name;$('account-star-weapon').textContent=selected.weapon;
    $('account-save-state').textContent='自动保存';
    $('account-talent-list').innerHTML=selected.talentIds.filter(id=>talents.has(id)).map(id=>{
      const t=talents.get(id),label=quality(t)+'天赋',max=store.rules.maxLevel(id);
      return '<section class="account-talent q'+t.quality+'" data-account-talent="'+id+'" aria-label="'+esc(selected.name+' '+label)+'"><div class="account-talent-label"><span class="account-talent-frame">'+AccountTalentArt.icon(selected,t.quality)+'</span><strong>'+label+'</strong><span class="account-talent-current"></span></div><div class="account-level-choices" role="group" aria-label="'+esc(label+'等级')+'">'+Array.from({length:max},(_,i)=>'<button type="button" data-account-talent-level="'+id+'" data-account-level="'+(i+1)+'" aria-label="'+esc(selected.name+' '+label+' '+(i+1)+'级')+'">'+(i+1)+'</button>').join('')+'</div></section>';
    }).join('');
    $('account-talent-panel').scrollTop=0;updateLevels();
  }
  function render(){if(!read())return;syncView();buildMap();renderPanel();layoutMap();}
  function fit(){state.zoom=1;state.x=state.y=0;transform();}
  function enterFamily(family){
    state.family=state.focusFamily=family;
    if(star().family!==family){const selected=stars.find(s=>s.family===family);state.star=selected.id;state.talent=selected.talentIds.find(id=>talents.has(id));}
    $('account-talent-status').textContent='';syncView();buildMap();renderPanel();fit();layoutMap();
  }
  function back(){
    if($('account-reset-dialog').open){$('account-reset-dialog').close();return true;}
    if(state.family){state.family=null;syncView();buildMap();fit();layoutMap();return true;}return false;
  }
  function save(id,level){
    state.talent=id;
    try{levels=store.save({...levels,[id]:level});updateLevels();$('account-save-state').textContent='已保存';$('account-talent-status').textContent='';document.dispatchEvent(new CustomEvent('account-talents-changed'));}
    catch(error){globalThis.Diagnostics?.record('talents',error,'DATA_SAVE');$('account-talent-status').textContent=error.message;updateLevels();}
  }
  nodeLayer.addEventListener('click',event=>{
    if(suppressClick){suppressClick=false;return;}
    const family=event.target.closest('[data-account-family]'),button=event.target.closest('[data-account-star]');
    if(family)enterFamily(family.dataset.accountFamily);
    if(button){state.star=Number(button.dataset.accountStar);state.talent=star().talentIds.find(id=>talents.has(id));$('account-talent-status').textContent='';selectMarker();renderPanel();}
  });
  $('account-talent-list').addEventListener('click',event=>{const button=event.target.closest('[data-account-level]');if(button)save(Number(button.dataset.accountTalentLevel),Number(button.dataset.accountLevel));});
  $('account-map-back').onclick=()=>{if(!back())PlannerApp.route('home');};$('account-map-fit').onclick=fit;
  function zoom(factor){state.zoom=Math.max(1,Math.min(3,state.zoom*factor));schedule();}
  $('account-map-plus').onclick=()=>zoom(1.2);$('account-map-minus').onclick=()=>zoom(1/1.2);
  stage.addEventListener('wheel',event=>{event.preventDefault();zoom(event.deltaY<0?1.1:1/1.1);},{passive:false});
  // 指针超过阈值后才拖动；图层位移不重建按钮，双指结束后从当前位置继续。
  stage.addEventListener('pointerdown',event=>{if(event.target.closest('.account-map-tools'))return;pointers.set(event.pointerId,{x:event.clientX,y:event.clientY});drag={x:event.clientX,y:event.clientY,panX:state.x,panY:state.y};pinch=0;suppressClick=false;});
  stage.addEventListener('pointermove',event=>{
    if(!pointers.has(event.pointerId))return;pointers.set(event.pointerId,{x:event.clientX,y:event.clientY});
    if(pointers.size===2){const [a,b]=[...pointers.values()],distance=Math.hypot(a.x-b.x,a.y-b.y);if(pinch)zoom(distance/pinch);pinch=distance;suppressClick=true;stage.setPointerCapture(event.pointerId);return;}
    if(drag&&Math.hypot(event.clientX-drag.x,event.clientY-drag.y)>6){stage.setPointerCapture(event.pointerId);suppressClick=true;state.x=drag.panX+event.clientX-drag.x;state.y=drag.panY+event.clientY-drag.y;schedule();}
  });
  const release=event=>{pointers.delete(event.pointerId);pinch=0;const remaining=[...pointers.values()][0];drag=remaining?{...remaining,panX:state.x,panY:state.y}:null;};
  stage.addEventListener('pointerup',release);stage.addEventListener('pointercancel',release);
  new ResizeObserver(()=>{if(document.body.dataset.page==='talents')layoutMap();}).observe(stage);
  let seed=829;const random=()=>{seed=(seed*16807)%2147483647;return seed/2147483647;};
  $('account-starfield').innerHTML=Array.from({length:65},()=>'<i style="left:'+random()*100+'%;top:'+random()*100+'%;--star-size:'+(random()*1.4+.7)+'px;opacity:'+(random()*.45+.15)+'"></i>').join('');
  $('account-level-reset').onclick=()=>$('account-reset-dialog').showModal();$('account-reset-cancel').onclick=()=>$('account-reset-dialog').close();
  $('account-reset-confirm').onclick=()=>{try{levels=store.save({});$('account-reset-dialog').close();updateLevels();$('account-save-state').textContent='已恢复1级';$('account-talent-status').textContent='';document.dispatchEvent(new CustomEvent('account-talents-changed'));}catch(error){globalThis.Diagnostics?.record('talents',error,'DATA_SAVE');$('account-talent-status').textContent=error.message;}};
  window.addEventListener('storage',event=>{if(event.key===store.key){if(document.body.dataset.page==='talents'&&read())updateLevels();document.dispatchEvent(new CustomEvent('account-talents-changed'));}});
  globalThis.AccountTalentUI={open:render,leave(){pointers.clear();drag=null;pinch=0;$('account-reset-dialog').close();if(frame){cancelAnimationFrame(frame);frame=0;}},back,snapshot:()=>({...state,levels:store.get()})};
})();
