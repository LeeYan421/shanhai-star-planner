/* 原生外壳负责触摸与停靠，页面按当前星宿内容收敛高度。 */
(() => {
  'use strict';
  const $=id=>document.getElementById(id),core=DesktopGuideCore,esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let plan,groups=[],checked=new Set(),cursor=0,mode='overview',dragged=false,reportedHeight=0;
  const complete=group=>group.nodes.every(node=>checked.has(node.id));
  function maxHeight(){try{return JSON.parse(AndroidPlanner.getGuideWindowMetrics()).maxHeight;}catch(error){globalThis.Diagnostics?.record('guide',error,'GUIDE_LAYOUT');return innerHeight;}}
  function fit(){
    if(document.body.classList.contains('is-mini'))return;
    const frame=document.querySelector('.frame'),style=getComputedStyle(frame),gap=parseFloat(style.rowGap)||0;
    const chrome=document.querySelector('.guide-bar').offsetHeight+document.querySelector('.guide-meta').offsetHeight+$('status').offsetHeight+document.querySelector('footer').offsetHeight+parseFloat(style.paddingTop)+parseFloat(style.paddingBottom)+3*gap;
    const limit=mode==='overview'&&cursor>=0?maxHeight():Math.min(280,maxHeight()),available=Math.max(20,limit-chrome);let contentHeight=0;
    // 按完整属性名和等级的实测宽度分栏，长属性保留完整文字，行号仍按列从上到下排列。
    if(mode==='overview'&&cursor>=0){const grid=$('rows'),rows=groups[cursor].rows,columnWidth=Math.max(104,...[...grid.children].map(row=>row.firstElementChild.getBoundingClientRect().width+row.lastElementChild.getBoundingClientRect().width+12)),maxColumns=Math.max(1,Math.min(2,Math.floor((grid.clientWidth+6)/(columnWidth+6)))),columns=rows.length>=4?maxColumns:1,per=Math.ceil(rows.length/columns);contentHeight=per*20;grid.style.gridTemplateRows=`repeat(${per},20px)`;grid.style.gridTemplateColumns=`repeat(${columns},minmax(0,1fr))`;grid.style.height=Math.min(contentHeight,available)+'px';grid.style.overflowY=contentHeight>available?'auto':'hidden';}
    else contentHeight=[...$('content').children].reduce((sum,node)=>sum+node.getBoundingClientRect().height,0);
    const height=Math.ceil(Math.min(limit,chrome+Math.max(20,contentHeight)));
    if(typeof AndroidPlanner.reportGuideHeight==='function'&&height!==reportedHeight){reportedHeight=height;AndroidPlanner.reportGuideHeight(height);}
  }
  function render(){
    const group=groups[cursor],count=groups.filter(complete).length;$('position').textContent=count+'/'+groups.length;$('bubble-label').textContent='星宿\n'+count+'/'+groups.length;
    $('title').textContent=group?.title||'加点已完成';$('location').textContent=group?.location||'';$('order').textContent=group?'点亮 '+group.nodes.map(node=>node.row).join('→')+'行':'';
    $('rows').hidden=mode!=='overview'||!group;$('content').hidden=mode==='overview'&&!!group;
    // 余额按当前星宿点完后的检查点显示，分母始终使用玩家填写的总预算。
    if(group){$('rows').innerHTML=group.rows.map(row=>`<mdui-list-item nonclickable class="row ${!row.level?'skipped':checked.has(row.id)?'checked':''}"><span>${row.row} ${esc(row.attribute)}</span><strong slot="end-icon">${row.level?row.level+'级'+(checked.has(row.id)?'✓':''):'不点'}</strong></mdui-list-item>`).join('');$('status').textContent='本宿'+group.cost+'点 · 点完剩余'+(plan.budget-group.cumulative)+'/'+plan.budget+'点';}
    else{$('status').textContent='剩余'+(plan.budget-plan.spent)+'/'+plan.budget+'点';$('content').innerHTML=`<mdui-list-item nonclickable class="detail">${esc(((plan.talents||[]).join('\n\n')||'所有星宿已完成。')+'\n返回主窗口复核并装备天赋')}</mdui-list-item>`;}
    if(mode==='details'&&group)$('content').innerHTML=group.nodes.map(node=>`<mdui-list-item nonclickable class="detail">${esc('第'+node.row+'行 · '+node.attribute+' → Lv'+node.level+'\n+'+node.value+' · '+node.cost+'点\n'+node.levelText)}</mdui-list-item>`).join('');
    if(mode==='list')$('content').innerHTML=groups.map((group,index)=>`<mdui-list-item class="star" data-jump="${index}">${index+1}. ${esc(group.title)} · ${group.cost}点${complete(group)?' ✓':''}</mdui-list-item>`).join('');
    $('details').textContent=mode==='details'?'总览':'明细';$('list').textContent=mode==='list'?'总览':'清单';$('done').textContent=!group?'关闭':complete(group)?'撤销':'完成并继续';$('done').disabled=!!group&&!core.canComplete(group,checked);if($('done').disabled)$('done').textContent='先点前置';requestAnimationFrame(fit);
  }
  globalThis.refreshGuide=()=>{const raw=AndroidPlanner.getFloatingGuide();if(!raw||raw==='null')return;plan=JSON.parse(raw);groups=core.groups(plan);let saved=plan.checked||[];try{saved=JSON.parse(AndroidPlanner.getGuideProgress(plan.key)||JSON.stringify(saved));}catch(error){globalThis.Diagnostics?.record('guide',error,'DATA_RESTORE');}checked=core.restore(plan,saved);cursor=groups.findIndex(group=>!complete(group));render();};
  $('previous').onclick=()=>{cursor=cursor<0?groups.length-1:Math.max(0,cursor-1);mode='overview';render();};$('next').onclick=()=>{cursor=Math.min(groups.length-1,Math.max(0,cursor)+1);mode='overview';render();};
  $('details').onclick=()=>{mode=mode==='details'?'overview':'details';render();};$('list').onclick=()=>{mode=mode==='list'?'overview':'list';render();};$('content').onclick=event=>{const button=event.target.closest('[data-jump]');if(button){cursor=Number(button.dataset.jump);mode='overview';render();}};
  $('done').onclick=()=>{if(cursor<0){AndroidPlanner.windowAction('close');return;}try{const next=core.toggle(plan,checked,cursor);if(!AndroidPlanner.saveGuideProgress(plan.key,JSON.stringify([...next])))throw new Error('进度未能保存');checked=next;cursor=groups.findIndex(group=>!complete(group));mode='overview';render();}catch(error){globalThis.Diagnostics?.record('guide',error,'GUIDE_STATE');$('status').textContent=error.message;}};
  $('close').onclick=()=>AndroidPlanner.windowAction('close');$('minimize').onclick=()=>AndroidPlanner.windowAction('minimize');$('guide-bubble').onclick=event=>{if(dragged){event.preventDefault();return;}AndroidPlanner.windowAction('restore');};
  globalThis.setGuideMini=value=>{document.body.classList.toggle('is-mini',!!value);$('guide-bubble').classList.toggle('hidden',!value);if(!value){document.body.classList.remove('edge-hidden');requestAnimationFrame(fit);}};
  globalThis.setGuideDock=(left,hidden)=>{document.body.dataset.edge=left?'left':'right';document.body.classList.toggle('edge-hidden',!!hidden);};
  // 桌面保留窗口桥接；安卓拖动由原生触摸直接处理。
  if(globalThis.DesktopHost)for(const handle of [$('drag-handle'),$('guide-bubble')]){let origin;handle.addEventListener('pointerdown',event=>{origin={x:event.screenX,y:event.screenY};dragged=false;handle.setPointerCapture(event.pointerId);});handle.addEventListener('pointermove',event=>{if(!origin)return;const dx=event.screenX-origin.x,dy=event.screenY-origin.y;if(Math.abs(dx)+Math.abs(dy)>6)dragged=true;if(dragged)AndroidPlanner.dragGuideWindow(dx,dy,false);});const end=()=>{if(origin&&dragged)AndroidPlanner.dragGuideWindow(0,0,true);origin=null;};handle.addEventListener('pointerup',end);handle.addEventListener('pointercancel',end);}
  new ResizeObserver(()=>requestAnimationFrame(fit)).observe(document.querySelector('.guide-meta'));addEventListener('resize',()=>requestAnimationFrame(fit));globalThis.DesktopGuide={jump(index){cursor=index;mode='overview';render();},snapshot:()=>({cursor,checked:[...checked],groups:groups.length,rows:groups[cursor]?.rows.length||0})};refreshGuide();
})();
